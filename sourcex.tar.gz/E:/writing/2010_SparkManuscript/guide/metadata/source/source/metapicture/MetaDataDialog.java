//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************
 Name: MetaDataDialog.java
 Function: Dialog of tabbed panes with first pane as MetaDataList.
 Author: Sean Parsons
 Date: Spring 2010

 Description:


 ****************************************************************************/
//////////////////////////////////////////////////////////////////////////////

package metapicture;

import java.awt.*;
import javax.swing.*;

//panel packages
import frequency.*;
import spark.*;
import histogram.*;


public class MetaDataDialog extends JDialog {

    //minimum elements
    JTabbedPane tbpane;
    MetaDataList listpane;
    
    //other tabbed panes
    fftPanel fftpanel;
    sparkpanel spark_panel;
    histpanel hist_panel;
  


    public MetaDataDialog(Frame parent, String title, boolean modal){

        //dialog set up
        super(parent, title, Dialog.ModalityType.MODELESS);
        setSize(600,600);
        setResizable(true);
        
        setLayout(new GridLayout(1, 2));

        //list panel
        listpane = new MetaDataList();

        //spark panel
        spark_panel = new sparkpanel(listpane);

        //histogram panel
        hist_panel = new histpanel(listpane);

        //tabbed pane
        tbpane = new JTabbedPane();
        tbpane.addTab("SPRK", spark_panel);
        tbpane.addTab("HIST", hist_panel);

        add("List", listpane);
        add(tbpane);


    }

   

}
