/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package metapicture;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import ij.gui.*;
import ij.*;
import ij.process.*;

import SPUtils.*;
/**
 *
 * @author Sean
 */
public class CalPanel extends JDialog implements MouseMotionListener, ActionListener {

    JButton xname;
    JButton yname;
    JTextField xfield;
    JTextField yfield;
    JLabel xunit;
    JLabel yunit;

    boolean xyAreTheSame;
    
    MetaPicture pic;
    ImageCanvas win;
    CoorPair p1;
    CoorPair p2;
    
    public CalPanel(Frame parent){

        super(parent, "dimensions", false);
        setSize(300,75);
        setResizable(false);

        //add components
        xname = new JButton("x name");
        xname.addActionListener(this);
        yname = new JButton("y name");
        yname.addActionListener(this);
        xfield = new JTextField("");
        yfield = new JTextField("");
        xunit = new JLabel("x unit");
        yunit = new JLabel("y unit");
    
        xyAreTheSame = false;
        setLayout(new GridLayout(2,3));
        add(xname);
        add(xfield);
        add(xunit);
        add(yname);
        add(yfield);
        add(yunit);

        p1 = new CoorPair();
        p2 = new CoorPair();
  
    }

    //overloaded show, reads in image data
    public void show(MetaPicture arg){
        pic = arg;
        win = arg.DImage.getCanvas();
        win.addMouseMotionListener(this);
        setTitle(pic.picname + ", calibration");
        GetImageData(pic);
        this.setModal(false);
        this.show();
        setLocationRelativeTo(win);
    }

    //get values from an image plus
    void GetImageData(MetaPicture arg){

        //if x and y dimensions are the same....
        if (
            (arg.metadata.GetValue(MetaTagType.X_NAME).matches(arg.metadata.GetValue(MetaTagType.Y_NAME)))
            &&
            (arg.metadata.GetValue(MetaTagType.X_UNIT).matches(arg.metadata.GetValue(MetaTagType.Y_UNIT)))
            ){

            xyAreTheSame = true;
            if (isAncestorOf(yname) == true) remove(yname);
            if (isAncestorOf(yfield) == true) remove(yfield);
            if (isAncestorOf(yunit) == true) remove(yunit);
            setLayout(new GridLayout(1,3));
            
            xname.setText(arg.metadata.GetValue(MetaTagType.X_NAME));
            xunit.setText(arg.metadata.GetValue(MetaTagType.X_UNIT));

        //...if not.....
        } else {

            xyAreTheSame = false;
            if (isAncestorOf(yname) == false) add(yname);
            if (isAncestorOf(yfield) == false) add(yfield);
            if (isAncestorOf(yunit) == false) add(yunit);
            setLayout(new GridLayout(2,3));
            
            xname.setText(arg.metadata.GetValue(MetaTagType.X_NAME));
            xunit.setText(arg.metadata.GetValue(MetaTagType.X_UNIT));
            yname.setText(arg.metadata.GetValue(MetaTagType.Y_NAME));
            yunit.setText(arg.metadata.GetValue(MetaTagType.Y_UNIT));

        }


    }


    //update values in xfield/yfield
    public void mouseDragged(MouseEvent e){

            //get bounds
            Roi roi_untrans = pic.DImage.getRoi();

            if (roi_untrans == null) xfield.setText("no roi");

            //get bounds of transformed (DImage to OImage) roi
            Rectangle rec = pic.GetTransROI(false, roi_untrans).getBounds();

            p1.Set(rec.x, rec.y);
            p2.Set(rec.x + rec.width, rec.y + rec.height);
            
            //calculate differences in units
            double xd = MetaUtils.StrToDbl(pic.metadata.GetValue(MetaTagType.X_RES))
                            * Math.abs(p1.x - p2.x);
            double yd = MetaUtils.StrToDbl(pic.metadata.GetValue(MetaTagType.Y_RES))
                            * Math.abs(p1.y - p2.y);

            //..if x and y are the same
            if (xyAreTheSame == true){
                double xyd = Math.sqrt(Math.pow(xd, 2) + Math.pow(yd, 2));
                xfield.setText(MetaUtils.DblToStr(xyd, 5));
            //..or if x and y are not the same
            }else{
                xfield.setText(MetaUtils.DblToStr(xd, 5));
                yfield.setText(MetaUtils.DblToStr(yd, 5));
            }//end of if x/y are the same

    }
    
    //does nothing
    public void mouseMoved(MouseEvent e){}

    public void actionPerformed(ActionEvent ae){

        if (ae.getSource() == xname){

            //get input length
            double len = MetaUtils.StrToDbl(xfield.getText());
            double res = 0;
            if (len > 0){
                
                if (xyAreTheSame == true){
                    res = len / Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
                    if (IJ.showMessageWithCancel("cal", "change x resolution?")){
                       pic.metadata.SetValue(MetaTagType.X_RES, MetaUtils.DblToStr(res));
                       pic.metadata.SetValue(MetaTagType.Y_RES, MetaUtils.DblToStr(res));
                    } 
                } else { 
                   //calculate resolution (units/pixel)
                   res = len / Math.abs(p1.x - p2.x); 
                   if (IJ.showMessageWithCancel("cal", "change x resolution?"))
                       pic.metadata.SetValue(MetaTagType.X_RES, MetaUtils.DblToStr(res));
                }
    
            }

        }
        else if (ae.getSource() == yname){

            //get input length
            double len = MetaUtils.StrToDbl(yfield.getText());
            double res = 0;
            if (len > 0){
                //calculate resolution (units/pixel)
                res = len / Math.abs(p1.y - p2.y);
                if (IJ.showMessageWithCancel("cal", "change y resolution?")){
                    pic.metadata.SetValue(MetaTagType.Y_RES, MetaUtils.DblToStr(res));
                    IJ.showMessage("y resolution changed to " + MetaUtils.DblToStr(res));
                }
            }

        }
        else;


    }

}
