/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SPUtils;

import java.util.ArrayList;
import ij.process.*;
import regions.*;
/**
 *
 * @author Sean
 */
public abstract class Moments {

    //cnstr
    Moments(){}

    //CALCULATE MOMENTS OF XY PAIRED COORDINATE DATA

    //moment; m<pq>
    public static double Moment(ArrayList<CoorPair> arg, int p, int q) {

        double Mpq = 0;
        for(int i = 0; i < arg.size(); i++)
            Mpq += (Math.pow(arg.get(i).x, p) * Math.pow(arg.get(i).y, q));

        return Mpq;

    }

    //central moment; c<pq>
    public static double CentralMoment(ArrayList<CoorPair> arg, int p, int q) {

        double m00  = Moment(arg,  0, 0);	// region area
        double xCtr = Moment(arg, 1, 0) / m00;
        double yCtr = Moment(arg, 0, 1) / m00;

        double cMpq = 0;
        for(int i = 0; i < arg.size(); i++)
              cMpq += Math.pow(arg.get(i).x - xCtr, p) * Math.pow(arg.get(i).y - yCtr, q);

        return cMpq;

    }

    //CALCULATE MOMENTS OF BINARY REGION
    //ip = binary descriptor, arg = region info

    //moment; m<pq>
    public static double Moment(ImageProcessor ip, BinaryRegion arg, int p, int q) {

        double Mpq = 0;
        for(int i = arg.left; i <= arg.right; i++)
            for(int j = arg.top; j <= arg.bottom; j++)
                if (ip.getf(i, j) == arg.label)
                        Mpq += (Math.pow(i, p) * Math.pow(j, q));

        return Mpq;

    }

    //central moment; c<pq>
    public static double CentralMoment(ImageProcessor ip, BinaryRegion arg, int p, int q) {

        double m00  = Moment(ip, arg,  0, 0);	// region area
        double xCtr = Moment(ip, arg, 1, 0) / m00;
        double yCtr = Moment(ip, arg, 0, 1) / m00;

        double cMpq = 0;
        for(int i = arg.left; i <= arg.right; i++)
            for(int j = arg.top; j <= arg.bottom; j++)
                if (ip.getf(i, j) == arg.label)
                        cMpq += Math.pow(i - xCtr, p) * Math.pow(j - yCtr, q);

        return cMpq;

    }

    //CALCULATE MOMENTS OF REGION
    //ip = binary descriptor, ipv = scalar values, arg = region info

    //moment; m<pq>
    public static double Moment(ImageProcessor ip, ImageProcessor ipv, BinaryRegion arg, int p, int q) {

        double Mpq = 0;
        for(int i = arg.left; i <= arg.right; i++)
            for(int j = arg.top; j <= arg.bottom; j++)
                if (ip.getf(i, j) == arg.label)
                        Mpq += (Math.pow(i, p) * Math.pow(j, q) * -ipv.getf(i, j));

        return Mpq;

    }

    //central moment; c<pq>
    public static double CentralMoment(ImageProcessor ip, ImageProcessor ipv, BinaryRegion arg, int p, int q) {

        double m00  = Moment(ip, arg,  0, 0);	// region area
        double xCtr = Moment(ip, arg, 1, 0) / m00;
        double yCtr = Moment(ip, arg, 0, 1) / m00;

        double cMpq = 0;
        for(int i = arg.left; i <= arg.right; i++)
            for(int j = arg.top; j <= arg.bottom; j++)
                if (ip.getf(i, j) == arg.label)
                        cMpq += (Math.pow(i - xCtr, p) * Math.pow(j - yCtr, q) * -ipv.getf(i, j));

        return cMpq;

    }




}
