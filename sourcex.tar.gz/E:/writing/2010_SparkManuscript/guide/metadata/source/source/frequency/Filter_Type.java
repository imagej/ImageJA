

package frequency;


public enum Filter_Type {
    
    BESSEL("Bessel"),
    BUTTERWORTH("Butterworth");

    //MEMBERS
    private String description;

    //CNSTR
    Filter_Type(String description_arg){
        description = description_arg;
    }

    //GET
    String GetDescription(){
        return description;
    }

}
