/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package spark;


import metapicture.*;
import ij.process.*;
import javax.swing.*;
import java.util.ArrayList;
import ij.*;


public class MXRRatio2 extends SwingWorker<Boolean, Void>{


    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)

    float step;             //step level
    int sback;              //number of levels to look back over for nregion comparison
    boolean doAverage;      //average values across scan line?

    public MXRRatio2(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;

        //output picture?
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "MXRRatio");
        output.metadata.SetValueUnEditable(MetaTagType.A_NAME, "F/F0");
        output.metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, "0.0");
        output.metadata.SetValueUnEditable(MetaTagType.A_RES, "1.0");
        output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "");
        output.name = output.name + "_" + "MXRRatio";
        output.SetFilePath();
        output.SetPictureName();

    }

    void SetVariables(float step_arg, int sback_arg, boolean doAverage_arg){

        if (step_arg < 0) step_arg = 1; else step = step_arg;
        if(sback_arg < 1) sback = 1; else sback = sback_arg;
        doAverage = doAverage_arg;

    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //input and output image processors
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();
        
        //---------------------------------------------
        //??????????????????????????????????????
        
        int nloops = 0;
        boolean stop = false;
        float level = 0;
        float lmax = 0;
        ArrayList<LevelCount> rcount = new ArrayList<LevelCount>();
        LevelCount f0 = new LevelCount(0, 0);
        ArrayList<LevelCount> f0_line = new ArrayList<LevelCount>();
        
        //loop through lines
        for (int j = 0; j < yl; j++){
 
            //calculate first level
            level = step + GetLineMin(imp, j);
            lmax = GetLineMax(imp, j);

            //loop through levels
            stop = false;

            while(level < lmax){

                //if(j == 0) IJ.showMessage("level = " + level);
                //find number of regions at current level
                rcount.add(new LevelCount(level, GetLineCount(imp, j, level)));

                //increase level
                level += step;

            }//end of while loop

            //find maximum count and add to f0_line;
            for(int i = 0; i < rcount.size(); i++){
                if (rcount.get(i).count > f0.count) f0.Set(rcount.get(i));
            }
            f0_line.add(new LevelCount(f0));
    
            //remove elements of rcount
            rcount.clear();
            f0.Set(0, 0);
        
        }
        
        if (doAverage){
   
            //divide by F0 (average of F0's)
            float av = 0;
            for(int i = 0; i < f0_line.size(); i++)
                av += f0_line.get(i).level;
            av /= (float)f0_line.size();
            for(int i = 0; i < imp_o.getPixelCount(); i++)
                imp_o.setf(i, imp.getf(i) / av);

        } else {

            //divide by F0 (line by line)
            for(int j = 0; j < yl; j ++)
                for(int i = 0; i < xl; i ++){
                    imp_o.setf(i, j, imp.getf(i, j) / f0_line.get(j).level);
                }

        }
        
        //set output processors to OImage
        imp_o.setMinAndMax(0, 10.0);
        output.SetToOriginal();

        //return
        return true;

    }

    @Override
    public void done() {

          parent.WhenMXRRatioDone();

    }

    float GetLineMin(ImageProcessor ip, int ln){

        if((ln < 0) || (ln >= ip.getHeight())) ln = 0;

        float min = (float)ip.getMax();
        for(int i = 0; i < ip.getWidth(); i++)
            if (ip.getf(i, ln) < min) min = ip.getf(i, ln);

        return min;

    }
    
    float GetLineMax(ImageProcessor ip, int ln){

        if((ln < 0) || (ln >= ip.getHeight())) ln = 0;

        float max = (float)ip.getMin();
        for(int i = 0; i < ip.getWidth(); i++)
            if (ip.getf(i, ln) > max) max = ip.getf(i, ln);

        return max;

    }

    int GetLineCount(ImageProcessor ip, int ln, float lev){

        if((ln < 0) || (ln >= ip.getHeight())) ln = 0;

        int count = 0;
        for(int i = 1; i < ip.getWidth(); i++)
            if ((ip.getf(i-1, ln) < lev) && (ip.getf(i, ln) >= lev)) count++;

        count /= 2;

        return count;

    }
    
    class LevelCount {
        
        public float level;
        public int count;

        public LevelCount(LevelCount arg){
            level = arg.level;
            count = arg.count;
        }
        
        public LevelCount(float level_arg, int count_arg){
            level = level_arg;
            count = count_arg;
        }
        
        public void Set(float level_arg, int count_arg){
            level = level_arg;
            count = count_arg;
        }

        public void Set(LevelCount arg){
            level = arg.level;
            count = arg.count;
        }

    }


}
