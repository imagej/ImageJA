/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PhysiolPlot;

//package components;

import SPUtils.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import metapicture.*;
import SPUtils.*;


public class PhysiolViewer extends JPanel implements ActionListener {

    //DATA
    MetaPicture mypic;              //picture
    double yzoom;           //y zoom factor
    double xzoom;           //x zoom factor
    
    //GUI ELEMENTS
    private JScrollPane pictureScrollPane;  //scroll pane
    private ScrollablePicture picture;      //picture
    private Rule columnView;                //x ruler
    private Rule rowView;                   //y ruler
    private AdjustPanel zpanel;             //zoom corner

    
    public PhysiolViewer(MetaPicture arg) {
        
        setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));

        mypic = arg;
        mypic.SetToOriginal();
        ImageIcon david = mypic.getIcon();

        //calculate image lengths and origins (units)
        double xlen = MetaUtils.StrToDbl(arg.metadata.GetValue(MetaTagType.X_RES));
        double ylen = MetaUtils.StrToDbl(arg.metadata.GetValue(MetaTagType.Y_RES));
        if (xlen >= 0) xlen *= (double)arg.OImage.getWidth();
            else xlen = (double)arg.OImage.getWidth();
        if (ylen >= 0) ylen *= (double)arg.OImage.getHeight();
            else ylen = (double)arg.OImage.getHeight();
        double xorg = MetaUtils.StrToDbl(arg.metadata.GetValue(MetaTagType.X_ORIGIN));
        double yorg = MetaUtils.StrToDbl(arg.metadata.GetValue(MetaTagType.Y_ORIGIN));
        
        //Create the row and column headers
        columnView = new Rule(Rule.HORIZONTAL, xorg, xlen, arg.metadata.GetValue(MetaTagType.X_UNIT));
        rowView = new Rule(Rule.VERTICAL, yorg, ylen, arg.metadata.GetValue(MetaTagType.Y_UNIT));
        if (david != null) {
            columnView.setPixelSize(david.getIconWidth());
            rowView.setPixelSize(david.getIconHeight());
        } else {
            columnView.setPixelSize(300);
            rowView.setPixelSize(300);
        }
        
        //Set up the scroll pane.
        picture = new ScrollablePicture(mypic.getIcon(), 1);
        pictureScrollPane = new JScrollPane(picture);
        pictureScrollPane.setPreferredSize(new Dimension(300, 250));
        pictureScrollPane.setViewportBorder(BorderFactory.createLineBorder(Color.black));
        pictureScrollPane.setColumnHeaderView(columnView);
        pictureScrollPane.setRowHeaderView(rowView);

	//Set the adjust corner
        zpanel = new AdjustPanel();
        zpanel.x_zoom_in.addActionListener(this);
        zpanel.x_zoom_out.addActionListener(this);
        zpanel.y_zoom_in.addActionListener(this);
        zpanel.y_zoom_out.addActionListener(this);
        pictureScrollPane.setCorner(JScrollPane.UPPER_LEADING_CORNER, zpanel);
        xzoom = yzoom = 1;
        
        //Put it in this panel
        add(pictureScrollPane);
       
    }
    
    public void ReSetPicture(){
        //reset displayed image
        
        picture.setIcon(mypic.getIcon());
        
        pictureScrollPane.setViewportView(picture);
        pictureScrollPane.setColumnHeaderView(columnView);
        pictureScrollPane.setRowHeaderView(rowView);
        
        mypic.DrawAllROIs(picture.getGraphics());//!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }

    //button pressed
    public void actionPerformed(ActionEvent ae){

        //X ZOOM IN
        if(ae.getSource() == zpanel.x_zoom_in){

            //increase zoom factor
            xzoom *= 2;
            //resize DImage
            mypic.ReSize(xzoom, yzoom);
            //adjust horizontal ruler and reset picture
            columnView.setPixelSize(mypic.DImage.getWidth());
            ReSetPicture();
        }
        //X ZOOM OUT
        else if(ae.getSource() == zpanel.x_zoom_out){

            //increase zoom factor
            xzoom /= 2;
            //resize DImage
            mypic.ReSize(xzoom, yzoom);
            //adjust horizontal ruler and reset picture
            columnView.setPixelSize(mypic.DImage.getWidth());
            ReSetPicture();
            
        }
        //Y ZOOM IN
        else if(ae.getSource() == zpanel.y_zoom_in){

            //increase zoom factor
            yzoom *= 2;
            //resize DImage
            mypic.ReSize(xzoom, yzoom);
            //adjust horizontal ruler and reset picture
            rowView.setPixelSize(mypic.DImage.getHeight());
            ReSetPicture();
            
        }
        //Y ZOOM OUT
        else if(ae.getSource() == zpanel.y_zoom_out){

            //increase zoom factor
            yzoom /= 2;
            //resize DImage
            mypic.ReSize(xzoom, yzoom);
            //adjust horizontal ruler and reset picture
            rowView.setPixelSize(mypic.DImage.getHeight());
            ReSetPicture();

        }
        
        
    }
 
}


/////////////////////////////////////////////////////////////////
class AdjustPanel extends JPanel{
    
    JButton x_zoom_in;
    JButton x_zoom_out;
    JButton y_zoom_in;
    JButton y_zoom_out;
    
    AdjustPanel(){
        
        x_zoom_in = new JButton("i");
        x_zoom_in.setFont(new Font("SansSerif",Font.ITALIC,10));
        x_zoom_out = new JButton("o");
        x_zoom_out.setFont(new Font("SansSerif",Font.ITALIC,10));
        y_zoom_in = new JButton("i");
        y_zoom_in.setFont(new Font("SansSerif",Font.ITALIC,10));
        y_zoom_out = new JButton("o");
        y_zoom_out.setFont(new Font("SansSerif",Font.ITALIC,10));

        setLayout(new GridLayout(3,3));
        add(new JLabel(""));
        add(y_zoom_in);
        add(new JLabel(""));

        add(x_zoom_in);
        add(new JLabel(""));
        add(x_zoom_out);

        add(new JLabel(""));
        add(y_zoom_out);
        add(new JLabel(""));       
        
    }
  
}

