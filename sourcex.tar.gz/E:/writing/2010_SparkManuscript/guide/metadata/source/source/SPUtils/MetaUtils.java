//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************
 Name: MetaUtils.java
 Function: Abstract class of utility functions.
 Author: Sean Parsons
 Date: Spring 2010

 Description:


 ****************************************************************************/
//////////////////////////////////////////////////////////////////////////////

package SPUtils;

import java.util.*;
import java.util.Calendar;
import java.text.SimpleDateFormat;


public abstract class MetaUtils {

    //--------------------------------------
    //CNSTR
    MetaUtils(){}

    //----------------------------------------
    //FILE HANDLING

    //get file path
    public static String GetFilePath(String arg){
        return arg.substring(0, arg.lastIndexOf('\\') + 1);
    }
    
    //get file name without extension
    public static String GetFileName(String arg){
        return arg.substring(arg.lastIndexOf('\\') + 1, arg.lastIndexOf('.'));
    }
    
    //get file extension
    public static String GetFileExtension(String arg){
        return arg.substring(arg.lastIndexOf('.') + 1);
    }

    //-----------------------------------------
    //NUMBER/STRING CONVERSION

    //convert double to string
    //normal
    public static String DblToStr(double arg){
         return Double.toString(arg);
    }
    //no trailing zeros
    public static String DblToStrNoZeroes(double arg){
        String val = Double.toString(arg);
        while ((val.endsWith("0")) && (val.charAt(val.length()-2) != '.'))
            val.substring(0, val.length()-2);
        return val;
    }
    //ndecimel places after the decimel
    public static String DblToStr(double arg, int ad){

        String val = Double.toString(arg);  //string rep of number

        //index of decimel point
        int di = val.indexOf('.');
        //if no decimel point add to end
        if (di < 0) {
            val = val.concat(".");
            di  = val.length() - 1;
        }

        //make sure range is okay
        if (ad < -1) return val;

        //buffer string if neccarsary
        if ((di + ad + 1) >= val.length())
            for (int i = 0; i < ad; i++) val += "0";

        //return substring
        return val.substring(0, di + ad + 1);

    }
    //bd places before the decimel to ad places after the decimel
    public static String DblToStr(double arg, int bd, int ad){
        
        String val = Double.toString(arg);  //string rep of number
        
        //index of decimel point
        int di = val.indexOf('.');
        //if no decimel point add to end
        if (di < 0) {
            val = val.concat(".");
            di  = val.length() - 1;
        }

        //make sure range is okay
        if ((bd < 1) || (ad < -1)) return val;

        //buffer string if neccarsary
        if ((di + ad + 1) >= val.length())
            for (int i = 0; i < ad; i++) val += "0";
        if ((di - bd) < 0)
            for (int i = 0; i < bd; i++) val = "0" + val;
        //get new decimel index
        di = val.indexOf('.');

        //return substring
        return val.substring(di - bd, di + ad + 1);

    }

    //convert string to double
    public static double StrToDbl(String arg){

            try{
                return Double.valueOf(arg).doubleValue();
            } catch(NumberFormatException e){
                return -1;
            } catch (NullPointerException e){
                return -1;
            }

     }

    //convert int to string
    public static String IntToStr(int arg){
         return Integer.toString(arg);
    }
    
    //---------------------------------------------
    //DATE/TIME
    public static String GetDateTime() {

        String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
        return sdf.format(cal.getTime());

    }
    
    //------------------------------------------
    //MATH

    //return closest value to target that is a integer power of base 10.
    public static double GetNearestBase10(double target){
        
        return Math.pow(10, GetNearestBase10Exponent(target));
    }
    
    //return e where 10^e is the closest value to target
    public static double GetNearestBase10Exponent(double target){
        
        double e = 0;
        if (target > Math.pow(10, e)){
            
           while (target > Math.pow(10, e)) e++;
           if ((target - Math.pow(10, e - 1)) < (Math.pow(10, e) - target)) e--;
            
        } else {
            
           while (target < Math.pow(10, e)) e--;
           if ((target - Math.pow(10, e)) > (Math.pow(10, e + 1) - target)) e++;

        }

        return e;
        
    }

    //return factorial of n
    public static int Factorial(int n){
        int val = 1;
        for (int i = 2; i <= n; i++) val *= i;
        return val;
    }

    public static float FactorialF(int n){
        float val = 1;
        for (int i = 2; i <= n; i++) val *= (float)i;
        return val;
    }

    public static double FactorialD(int n){
        double val = 1;
        for (int i = 2; i <= n; i++) val *= (double)i;
        return val;
    }
    
    //-----------------------------------------
    //RANDOM VARIABLES
    
    public static String GetRandomString(){

        Random r = new Random();
        return Long.toString(Math.abs(r.nextLong()), 36);
        
    }
    
    //--------------------------------------------
    //ARRAY SEARCH

    public static int GetMaxCoor(double arg[]){
        int ret = 0;
        double max = arg[0];
        for(int i = 0; i < arg.length; i++)
            if(arg[i] > max) {max = arg[i]; ret = i;}

        return ret;
    }

    public static int GetMinCoor(double arg[]){
        int ret = 0;
        double min = arg[0];
        for(int i = 0; i < arg.length; i++)
            if(arg[i] < min) {min = arg[i]; ret = i;}

        return ret;
    }

}
