/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package metapicture;

import java.util.*;
import java.io.*;
import SPUtils.*;
import ij.*;


/**
 *
 * @author Sean
 */
public class MetaTable extends MetaObject{

    ArrayList<Column> variables;     //variables
    public int nvariables;

    ArrayList<Column> data;     //data
    public int nrows;
    public int ncols;
    
    //CONSTR
    //default
    public MetaTable(){
        
        //TYPE
        type = 2;
        
        //FILE INFO
        SetFileData("c:\\somefile.txt");
        
        //METADATA
        metadata = new MetaArray("c:\\somefile.txt");
        CheckMinimumTags();
        SetPictureName();

        //VARIABLES
        variables = new ArrayList<Column>();
        variables.add(new StringColumn("name", ""));
        variables.add(new DoubleColumn("value", ""));
        
        //DATA
        data = new ArrayList<Column>();
        nrows = 0;
        ncols = 0;
        
    }
    
    //from txt file
    public MetaTable(String arg){
        
        //TYPE
        type = 2;
        
        //FILE INFO
        SetFileData(arg);
        
        //METADATA
        //create from this string at the end of this cnstr
        String metastring = "METATAGS\n";
        
        //VARIABLES
        variables = new ArrayList<Column>();
        variables.add(new StringColumn("name", ""));
        variables.add(new DoubleColumn("value", ""));
        
        //DATA
        data = new ArrayList<Column>();
        nrows = 0;
        ncols = 0;
        
        //READ DATA
        try{
           
            //open file
            FileReader in = new FileReader(arg);
            BufferedReader br = new BufferedReader(in);
    
            //loop through lines of stream
            String str = "";   //contents of line
            String stra[] = new String[2];  //contents of line split by \t
            int ns = 0;                 //length of stra[]
            int line_n = 0;             //line index
            MetaTagType my_tag = MetaTagType.A_NAME;
            
            boolean IsMetaTable = true; //flags if the txt file is not found to be a metatable
            boolean IsEndOfMetaData = false;        //flags for end of sections
            boolean IsEndOfVariables = false;
            boolean IsEndOfData = false;

            while (((str = br.readLine()) != null) &&
                    (IsMetaTable == true)){
     
                //split line
                stra = str.split("\t");
                ns = stra.length;
          
                //first line: check file is metadata
                if (line_n == 0){

                    if((ns > 0) &&(stra[0].matches("METADATA"))){
                     
                    } else IsMetaTable = false;
                    line_n++;
                    continue;

                
                //other lines: get data       
                } else {
                    
                    //metadata
                    if (IsEndOfMetaData == false){
                        if((ns > 1) && (stra[0].matches("") == false)){
                            metastring += (my_tag.GetTagString(stra[0]) + "\t" + stra[1] + "\n");
                        }else IsEndOfMetaData = true;
                    }
                    //variables
                    if (IsEndOfVariables == false){
                        if((ns > 3) && (stra[2].matches("") == false)){
                            AddVariable(stra[2], MetaUtils.StrToDbl(stra[3]));
                        }else IsEndOfVariables = true;
                    }
                    //data
                    if (IsEndOfData == false){
                        if((ns > 4) && (stra[4].matches("") == false)){

                            switch (line_n){
                                //add columns (type recognition???)
                                case 1:
                                   for(int i = 4; i < ns; i++) AddColumn(stra[i], "", 3);
                                   break;
                                //set units
                                case 2:
                                    for(int i = 4; i < ns; i++) data.get(i-4).units = stra[i];
                                    break;
                                //set data
                                default:
                                    AddRow();
                                    for(int i = 4; i < ns; i++) Set(nrows-1, i - 4, stra[i]);
                            }

                        }else IsEndOfData = true;
                        
                    }
                            
                }//end of if (1st line) else (other lines)

                line_n++;
                
            }//end of line loop
  
            in.close();
            
        }catch(IOException e){
            IJ.showMessage("could not open file, " + arg);
        }

        //METADATA (PART 2)
        metastring += "TAGEND\n";
        metadata = new MetaArray(metastring, arg);
        CheckMinimumTags();
        SetPictureName();

    }
    
    //copy
    public MetaTable(MetaTable arg){
        
        //TYPE
        type = 2;

        //FILE INFO
        SetFileData(arg.fpath);
        
        //METADATA
        metadata = new MetaArray(arg.metadata);
        SetPictureName();

        //VARIABLES
        nvariables = arg.nvariables;
        variables = new ArrayList<Column>();
        for(int i = 0; i < arg.variables.size(); i++){
            
            switch (arg.variables.get(i).type){
                
                case 1:
                    variables.add(new StringColumn((StringColumn)arg.variables.get(i)));
                    break;
                case 2:
                    variables.add(new IntegerColumn((IntegerColumn)arg.variables.get(i)));
                    break;
                default:
                    variables.add(new DoubleColumn((DoubleColumn)arg.variables.get(i)));
                    break;
   
            }
            
        }
        
        //DATA
        nrows = arg.nrows;
        ncols = arg.ncols;
        data = new ArrayList<Column>();
        for(int i = 0; i < arg.data.size(); i++){

            switch (arg.data.get(i).type){

                case 1:
                    data.add(new StringColumn((StringColumn)arg.data.get(i)));
                    break;
                case 2:
                    data.add(new IntegerColumn((IntegerColumn)arg.data.get(i)));
                    break;
                default:
                    data.add(new DoubleColumn((DoubleColumn)arg.data.get(i)));
                    break;

            }

        }
        
    }
    
    //----------------------------------------------------
    public void CheckMinimumTags(){
        
        //ID
        if (metadata.FindIndex(MetaTagType.CLASS_ID) == -1) metadata.AddTag(MetaTagType.CLASS_ID, "METATABLE");
            else metadata.SetValueUnEditable(MetaTagType.CLASS_ID, "METATABLE");
        if (metadata.FindIndex(MetaTagType.UNIQ_ID) == -1) metadata.AddUniqID();
        if (metadata.FindIndex(MetaTagType.CREAT_P) == -1) metadata.AddTag(MetaTagType.CREAT_P, "???");
        if (metadata.FindIndex(MetaTagType.DATATYPE) == -1) metadata.AddTag(MetaTagType.DATATYPE, "???");
        if (metadata.FindIndex(MetaTagType.CREAT_D) == -1) metadata.AddTag(MetaTagType.CREAT_D, "???");
        if (metadata.FindIndex(MetaTagType.PARENT_ID) == -1) metadata.AddTag(MetaTagType.PARENT_ID, "???");
        
    }

    public void AddVariable(String name, double val){

        variables.get(0).Add();
        variables.get(0).Set(name);
        variables.get(1).Add();
        variables.get(1).Set(val);
        nvariables++;

    }
    
    public void AddColumn(String title, String units, int t){
        
        switch(t){
            
            //STRING
            case 1:
                data.add(new StringColumn(title, units));
                break;
                
            //INT
            case 2:
                data.add(new IntegerColumn(title, units));
                break;
                
            //DOUBLE (default)
            default:
                data.add(new DoubleColumn(title, units));
                break; 
            
        }

        //complete rows
        for(int i = 0; i < nrows; i++) data.get(data.size()-1).Add();

        //update no. of columns
        ncols++;
              
    }
    
    public void AddRow(){

        //add element to each column
        for (int i = 0; i < data.size(); i++)
            data.get(i).Add();
        //update row count
        nrows++;
    }

    public void DeleteAllRows(){

        for (int i = 0; i < data.size(); i++)
            data.get(i).RemoveAll();

        nrows = 0;
        
    }

    public boolean Set(int r, int c, double val){

        if ((c < data.size()) && (r < data.get(c).Size())){
            data.get(c).Set(r, val);
            return true;
        }
        return false;
        
    }

    public boolean Set(int r, int c, String val){

        if ((c < data.size()) && (r < data.get(c).Size())){
            data.get(c).Set(r, val);
            return true;
        }
        return false;

    }
    
    public String Get(int r, int c){
        
        if ((c < data.size()) && (r < data.get(c).Size())){
            return data.get(c).Get(r);
        }
        return "";
        
    }

    public String GetColumnTitle(int c){

        if (c < data.size()) return data.get(c).title;
        return "";
    }

    public String GetColumnUnits(int c){
        if (c < data.size()) return data.get(c).units;
        return "";
    }
    
    public void WriteData(String arg){

        FileWriter out;
        try {

            out = new FileWriter(arg);

            out.write("METADATA\t\tVARIABLES\t\tDATA\n");
            
            int ny = 0;
            int nya[] = {metadata.Length(), nvariables, nrows + 2};
            for (int i = 0; i < 3; i++) if (nya[i] > ny) ny = nya[i];
            
            //loop through rows
            for (int iy = 0; iy < ny; iy++){

                //metadata
                if (iy < metadata.Length()){

                    //metadata.GetTagType(iy).toString() vs metadata.GetTagType(iy).GetDescription()
                    out.write((metadata.GetTagType(iy).GetDescription() +
                                "\t" +
                                metadata.GetValue(iy) +
                                "\t"));
                } else out.write("\t\t");

                //variables
                if  (iy < nvariables){

                    out.write((variables.get(0).Get(iy) +
                                "\t" +
                                variables.get(1).Get(iy) +
                                "\t"));

                } else out.write("\t\t");

                //data
                if (iy < nrows + 2){

                    for (int ix = 0; ix < ncols; ix++){

                        switch (iy){
                            case 0: out.write(data.get(ix).title);
                            break;
                            case 1: out.write(data.get(ix).units);
                            break;
                            default: out.write(data.get(ix).Get(iy - 2));
                        }

                        out.write("\t");

                    }//end of data x loop

                }//end of data

                //new line
                out.write("\n");

            }//end of table y loop

            out.close();

        }catch(IOException e){
            IJ.showMessage("failed to open stream to " + arg);
        }


    }

}

/////////////////////////////////////////////////////
//---------------------------------------------------

abstract class Column {

    public String title;       //title
    public String units;       //units
    public int type;

    Column(){
        title = "data";
        units = "units";
        type = 0;
    }
    
    Column(Column arg){
        title = arg.title;
        units = arg.units;
        type = arg.type;
    }

    //add entry
    abstract public void Add();

    //remove all entries
    abstract public void RemoveAll();

    //set entry
    abstract public void Set(int idx, String val);
    abstract public void Set(int idx, double val);
    abstract public void Set(String val);
    abstract public void Set(double val);

    //get entry
    abstract public String Get(int idx);
    abstract public String Get();

    //info
    abstract public int Size();

}


class StringColumn extends Column {

    private ArrayList<String> data;

    public StringColumn(){
        type = 1;
        data = new ArrayList<String>();
    }
    
    public StringColumn(StringColumn arg){
        
        title = arg.title;
        units = arg.units;
        type = arg.type;
        data = new ArrayList<String>();
        for(int i = 0; i < arg.data.size(); i++)
            data.add(arg.data.get(i));

    }

    public StringColumn(String title_arg, String units_arg){
        title = title_arg;
        units = units_arg;
        type = 1;
        data = new ArrayList<String>();
    }

    //add entry
    public void Add(){
        data.add("null");
    }

    //remove all entries
    public void RemoveAll(){
        data.clear();
    }

    //set entry
    public void Set(int idx, String val){
        if(idx < Size()) data.set(idx, val);
    }
    public void Set(int idx, double val){
        if(idx < Size()) data.set(idx, MetaUtils.DblToStr(val));
    }
    public void Set(String val){
        Set(data.size()-1, val);
    }
    public void Set(double val){
        Set(data.size()-1, val);
    }

    //get entry
    public String Get(int idx){
        if(idx < Size()) return data.get(idx);
        return "null";
    }
    public String Get(){
        return Get(data.size()-1);
    }

    //info
    public int Size(){
        return data.size();
    }

}


class DoubleColumn extends Column {

    private ArrayList<Double> data;

    public DoubleColumn(){
        type = 3;
        data = new ArrayList<Double>();
    }
    
    public DoubleColumn(DoubleColumn arg){
        
        title = arg.title;
        units = arg.units;
        type = arg.type;
        data = new ArrayList<Double>();
        for(int i = 0; i < arg.data.size(); i++)
            data.add(arg.data.get(i));

    }

    public DoubleColumn(String title_arg, String units_arg){
        title = title_arg;
        units = units_arg;
        type = 3;
        data = new ArrayList<Double>();
    }

    //add entry
    public void Add(){
        data.add(0.0);
    }

    //remove all entries
    public void RemoveAll(){
        data.clear();
    }

    //set entry
    public void Set(int idx, String val){
        if(idx < Size()) data.set(idx, MetaUtils.StrToDbl(val));
    }
    public void Set(int idx, double val){
        if(idx < Size()) data.set(idx, val);
    }
    public void Set(String val){
        Set(data.size()-1, val);
    }
    public void Set(double val){
        Set(data.size()-1, val);
    }

    //get entry
    public String Get(int idx){
        if(idx < Size()) return data.get(idx).toString();
        return "null";
    }
    public String Get(){
        return Get(data.size()-1);
    }

    //info
    public int Size(){
        return data.size();
    }

}


class IntegerColumn extends Column {

    private ArrayList<Integer> data;

    public IntegerColumn(){
        type = 2;
        data = new ArrayList<Integer>();
    }

    public IntegerColumn(IntegerColumn arg){
        
        title = arg.title;
        units = arg.units;
        type = arg.type;
        data = new ArrayList<Integer>();
        for(int i = 0; i < arg.data.size(); i++)
            data.add(arg.data.get(i));

    }
    
    public IntegerColumn(String title_arg, String units_arg){
        title = title_arg;
        units = units_arg;
        type = 2;
        data = new ArrayList<Integer>();
    }

    //add entry
    public void Add(){
        data.add(0);
    }

    //remove all entries
    public void RemoveAll(){
        data.clear();
    }

    //set entry
    public void Set(int idx, String val){
        if(idx < Size()) data.set(idx, (int)MetaUtils.StrToDbl(val));
    }
    public void Set(int idx, double val){
        if(idx < Size()) data.set(idx, (int)val);
    }
    public void Set(String val){
        Set(data.size()-1, val);
    }
    public void Set(double val){
        Set(data.size()-1, val);
    }

    //get entry
    public String Get(int idx){
        if(idx < Size()) return data.get(idx).toString();
        return "null";
    }
    public String Get(){
        return Get(data.size()-1);
    }

    //info
    public int Size(){
        return data.size();
    }

}

///////////////////////////////////////////////////////