/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SPUtils;

/**
 *
 * @author Sean
 */
public class CoorPair {

    public double x;
    public double y;

    public CoorPair(){
        x = 0;
        y = 0;
    }

    public CoorPair(double xarg, double yarg){
        x = xarg;
        y = yarg;
    }

    public CoorPair(CoorPair arg){
        x = arg.x;
        y = arg.y;
    }
    
    public void Set(double xarg, double yarg){
        x = xarg;
        y = yarg;
    }

    public void Set(CoorPair arg){
        x = arg.x;
        y = arg.y;
    }
    
    public void swap(){
        double hold = x;
        x = y;
        y = hold;
    }



}
