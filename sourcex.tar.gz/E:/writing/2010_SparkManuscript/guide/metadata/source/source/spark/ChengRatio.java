/*
 * Applies Cheng normalisation algorithm along x axis
 *
 *
 * Cheng et al. (1999) Amplitude Distribution of Calcium Sparks in Confocal Images: Theory and
   Studies with an Automatic Detection Method. Biophysical Journal 76, 606–617
 *
 * Sean Parsons, April 2010
 *
 *
 */

package spark;

import metapicture.*;
import SPUtils.MetaUtils.*;
import javax.swing.*;
import ij.process.*;
import ij.*;

public class ChengRatio extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)
    

    double Sfact;           //sigma (noise) factor
    int nmax;               //maxiumum number of iterations
    
    public ChengRatio(sparkpanel parent_arg, MetaPicture arg){
        
        parent = parent_arg;
        input = arg;

        //output picture?
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "ChengRatio");
        output.metadata.SetValueUnEditable(MetaTagType.A_NAME, "F/F0");
        output.metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, "0.0");
        output.metadata.SetValueUnEditable(MetaTagType.A_RES, "1.0");
        output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "");
        output.name = output.name + "_" + "ChengRatio";
        output.SetFilePath();
        output.SetPictureName();
              
        //variables/etc
        Sfact = 2.0;
        nmax = 20;
        
    }

    void SetVariables(double Sfact_arg, int nmax_arg){

        if((Sfact_arg > 0) && (Sfact_arg <= 10)) Sfact = Sfact_arg;
        if((nmax > 0) && (nmax <= 100))nmax = nmax_arg;

    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //dimensions
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();

        //array for holding values closed by last loop
        boolean off_arr[] = new boolean[xl];
        float f0_arr[] = new float[yl];
   
        int count_off = xl;      //number of pixels not masked (off_arr == false)
        int count_loop = 0;     //number of loops
        float mean = 0f;        //mean
        float sd = 0f;          //standard deviation
        float thresh = 0;       //threshold
        Float ch = new Float(0);

        //loop through rows
        for (int j = 0; j < yl; j++){
        
            //for each row.....
            count_off = xl-2;
          
            for (int i = 2; i < xl; i++){
                if((ch.isNaN(imp_o.getf(i, j))) || (ch.isInfinite(imp_o.getf(i,j)))){
                    //IJ.showMessage("NaN, row = " + j);
                    off_arr[i] = true;
                    count_off--;
                }
                else off_arr[i] = false;
            }
 
            count_loop = 0;
            while ((count_off > 0) && (count_loop < nmax)){

                //calculate mean
                mean = 0f;
                for (int i = 2; i < xl; i++)
                    if ((off_arr[i] == false) && (imp.getf(i, j) != 0))
                        mean += (imp.getf(i, j) / (float)count_off);

                //calculate sd
                sd = 0f;
                for (int i = 2; i < xl; i++)
                    if ((off_arr[i] == false) && (imp.getf(i, j) != 0))
                        sd +=  Math.pow((imp.getf(i, j) - mean), 2);
                sd /= count_off;
                sd = (float)Math.sqrt(sd);

                //mask
                thresh = mean + ((float)Sfact * sd);
                for (int i = 2; i < xl; i++)
                   if ((off_arr[i] == false) && (imp.getf(i, j) > thresh)){
                      off_arr[i] = true;
                      count_off --;
                   }

                count_loop++;

            }//end of row loop

            if(ch.isNaN(mean)) IJ.showMessage("row " + j + " is Nan");
            if(ch.isInfinite(mean)) IJ.showMessage("row " + j + " is Inf");

            f0_arr[j] = mean;
           
        }//end of loop through rows

        //ratio output
        float val = 0;
        for (int j = 0; j < yl; j++)
            for (int i = 2; i < xl; i++){
                val = 1 + ((imp.getf(i, j) - f0_arr[j])/ f0_arr[j]);
                if((ch.isNaN(val)) || (ch.isInfinite(val))) imp_o.setf(i, j, 1);
                    else imp_o.setf(i, j, val);
            }
        
        
        //set output processors to OImage
        imp_o.setMinAndMax(0, 10.0);
        output.SetToOriginal();

        return true;

    }

    @Override
    public void done() {

          parent.WhenRatioDone();

    }




}
