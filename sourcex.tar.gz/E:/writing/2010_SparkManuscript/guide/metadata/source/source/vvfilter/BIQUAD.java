/*
 An IIR filter library, translated from the c++ code of Vladimir L. Vassilevsky.
 *
 * Sean Parsons, April 2010
 *
 * BIQUAD.java
 * FILTER.java
 *
 * BIQUAD_TYPE.java
 * FILTER_FUNCTION.java
 * FILTER_TYPE.java
 *
 * bessel_tables.java
 * misutil.java
 * modphase.java (added by SP)
 *
 *
 */

package vvfilter;

import flanagan.complex.*;

public class BIQUAD {

    //============ Design input parameters

    BIQUAD_TYPE bt;     // type of function
    double fs;             // sample rate (Hz)
    double fc;             // cutoff/center/corner frequency (Hz)
    double Q;              // Q of section
    double gain_db;        // gain in passband (dB), boost/cut for EQ filter

    // biquad unquantized coeffs
    double b0;
    double b1;
    double b2;
    double a1;
    double a2;

    // biquad coeffs (rounded to 4.20 accuracy)
    double round_b0;
    double round_b1;
    double round_b2;
    double round_a1;
    double round_a2;

    // biquad coeffs in 4.20 integer format
    int fract_b0;
    int fract_b1;
    int fract_b2;
    int fract_a1;
    int fract_a2;

    /*
    BIQUAD::BIQUAD(void){
        BIQUAD::DesignBiquad(FLAT, SAMPLE_RATE, 1000.0, 0.0, 0.0);
    }
     */
    public BIQUAD(){
        DesignBiquad(BIQUAD_TYPE.FLAT, 48000.0, 1000.0, 0.0, 0.0f);
    }

    public void print(){

        System.out.println("bt = " + bt + "\n" +
                           "fs = " + fs + "\n" +
                           "fc = " + fc + "\n" +
                           "Q = " + Q  + "\n" +
                           "gain_db = " + gain_db + "\n" +
                           "biquad unquantized coeffs\n" +
                           "b0 = " + b0 + "\n" +
                           "b1 = " + b1 + "\n" +
                           "b2 = " + b2 + "\n" +
                           "a1 = " + a1 + "\n" +
                           "a2 = " + a2 + "\n" +
                           "biquad coeffs (rounded to 4.20 accuracy)\n" +
                           "round_b0 = " + round_b0 + "\n" +
                           "round_b1 = " + round_b1 + "\n" +
                           "round_b2 = " + round_b2 + "\n" +
                           "round_a1 = " + round_a1 + "\n" +
                           "round_a2 = " + round_a2 + "\n" +
                           "biquad coeffs in 4.20 integer format\n" +
                           "fract_b0 = " + fract_b0 + "\n" +
                           "fract_b1 = " + fract_b1 + "\n" +
                           "fract_b2 = " + fract_b2 + "\n" +
                           "fract_a1 = " + fract_a1 + "\n" +
                           "fract_a2 = " + fract_a2 + "\n");


    }
    
    /*
     * 
    void BIQUAD::DesignBiquad(BIQUAD_TYPE bt, double fs, double fc, double Q, f32 gain_db){
        double omega; // warp factor
        double gain;
        double norma,A;
        double A1, A2;

        BIQUAD::bt      = bt;
        BIQUAD::fs      = fs;
        BIQUAD::fc      = fc;
        BIQUAD::Q       = Q;
        BIQUAD::gain_db = gain_db;

        // Use for A1A2 design only

        A1 = Q;
        A2 = gain_db;

        omega   =   tan(fc*PI/fs);
        gain    =   pow(10.0, gain_db/20.0);

        switch(bt){

            case FLAT:
                BIQUAD::b0 = gain;
                BIQUAD::b1 = 0.0;
                BIQUAD::b2 = 0.0;
                BIQUAD::a1 = 0.0;
                BIQUAD::a2 = 0.0;
                BIQUAD::Q  = 0.0;
                break;

                                    //           1
            case LOWPASS_1:         // H(s) = -------
                                    //         1 + S

                norma = 1.0/(1.0 + omega);
                BIQUAD::b0 = gain*omega*norma;
                BIQUAD::b1 = BIQUAD::b0;
                BIQUAD::b2 = 0.0;
                BIQUAD::a1 = (omega - 1.0)*norma;
                BIQUAD::a2 = 0.0;
                BIQUAD::Q  = 0.5;
                break;

                                    //           S
            case HIGHPASS_1:        // H(s) = -------
                                    //         1 + S

                norma = 1.0/(1.0 + omega);
                BIQUAD::b0 = gain*norma;
                BIQUAD::b1 = -BIQUAD::b0;
                BIQUAD::b2 = 0.0;
                BIQUAD::a1 = (omega - 1.0)*norma;
                BIQUAD::a2 = 0.0;
                BIQUAD::Q  = 0.5;
                break;

                                //              1
            case LOWPASS_2:     // H(s) = ---------------
                                //         s^2 + s/Q + 1

                norma  = 1.0/(srd(omega) + omega/Q + 1.0);
                BIQUAD::b0 = srd(omega)*norma*gain;
                BIQUAD::b1 = 2.0*BIQUAD::b0;
                BIQUAD::b2 = BIQUAD::b0;
                BIQUAD::a1 = 2.0*norma*(srd(omega) - 1.0);
                BIQUAD::a2 = norma*(srd(omega) - omega/Q  + 1.0);
                break;

                                //            s^2
            case HIGHPASS_2:    // H(s) = ---------------
                                //         s^2 + s/Q + 1

                norma  = 1.0/(srd(omega) + omega/Q + 1.0);
                BIQUAD::b0 = norma*gain;
                BIQUAD::b1 = -2.0*BIQUAD::b0;
                BIQUAD::b2 = BIQUAD::b0;
                BIQUAD::a1 = 2.0*norma*(srd(omega) - 1.0);
                BIQUAD::a2 = norma*(srd(omega) - omega/Q  + 1.0);
                break;
     
                                //              s/Q
            case BANDPASS:      // H(s) = ---------------
                                //         s^2 + s/Q + 1

                norma  = 1.0/(srd(omega) + omega/Q + 1.0);
                BIQUAD::b0 = omega*norma*gain/Q;
                BIQUAD::b1 = 0.0;
                BIQUAD::b2 = -BIQUAD::b0;
                BIQUAD::a1 = 2.0*norma*(srd(omega) - 1.0);
                BIQUAD::a2 = norma*(srd(omega) - omega/Q  + 1.0);
                break;
      
                                    //          s^2 + s*G/Q + 1
            case PARAMETRIC_EQ:     // H(s) = ------------------
                                    //          s^2 + s/Q + 1
                
                if(gain < 1.0) Q *= gain;  // Maintain 3-db bandwidth of boost and cut

                A = gain/Q;
                norma = 1.0/(srd(omega) + omega/Q + 1.0);
                BIQUAD::b0 = norma*(srd(omega) + A*omega + 1.0);
                BIQUAD::b1 = norma*2.0*(srd(omega) - 1.0);
                BIQUAD::b2 = norma*(srd(omega) - A*omega + 1.0)
                BIQUAD::a1 = BIQUAD::b1;
                BIQUAD::a2 = norma*(srd(omega) - omega/Q + 1.0);
                break;

                                    //              1
            case A1A2_LOWPASS:      // H(s) = --------------------
                                    //          1 + A1*S + A2*S^2

                norma = 1.0/(srd(omega) + A1*omega + A2);
                BIQUAD::b0 = srd(omega)*norma;
                BIQUAD::b1 = 2.0*BIQUAD::b0;
                BIQUAD::b2 = BIQUAD::b0;
                BIQUAD::a1 = 2.0*(srd(omega) - A2)*norma;
                BIQUAD::a2 = (srd(omega) - A1*omega + A2)*norma;
                break;
      
                                    //               S^2
            case A1A2_HIGHPASS:     // H(s) =  -----------------
                                    //          S^2 + A1*S + A2

                norma = 1.0/(1.0 +  A1*omega + A2*srd(omega));
                BIQUAD::b0 = norma;
                BIQUAD::b1 = -2.0*BIQUAD::b0;
                BIQUAD::b2 = BIQUAD::b0;
                BIQUAD::a1 = 2.0*(A2*srd(omega) - 1.0)*norma;
                BIQUAD::a2 = (1.0 - A1*omega + A2*srd(omega))*norma;
                break;

        }

        round_b0 = b0;
        round_b1 = b1;
        round_b2 = b2;
        round_a1 = a1;
        round_a2 = a2;

        // Round to fractional coeffs
        fract_b0 = FloatToFract_4_20(round_b0);
        fract_b1 = FloatToFract_4_20(round_b1);
        fract_b2 = FloatToFract_4_20(round_b2);
        fract_a1 = FloatToFract_4_20(round_a1);
        fract_a2 = FloatToFract_4_20(round_a2);

    };
     */
    public void DesignBiquad(BIQUAD_TYPE bt_arg, double fs_arg, double fc_arg, double Q_arg, float gain_db_arg){

        double omega; // warp factor
        double gain;
        double norma,A;
        double A1, A2;

        bt = bt_arg;
        fs = fs_arg;
        fc = fc_arg;
        Q  = Q_arg;
        gain_db = gain_db_arg;

        // Use for A1A2 design only
        A1 = Q;
        A2 = gain_db;

        omega = Math.tan(fc*Math.PI/fs);
        gain = Math.pow(10.0, gain_db/20.0);

        switch(bt){

            case FLAT:
                b0 = gain;
                b1 = 0.0;
                b2 = 0.0;
                a1 = 0.0;
                a2 = 0.0;
                Q  = 0.0;
                break;

                                    //           1
            case LOWPASS_1:         // H(s) = -------
                                    //         1 + S

                norma = 1.0/(1.0 + omega);
                b0 = gain*omega*norma;
                b1 = b0;
                b2 = 0.0;
                a1 = (omega - 1.0)*norma;
                a2 = 0.0;
                Q  = 0.5;
                break;

                                    //           S
            case HIGHPASS_1:        // H(s) = -------
                                    //         1 + S

                norma = 1.0/(1.0 + omega);
                b0 = gain*norma;
                b1 = -b0;
                b2 = 0.0;
                a1 = (omega - 1.0) * norma;
                a2 = 0.0;
                Q  = 0.5;
                break;

                                //              1
            case LOWPASS_2:     // H(s) = ---------------
                                //         s^2 + s/Q + 1

                norma  = 1.0/(miscutil.srd(omega) + omega/Q + 1.0);
                b0 = miscutil.srd(omega) * norma * gain;
                b1 = 2.0 * b0;
                b2 = b0;
                a1 = 2.0*norma*(miscutil.srd(omega) - 1.0);
                a2 = norma*(miscutil.srd(omega) - omega/Q  + 1.0);
                break;

                                //            s^2
            case HIGHPASS_2:    // H(s) = ---------------
                                //         s^2 + s/Q + 1

                norma  = 1.0/(miscutil.srd(omega) + omega/Q + 1.0);
                b0 = norma*gain;
                b1 = -2.0 * b0;
                b2 = b0;
                a1 = 2.0*norma*(miscutil.srd(omega) - 1.0);
                a2 = norma*(miscutil.srd(omega) - omega/Q  + 1.0);
                break;

                                //              s/Q
            case BANDPASS:      // H(s) = ---------------
                                //         s^2 + s/Q + 1

                norma  = 1.0/(miscutil.srd(omega) + omega/Q + 1.0);
                b0 = omega*norma*gain/Q;
                b1 = 0.0;
                b2 = -b0;
                a1 = 2.0*norma*(miscutil.srd(omega) - 1.0);
                a2 = norma*(miscutil.srd(omega) - omega/Q  + 1.0);
                break;

                                    //          s^2 + s*G/Q + 1
            case PARAMETRIC_EQ:     // H(s) = ------------------
                                    //          s^2 + s/Q + 1

                if(gain < 1.0) Q *= gain;  // Maintain 3-db bandwidth of boost and cut

                A = gain/Q;
                norma = 1.0/(miscutil.srd(omega) + omega/Q + 1.0);
                b0 = norma*(miscutil.srd(omega) + A*omega + 1.0);
                b1 = norma*2.0*(miscutil.srd(omega) - 1.0);
                b2 = norma*(miscutil.srd(omega) - A*omega + 1.0);
                a1 = b1;
                a2 = norma*(miscutil.srd(omega) - omega/Q + 1.0);
                break;

                                    //              1
            case A1A2_LOWPASS:      // H(s) = --------------------
                                    //          1 + A1*S + A2*S^2

                norma = 1.0/(miscutil.srd(omega) + A1*omega + A2);
                b0 = miscutil.srd(omega)*norma;
                b1 = 2.0 * b0;
                b2 = b0;
                a1 = 2.0*(miscutil.srd(omega) - A2)*norma;
                a2 = (miscutil.srd(omega) - A1*omega + A2)*norma;
                break;

                                    //               S^2
            case A1A2_HIGHPASS:     // H(s) =  -----------------
                                    //          S^2 + A1*S + A2

                norma = 1.0/(1.0 +  A1*omega + A2*miscutil.srd(omega));
                b0 = norma;
                b1 = -2.0 * b0;
                b2 = b0;
                a1 = 2.0*(A2*miscutil.srd(omega) - 1.0)*norma;
                a2 = (1.0 - A1*omega + A2*miscutil.srd(omega))*norma;
                break;

        }

        round_b0 = b0;
        round_b1 = b1;
        round_b2 = b2;
        round_a1 = a1;
        round_a2 = a2;

        // Round to fractional coeffs
        fract_b0 = miscutil.FloatToFract_4_20(round_b0);
        fract_b1 = miscutil.FloatToFract_4_20(round_b1);
        fract_b2 = miscutil.FloatToFract_4_20(round_b2);
        fract_a1 = miscutil.FloatToFract_4_20(round_a1);
        fract_a2 = miscutil.FloatToFract_4_20(round_a2);

    }
    /*
    void BIQUAD::GetFrqResponse(f64 &module_dB, f64 &phase_degree, f64 f_Hz){
        complx response;
        f64 omega;

        omega = 2.0*PI*f_Hz/fs;

        complx z1(cos(omega),sin(omega));         // Z^(-1)
        complx z2(cos(2.0*omega),sin(2.0*omega)); // Z^(-2)


        response = (b0 + (b1*z1) + (b2*z2))/(1.0 + (a1*z1) + (a2*z2));

        module_dB       = 20.0*log10(sqrt(srd(response.real()) + srd(response.imag())));
        phase_degree    = (180.0/PI)*atan2(response.imag(),response.real());
    }
    */
    public void GetFrqResponse(modphase arg, double f_Hz){

        //complx response;
        double omega;

        omega = 2.0*Math.PI*f_Hz/fs;

        Complex z1 = new Complex(Math.cos(omega),Math.sin(omega));         // Z^(-1)
        Complex z2 = new Complex(Math.cos(2.0*omega),Math.sin(2.0*omega)); // Z^(-2)

        //response = (b0 + (b1*z1) + (b2*z2))/(1.0 + (a1*z1) + (a2*z2));
        Complex denom = new Complex(z1.times(a1).plus(z2.times(a2)).plus(1.0));
        Complex numr = new Complex(z1.times(b1).plus(z2.times(b2)).plus(b0));
        Complex response = new Complex(numr.over(denom));

        //System.out.println("response = " + response.getReal() + ", " + response.getImag() + "\n");
        arg.modulus = 20.0*Math.log10(Math.sqrt(
                miscutil.srd(response.getReal()) +
                miscutil.srd(response.getImag())
                ));
        arg.phase = (180.0/Math.PI)*Math.atan2(response.getImag(),response.getReal());

    }

    /*
    // Get 15 bytes of 4.20 coeffs
    //
    void BIQUAD::GetQuantizedCoeffs(u8 *coeffs){
        Split24(coeffs,fract_b0);
        Split24(coeffs + 3,fract_b1);
        Split24(coeffs + 6,fract_b2);
        Split24(coeffs + 9,fract_a1);
        Split24(coeffs + 12,fract_a2);
    }
    */
    public void GetQuantizedCoeffs(byte coeffs[]){
        miscutil.Split24(coeffs, fract_b0, 0);
        miscutil.Split24(coeffs, fract_b1, 3);
        miscutil.Split24(coeffs, fract_b2, 6);
        miscutil.Split24(coeffs, fract_a1, 9);
        miscutil.Split24(coeffs, fract_a2, 12);
    }

    public void GetQuantizedCoeffs(byte coeffs[], int offset){
        miscutil.Split24(coeffs, fract_b0, 0 + offset);
        miscutil.Split24(coeffs, fract_b1, 3 + offset);
        miscutil.Split24(coeffs, fract_b2, 6 + offset);
        miscutil.Split24(coeffs, fract_a1, 9 + offset);
        miscutil.Split24(coeffs, fract_a2, 12 + offset);
    }

    /*
    // Get unquantized coeffs
    //
    void BIQUAD::GetCoeffs(f64 *coeffs){
        coeffs[0] = b0;
        coeffs[1] = b1;
        coeffs[2] = b2;
        coeffs[3] = a1;
        coeffs[4] = a2;
    }
    */
    public void GetCoeffs(double coeffs[]){
        coeffs[0] = b0;
        coeffs[1] = b1;
        coeffs[2] = b2;
        coeffs[3] = a1;
        coeffs[4] = a2;
    }

    public void GetCoeffs(double coeffs[], int offset){
        if ((0 + offset) < coeffs.length) coeffs[0 + offset] = b0;
        if ((1 + offset) < coeffs.length) coeffs[1 + offset] = b1;
        if ((2 + offset) < coeffs.length) coeffs[2 + offset] = b2;
        if ((3 + offset) < coeffs.length) coeffs[3 + offset] = a1;
        if ((4 + offset) < coeffs.length) coeffs[4 + offset] = a2;
    }
    
}
