//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************
 Name: MetaPicture.java
 Function: Association of an image with its meta data.
 Author: Sean Parsons
 Date: Spring 2010

 Description:


 ****************************************************************************/
//////////////////////////////////////////////////////////////////////////////

package metapicture;

import java.io.*;
import javax.swing.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;

import ij.*;
import ij.process.*;
import ij.io.*;
import ij.ImagePlus.*;
import ij.gui.*;
import ij.gui.Roi.*;
import ij.gui.Overlay;


import SPUtils.*;


public class MetaPicture extends MetaObject {
    
    //-------------------------------------------------------
    //DATA MEMBERS
   
    //IMAGES
    public ImagePlus OImage;   //original image
    public ImagePlus DImage;   //display image
    
    //ROIS AND TRANSFORM
    public ArrayList<Roi> rois;    //ImageJ Rois (in OImage coordinate space)
    private AffineTransform trans_OD;  //affine transform from OImage to Dimage
    private Overlay over;
    
    //--------------------------------------------------------
    //CONSTRUCTORS
    //default
    public MetaPicture(){
        
        //TYPE
        type = 1;
        
        //FILE INFO
        SetFileData("c:\\somefile.tif");
        
        //METADATA
        metadata = new MetaArray(fpath);
        CheckMinimumTags();
        SetPictureName();

        //IMAGES
        ByteProcessor ImageProc = new ByteProcessor(100, 100);
        OImage = new ImagePlus(picname, ImageProc);
        DImage = new ImagePlus(picname, ImageProc);
        
        //ROIS AND TRANSFORM
        rois = new ArrayList<Roi>();
        trans_OD = new AffineTransform();
        over = new Overlay();
       
    }

    //copy
    public MetaPicture(MetaPicture arg){
        
        //TYPE
        type = 1;

        //FILE INFO
        SetFileData(arg.fpath);
 
        //METADATA
        metadata = new MetaArray(arg.metadata);
        SetPictureName();

        //IMAGES
        OImage = new ImagePlus();
        OImage.setProcessor(picname, arg.OImage.getProcessor().duplicate());
        DImage = new ImagePlus();
        DImage.setProcessor(picname, arg.OImage.getProcessor().duplicate());

        //ROIS AND TRANSFORM
        trans_OD = new AffineTransform();
        rois = new ArrayList<Roi>();
        for (int i = 0; i < arg.rois.size(); i++)
            rois.add(arg.rois.get(i));
        over = new Overlay();
        for (int i = 0; i < arg.over.size(); i++)
            over.add(arg.over.get(i));

    }

    //from tiff
    public MetaPicture(String arg){
        
        //TYPE
        type = 1;

        //FILE INFO
        SetFileData(arg);
        
        //METADATA
        FileInfo myinfo[] = new FileInfo[1];
        TiffDecoder tiffe = new TiffDecoder(path, name + "." + ext);
        //try read file description
        try {
            myinfo = tiffe.getTiffInfo();
            //create MetaArray
            metadata = new MetaArray(myinfo[0].description, fpath);
        //if can't read.....
        }catch (IOException e){ 
            //basic set and set class ID
            metadata = new MetaArray(fpath);   
        }
        CheckMinimumTags();
        SetPictureName();

        //IMAGES
        OImage = new ImagePlus(fpath);
        DImage = new ImagePlus(fpath);
        OImage.setTitle(picname);
        DImage.setTitle(picname);
         
        //ROIS AND TRANSFORM
        rois = new ArrayList<Roi>();
        trans_OD = new AffineTransform();
        over = new Overlay();

    }
    
    //----------------------------------------------------------
    //CONSTRUCTOR-RELATED
    
    //adds any minimum tags for a picture that are missing
    public void CheckMinimumTags(){
        
        //ID
        if (metadata.FindIndex(MetaTagType.CLASS_ID) == -1) metadata.AddTag(MetaTagType.CLASS_ID, "METAPICTURE");
            else metadata.SetValueUnEditable(MetaTagType.CLASS_ID, "METAPICTURE");
        if (metadata.FindIndex(MetaTagType.UNIQ_ID) == -1) metadata.AddUniqID();
        if (metadata.FindIndex(MetaTagType.CREAT_P) == -1) metadata.AddTag(MetaTagType.CREAT_P, "ca imaging");
        if (metadata.FindIndex(MetaTagType.DATATYPE) == -1) metadata.AddTag(MetaTagType.DATATYPE, "linescan");
        if (metadata.FindIndex(MetaTagType.CREAT_D) == -1) metadata.AddTag(MetaTagType.CREAT_D, "???");
        if (metadata.FindIndex(MetaTagType.PARENT_ID) == -1) metadata.AddTag(MetaTagType.PARENT_ID, "???");
        //image dimensions
        if (metadata.FindIndex(MetaTagType.X_NAME) == -1) metadata.AddTag(MetaTagType.X_NAME, "time");
        if (metadata.FindIndex(MetaTagType.X_UNIT) == -1) metadata.AddTag(MetaTagType.X_UNIT, "s");
        if (metadata.FindIndex(MetaTagType.X_ORIGIN) == -1) metadata.AddTag(MetaTagType.X_ORIGIN, "0.0");
        if (metadata.FindIndex(MetaTagType.X_RES) == -1) metadata.AddTag(MetaTagType.X_RES, "1.0");
        if (metadata.FindIndex(MetaTagType.Y_NAME) == -1) metadata.AddTag(MetaTagType.Y_NAME, "space");
        if (metadata.FindIndex(MetaTagType.Y_UNIT) == -1) metadata.AddTag(MetaTagType.Y_UNIT, "microns");
        if (metadata.FindIndex(MetaTagType.Y_ORIGIN) == -1) metadata.AddTag(MetaTagType.Y_ORIGIN, "0.0");
        if (metadata.FindIndex(MetaTagType.Y_RES) == -1) metadata.AddTag(MetaTagType.Y_RES, "1.0");
        if (metadata.FindIndex(MetaTagType.A_NAME) == -1) metadata.AddTag(MetaTagType.A_NAME, "intensity");
        if (metadata.FindIndex(MetaTagType.A_UNIT) == -1) metadata.AddTag(MetaTagType.A_UNIT, "arb");
        if (metadata.FindIndex(MetaTagType.A_ORIGIN) == -1) metadata.AddTag(MetaTagType.A_ORIGIN, "0.0");
        if (metadata.FindIndex(MetaTagType.A_RES) == -1) metadata.AddTag(MetaTagType.A_RES, "1.0");
        if (metadata.FindIndex(MetaTagType.AN_RESV) == -1) metadata.AddTag(MetaTagType.AN_RESV, "0");
        
    }    

    //--------------------------------------------
    //IMAGE OUTPUT
    public void WriteData(String arg){

        //add to metdata to Image description
        FileInfo myinfo = OImage.getFileInfo();
        myinfo.description = myinfo.description + metadata.GetMetaString() + (char)0;
        
        try {
            
            //open output stream and tiff encoder
            FileOutputStream fos = new FileOutputStream(arg);
            TiffEncoder tiffe = new TiffEncoder(myinfo);
            //write file
            try {
                tiffe.write(fos);
            }catch (IOException e){}
            //close stream
            try {
                fos.close();
            } catch (IOException e){}

        }catch (FileNotFoundException e){}


    }

    //--------------------------------------------
    //IMAGE PROCESSORS
    
    //set DImage back to OImage
    public void SetToOriginal(){
        DImage.setProcessor(picname, OImage.getProcessor());
        trans_OD.setToIdentity();
    }

    //set both DImage and OImage
    public void SetBothProcessors(ImageProcessor arg){
        DImage.setProcessor(picname, arg);
        OImage.setProcessor(picname, arg);
        trans_OD.setToIdentity();
    }

    //set colour model[idx] to col
    public void SetColorModel(int idx, Color col){

        IndexColorModel cm = (IndexColorModel)OImage.getProcessor().getColorModel();
        int cs = cm.getMapSize();
        byte rc[] = new byte[cs];
        byte bc[] = new byte[cs];
        byte gc[] = new byte[cs];
        cm.getReds(rc);
        cm.getBlues(bc);
        cm.getGreens(gc);
        if (idx < cs){
            rc[idx] = (byte)col.getRed();
            bc[idx] = (byte)col.getBlue();
            gc[idx] = (byte)col.getGreen();
        }

        IndexColorModel nm = new IndexColorModel(8, cs, rc, bc, gc);
        OImage.getProcessor().setColorModel(nm);
        DImage.getProcessor().setColorModel(nm);

    }
    
    //--------------------------------------------
    //DIMAGE ADJUSTMENT
    public void ReSize(double xfac, double yfac){

        DImage.setProcessor(picname,
                OImage.getProcessor().resize((int)((double)OImage.getWidth() * xfac),
                                             (int)((double)OImage.getHeight() * yfac))
                            );

        trans_OD.setToScale(xfac, yfac);
        
    }

    public void RotateRight(){
        DImage.setProcessor(picname,
                OImage.getProcessor().rotateRight());

        trans_OD.setToRotation(0.5 * Math.PI, OImage.getWidth()/2, OImage.getHeight()/2);  
    }

    public void RotateLeft(){
        DImage.setProcessor(picname,
                OImage.getProcessor().rotateLeft());

        trans_OD.setToRotation(-0.5 * Math.PI, OImage.getWidth()/2, OImage.getHeight()/2); 
    }

    //-------------------------------------------
    //ROIs

    //add..
    //...which is scaled to OImage
    public void AddROI(Roi arg){
        rois.add(arg);
    }
    //...which is scaled to DImage
    public void AddROI_fromDimage(Roi arg){
        rois.add(GetTransROI(false, arg)); 
    }

    //clear
    public void ClearRois(){
        rois.clear();
    }
    
    //get..
    public Roi GetROI(int idx){
        if ((idx > 0) && (idx < rois.size()))
            return rois.get(idx);
        return null;
    }
    public Roi GetROI(){
        return GetROI(rois.size()-1); 
    }
    
    //get number of ROIs
    public int GetNRois(){
        return rois.size();
    }

    //set properties...
    public void SetROIProperties(int idx, int colourindex, int width){
        if ((idx >= 0) && (idx < rois.size())){
            rois.get(idx).setStrokeColor(new Color(colourindex, colourindex, colourindex));
            rois.get(idx).setStrokeWidth(width);
        }
    }
    public void SetROIProperties(int colourindex, int width){
        SetROIProperties(rois.size()-1, colourindex, width);
    }
    public void SetROIProperties(int idx, Color colourindex, int width){
        if ((idx >= 0) && (idx < rois.size())){
            rois.get(idx).setStrokeColor(new Color(colourindex.getRed(), colourindex.getGreen(), colourindex.getBlue()));
            rois.get(idx).setStrokeWidth(width);
        }
    }
    public void SetROIProperties(Color colourindex, int width){
        SetROIProperties(rois.size()-1, colourindex, width);
    }
    public void SetROIName(int idx, String arg){
        if ((idx >= 0) && (idx < rois.size())){
           rois.get(idx).setName(arg); 
        }
    }
    public void SetROIName(String arg){
        SetROIName(rois.size()-1, arg);
    }
    
    //get properties
    public int GetROIColourIndex(int idx){
        if ((idx >= 0) && (idx < rois.size()))
            return rois.get(idx).getStrokeColor().getRed();
        return -1;
    }
    public Color GetROIColour(int idx){
        if ((idx >= 0) && (idx < rois.size()))
            return rois.get(idx).getStrokeColor();
        return Color.RED;
    }
    
    //return Roi arg transformed
    //OToD = true, OImage -> DImage
    //OToD = false, DImage -> OImage
    public Roi GetTransROI(boolean OToD, Roi arg){

        PolygonRoi d_polygon;

        int t = arg.getType();

        switch (t){

            //RECTANGLE (class Roi)
            case 0:

                //transform
                Roi d_rect = new Roi (GetTransRect(OToD, arg.getBounds()));
                return d_rect;

            //OVAL (class OvalRoi)
            case 1:

                //transform
                Rectangle oval = GetTransRect(OToD, arg.getBounds());
                OvalRoi d_oval = new OvalRoi(oval.x, oval.y, oval.width, oval.height);
                return d_oval;

            //POLYGON (class PolygonRoi)
            case 2:

                //transform
                d_polygon = new PolygonRoi(GetTransPoly(OToD, arg.getPolygon()), 2);
                return d_polygon;

            //FREE ROI (class FreehandRoi)
            case 3:

                //transform
                d_polygon = new PolygonRoi(GetTransPoly(OToD, arg.getPolygon()), 3);
                return d_polygon;

            //LINE (class Line)
            case 5:
                
                //get coordinates
                Line o_line = (Line)arg;
                double o_linearr[] = {o_line.x1, o_line.y1, o_line.x2, o_line.y2};
                double d_linearr[] = new double[4];

                //transform
                ROITransform(OToD, o_linearr, d_linearr, 2);

                //set
                Line d_line = new Line(d_linearr[0], d_linearr[1], d_linearr[2], d_linearr[3]);
                return d_line;

            //POLYLINE (class PolygonRoi)
            case 6:
                
                //transform
                d_polygon = new PolygonRoi(GetTransPoly(OToD, arg.getPolygon()), 6);
                return d_polygon;

            //FREE LINE (class FreehandRoi)
            case 7:

                //transform
                d_polygon = new PolygonRoi(GetTransPoly(OToD, arg.getPolygon()), 7);
                return d_polygon;

            //POINT (class PointRoi)
            case 10:

                Polygon d_poly = GetTransPoly(OToD, arg.getPolygon());
                PointRoi d_pnt = new PointRoi(d_poly.xpoints, d_poly.ypoints, d_poly.npoints);
                return d_pnt;

        }

       return new Roi(0, 0, 50, 20);

    }

    //does affine transform (see GetTransROI, above)
    public void ROITransform(boolean IsForward, double[] o_arr, double[] d_arr, int n){

        if (IsForward == true)
            trans_OD.transform(o_arr, 0, d_arr, 0, n);
        else {
            
            try {
                trans_OD.inverseTransform(o_arr, 0, d_arr, 0, n);
            }catch(NoninvertibleTransformException e){
                for(int i = 0; i < o_arr.length; i++) o_arr[i] = d_arr[i];
            }

        }
            
         
    }
    
    //Polygon(int x[], int y[]) -> double[x1, y1, x2, y2, .... xn, yn]
    public double[] GetTransCoor(Polygon arg){
        
        int n = arg.npoints;
        double val[] = new double[n*2];

        for(int i = 0; i < n; i++){
            val[i*2] = arg.xpoints[i];
            val[(i*2) + 1] = arg.ypoints[i];
        }
        
        return val;
        
    }
    
    //double[x1, y1, x2, y2, .... xn, yn] -> Polygon(int x[], int y[])
    public Polygon GetPolyCoor(double[] arg){
        
        int n = (int)Math.floor((double)arg.length / 2);
        Polygon val = new Polygon();

        for(int i = 0; i < n; i++){
            val.addPoint((int)arg[i*2], (int)arg[(i*2)+1]);
        }
        
        return val;

    }

    //transform Polygon
    public Polygon GetTransPoly(boolean IsForward, Polygon arg){

        //get coordinates
        double o_polygonarr[] = GetTransCoor(arg);
        int len = o_polygonarr.length;
        double d_polygonarr[] = new double[len];

        //transform
        ROITransform(IsForward, o_polygonarr, d_polygonarr, len/2);

        return GetPolyCoor(d_polygonarr);

    }
    
    //transform bounds Rectangle
    public Rectangle GetTransRect(boolean IsForward, Rectangle arg){
        
        //get coordinates
        double o_rectarr[] = {arg.x, arg.y, arg.x + arg.width, arg.y + arg.height};
        double d_rectarr[] = new double[4];

        //transform
        ROITransform(IsForward, o_rectarr, d_rectarr, 2);
        
        return new Rectangle((int)d_rectarr[0],
                             (int)d_rectarr[1],
                             (int)(d_rectarr[2] - d_rectarr[0]),
                             (int)(d_rectarr[3] - d_rectarr[1]));
        
    }

    //drawing....
    //...on graphics object (doesn't actually do this!
    public void DrawAllROIs(Graphics g){

        over.clear();
        Roi mr;

        for(int i = 0; i < rois.size(); i++){
            mr = GetTransROI(true, rois.get(i));
            mr.setStrokeColor(GetROIColour(i));
            over.add(mr);
        }

        DImage.setOverlay(over);
        DImage.updateAndDraw();

    }
    //...on current image
    public void DrawAllROIs(){

        over.clear();
        Roi mr;

        for(int i = 0; i < rois.size(); i++){
            mr = GetTransROI(true, rois.get(i));
            mr.setStrokeColor(GetROIColour(i));
            over.add(mr);
        }

        DImage.setOverlay(over);
        DImage.updateAndDraw();

    }

    //--------------------------------------------
    //DISPLAY
    public ImageIcon getIcon(){
        return new ImageIcon(DImage.getBufferedImage());
    }
    
    public void Show(){ 
        DImage.show();
    }

    public void Hide(){
        DImage.hide();
    }

    public void UpdateAndDraw(){
        DImage.updateAndDraw();
    }

    //--------------------------------------------------
            
}




