/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package frequency;

/**
 *
 * @author Sean
 */
public enum Dimension_Type {

    X("x"),
    Y("y"),
    XY("xy");

    //MEMBERS
    private String description;

    //CNSTR
    Dimension_Type(String description_arg){
        description = description_arg;
    }

    //GET
    String GetDescription(){
        return description;
    }
}
