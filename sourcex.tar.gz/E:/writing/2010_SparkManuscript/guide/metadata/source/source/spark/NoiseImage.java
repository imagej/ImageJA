/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package spark;


import metapicture.*;
import SPUtils.*;

import ij.process.*;
import javax.swing.*;
import java.awt.*;

import ij.gui.*;

import flanagan.math.*;

public class NoiseImage extends SwingWorker<Boolean, Void>{


    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture output[];    //array of output picture

    int iw;         //image width and height
    int ih;
    int n;          //number of images
    double base;    //base
    double mean;    //mean of Poisson distribution


    public NoiseImage(sparkpanel parent_arg){

        parent = parent_arg;

        iw = 512;
        ih = 512;
        n = 1;
        base = 10;
        mean = 5;

    }

    void SetVariables(int iw_arg, int ih_arg, int n_arg, double base_arg, double mean_arg){

        if(iw_arg > 0) iw = iw_arg;
        if(ih_arg > 0) ih = ih_arg;
        if(n_arg > 0) n = n_arg;
        if(base_arg > 0) base = base_arg;
        if(mean_arg > 0) mean = mean_arg;

    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {


        //array of output images
        output = new MetaPicture[n];
        for(int i = 0; i < n; i++) output[i] = new MetaPicture();

        //random number generator
        PsRandom ran = new PsRandom();

        //loop through images
        for(int i = 0; i < n; i++){

            //create processor
            FloatProcessor ip = new FloatProcessor(iw, ih);

            //put in values
            for(int p = 0; p < ip.getPixelCount(); p++)
                ip.setf(p, (float)(base + ran.nextPoissonian(mean)));

            //set output processors
            ip.setMinAndMax(base - mean, base + (mean*5));
            output[i].SetBothProcessors(ip);

            //metadata
            output[i].metadata.SetValueUnEditable(MetaTagType.PARENT_ID, "");
            output[i].metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Noise Image");
            output[i].metadata.SetValueUnEditable(MetaTagType.DATATYPE, "Poisson Noise");

            output[i].metadata.SetValueUnEditable(MetaTagType.X_NAME, "time");
            output[i].metadata.SetValueUnEditable(MetaTagType.X_UNIT, "sec");
            output[i].metadata.SetValueUnEditable(MetaTagType.Y_NAME, "space");
            output[i].metadata.SetValueUnEditable(MetaTagType.Y_UNIT, "microns");
            output[i].metadata.SetValueUnEditable(MetaTagType.A_NAME, "intensity");
            output[i].metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, "0.0");
            output[i].metadata.SetValueUnEditable(MetaTagType.A_RES, "1.0");
            output[i].metadata.SetValueUnEditable(MetaTagType.A_UNIT, "arb");

            output[i].name = "PoissonNoise_" + MetaUtils.IntToStr(i);
            output[i].SetFilePath();
            output[i].SetPictureName();


        }


        //return
        return true;

    }

    @Override
    public void done() {

          parent.WhenNoiseDone();

    }


}
