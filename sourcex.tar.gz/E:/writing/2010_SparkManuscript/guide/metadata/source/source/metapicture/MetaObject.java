//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************
 Name: MetaObject.java
 Function: Defines minimum methods for MetaPicture, MetaTrace, etc
 Author: Sean Parsons
 Date: Spring 2010

 Description:


 ****************************************************************************/
//////////////////////////////////////////////////////////////////////////////
package metapicture;

import SPUtils.*;

abstract public class MetaObject {
    
    //TYPE
    //0 = MetaObject
    //1 = MetaPicture
    //2 = MetaTable
    public int type;
    
    //FILE INFO
    public String fpath;       //filepath
    public String path;        //path
    public String name;        //name
    public String ext;         //extension
    public String picname;     //title for display window

    
    //METADATA
    public MetaArray metadata;  //meta data

    //CNSTR

    //default
    MetaObject(){
        
        //TYPE
        type = 0;
        
        //FILE INFO
        fpath = "c:\\somefile.xxx";
        SetFileData();

        //(don't intiate metadata, so subclasses can initiate by themselves)
        
    }

    //from file name
    MetaObject(String FileArg){

        //TYPE
        type = 0;

        //FILE INFO
        fpath = FileArg;
        SetFileData();

        //METADATA
        SetMetaData();
  
    }

    //FINAL METHODS
    final public void SetFileData(){
        path = MetaUtils.GetFilePath(fpath);
        name = MetaUtils.GetFileName(fpath);
        ext = MetaUtils.GetFileExtension(fpath);
    }

    final public void SetFilePath(){
        fpath = path + name + "." + ext;
    }

    final public void SetFileData(String Filearg){
        fpath = Filearg;
        SetFileData();
    }

     //set display name
    final public void SetPictureName(){
        picname = name + " (" + metadata.GetValue(MetaTagType.DATATYPE) + ")";
    }

    final public void SetMetaData(){
        metadata = new MetaArray(fpath);  
    };

    //OVERRIDDEN METHODS
    //write data out
    abstract public void WriteData(String arg);

    //check minimum contingent of meta tags
    abstract public void CheckMinimumTags();

    //abstract show() and hide()???

}
