/*
 An IIR filter library, translated from the c++ code of Vladimir L. Vassilevsky.
 *
 * Sean Parsons, April 2010
 *
 * BIQUAD.java
 * FILTER.java
 *
 * BIQUAD_TYPE.java
 * FILTER_FUNCTION.java
 * FILTER_TYPE.java
 *
 * bessel_tables.java
 * misutil.java
 * modphase.java (added by SP)
 *
 *
 */

/*
 * class FILTER
{
    FILTER_TYPE filter_type;
    FILTER_FUNCTION filter_function;

    u32 order;           // order
    u32 num_of_sections; // number of biquad sections in filter
    f64 fs;             // sample rate
    f64 fc;             // cutoff

    BIQUAD **bq; // array of pointers

    void Deallocate(void);
    void Allocate(void);

public:
    FILTER();
    ~FILTER();
    void DesignFilter(FILTER_TYPE filter_type,FILTER_FUNCTION filter_function, f64 fs, f64 fc, u32 order);
    void DesignEQFilter(f64 fs, f64 fc, f64 Q, f64 gain_dB);
    void GetFrqResponse(f64 &module_dB, f64 &phase_degree, f64 f);
    u32 GetQuantizedCoeffs(u8 *coeffs); // returns number_of_sections; each section is 15 bytes
    u32 GetCoeffs(f64 *coeffs); //  returns number_of_sections; each section is 5 coeffs
    u32 GetNumSections(void); // returns number of biquad filter sections;
    };
 */

package vvfilter;

import flanagan.complex.*;

public class FILTER{

    FILTER_TYPE filter_type;
    FILTER_FUNCTION filter_function;

    int order;             // order
    int num_of_sections;   // number of biquad sections in filter
    double fs;             // sample rat
    double fc;             // cutoff

    BIQUAD bq[];         // array of pointers

    /*
    void FILTER::Deallocate(void){
        int ci;
        for(ci = 0;ci < FILTER::num_of_sections;ci++) delete bq[ci];
        delete bq;
    }
    */
    void Deallocate(){
     
        
    }
    
    /*
    void FILTER::Allocate(void){
        int ci;
        bq = new BIQUAD *[num_of_sections];
        for(ci = 0;ci < FILTER::num_of_sections;ci++) FILTER::bq[ci] = new BIQUAD;
    }
    */
    void Allocate(){
        bq = new BIQUAD[num_of_sections];
        for(int i = 0; i < num_of_sections; i++) bq[i] = new BIQUAD();
    }

    /*
    FILTER::FILTER(){
        filter_type = FLAT_FILTER;
        filter_function = NO_FILTERING;
        order = 1;
        num_of_sections = 1;
        fs = SAMPLE_RATE;
        fc = fs/2.0;

        bq  = new BIQUAD *;
        *bq = new BIQUAD;

        (*bq)->DesignBiquad(FLAT,fs,fc,0.0,0.0);
    }
    */
    public FILTER(){
        filter_type = FILTER_TYPE.FLAT_FILTER;
        filter_function = FILTER_FUNCTION.NO_FILTERING;
        order = 1;
        num_of_sections = 1;
        fs = 48000.0;   //(const in c++ code, filter_design.h)
        fc = fs/2.0;
        
        bq = new BIQUAD[1];  //????

    }
    
    //~FILTER(); THIS IS JAVA!

    /*
    void FILTER::DesignFilter(FILTER_TYPE filter_type,FILTER_FUNCTION filter_function, f64 fs, f64 fc, u32 order){

        u32 ci;
        f64 fi_step;
        f64 A1,A2;
        BIQUAD_TYPE bt;

        // Clean garbage first
        FILTER::Deallocate();

        FILTER::fs = fs;
        FILTER::fc = fc;
        if(!order) order = 1;
        FILTER::order = order;
        FILTER::num_of_sections = (u32)ceil(order/2.0);
        FILTER::filter_type = filter_type;
        FILTER::filter_function = filter_function;

        // Design filter
        switch(filter_type){
            case FLAT_FILTER:
                FILTER::Allocate();
                FILTER::fc = fc = fs/2.0;
                FILTER::filter_function = filter_function = NO_FILTERING;
                for(ci = 0;ci < FILTER::num_of_sections;ci++) bq[ci]->DesignBiquad(FLAT,fs,fc,0.0,0.0);
                break;

            case BUTTERWORTH:
                FILTER::Allocate();
                fi_step = PI/(2.0*order);
                for(ci = 0;ci < FILTER::num_of_sections;ci++){

                    // Compute Q of Butterworth section
                    // Note: high Q sections first for better SNR

                    f64 fi = fi_step*(2*ci + 3*order + 1);

                    complx s(cos(fi),sin(fi));
                    complx q = s/((s*s) + 1.0);

                    f64 Q = q.real();

                    // Design filter section

                    switch(filter_function){

                        case LPF:
                            // If filter order is odd, last section is 1-st order
                            if((order&1)&&(ci == (FILTER::num_of_sections - 1))){
                                bt = LOWPASS_1;
                                Q = 0.5;
                            } else  bt = LOWPASS_2;
                            break;

                        case HPF:
                            // If filter order is odd, last section is 1-st order
                            if((order&1)&&(ci == (FILTER::num_of_sections - 1))){
                                bt = HIGHPASS_1;
                                Q = 0.5;
                            } else  bt = HIGHPASS_2;
                            break;

                    }

                    bq[ci]->DesignBiquad(bt,fs,fc,Q,0.0);
                }
                break; // End of Butterworth

            case LINKWITZ_RILEY:

                // LR filter should be even order!
                if(order&1) order++;
                FILTER::order = order;
                FILTER::num_of_sections = order/2;
                FILTER::Allocate();

                switch(filter_function){

                    case LPF:
                        bt = LOWPASS_2;
                        break;

                    case HPF:
                        bt = HIGHPASS_2;
                        break;

                }

                fi_step = PI/order;
                for(ci = 0;ci < FILTER::num_of_sections;ci += 2){

                    // Compute Q of each Butterworth section of LR filter
                    // Note: high Q sections first for better SNR

                    f64 fi = fi_step*(ci + 3*order/2 + 1);
                    complx s(cos(fi),sin(fi));
                    complx q = s/((s*s) + 1.0);
                    f64 Q = q.real();

                    // Take care of last section if odd number of sections
                    bq[ci]->DesignBiquad(bt,fs,fc,Q,0.0);

                    if((ci+1) < FILTER::num_of_sections) bq[ci+1]->DesignBiquad(bt,fs,fc,Q,0.0);

                }
                break; // End of Linkwitz - Riley

            //
            // Note: Bessel is designed using BLT.
            // The fase is linear if fc is much less then fs/2
            // Table supports Bessel up to 12-th order
            //
            case BESSEL:

                if(order > 12) order = 12;
                FILTER::order = order;
                FILTER::num_of_sections = (u32)ceil(order/2.0);
                FILTER::Allocate();

                switch(filter_function){

                    case LPF:
                        bt = A1A2_LOWPASS;
                        break;

                    case HPF:
                        bt = A1A2_HIGHPASS;
                        break;

                }

                const f64 *ptr = bessel_table[order-1];
                for(ci = 0;ci < FILTER::num_of_sections;ci++){

                    A1 = *ptr++;
                    A2 = *ptr++;
                    bq[ci]->DesignBiquad(bt,fs,fc,A1,A2);
                }
                break; // end of Bessel

        }
     
    }
     */
    public void DesignFilter(FILTER_TYPE filter_type_arg ,FILTER_FUNCTION filter_function_arg , double fs_arg, double fc_arg, int order_arg){

        int ci;
        double fi_step;
        double A1,A2;
        BIQUAD_TYPE bt = BIQUAD_TYPE.FLAT;  //(not initialised in orginal c++ code)

        // Clean garbage first
        Deallocate();

        fs = fs_arg;
        fc = fc_arg;
        if(order_arg == 0) order_arg = 1;
        order = order_arg;
        num_of_sections = (int)Math.ceil(order/2.0);

        filter_type = filter_type_arg;
        filter_function = filter_function_arg;

        // Design filter
        switch(filter_type){
            case FLAT_FILTER:
                Allocate();
                fc = fs_arg/2.0;
                filter_function = FILTER_FUNCTION.NO_FILTERING;
                for(ci = 0;ci < num_of_sections;ci++) bq[ci].DesignBiquad(BIQUAD_TYPE.FLAT,fs,fc,0.0,0.0f);
                break;

            case BUTTERWORTH:
                Allocate();
                fi_step = Math.PI/(2.0*order);
                for(ci = 0;ci < num_of_sections;ci++){

                    // Compute Q of Butterworth section
                    // Note: high Q sections first for better SNR

                    double fi = fi_step*(2*ci + 3*order + 1);

                    //complx s(cos(fi),sin(fi));    ///!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //complx q = s/((s*s) + 1.0);
                    //double Q = q.real();
                    Complex s = new Complex(Math.cos(fi), Math.sin(fi));
                    Complex q = new Complex(s.times(s).plus(1.0));
                    q = s.over(q);
                    double Q = q.getReal();
                    
                    // Design filter section
                    switch(filter_function){

                        case LPF:
                            // If filter order is odd, last section is 1-st order
                            if(((order & 1) != 0) && (ci == (num_of_sections - 1))){
                                bt = BIQUAD_TYPE.LOWPASS_1;
                                Q = 0.5;
                            } else  bt = BIQUAD_TYPE.LOWPASS_2;
                            break;

                        case HPF:
                            // If filter order is odd, last section is 1-st order
                            if(((order & 1) != 0) && (ci == (num_of_sections - 1))){
                                bt = BIQUAD_TYPE.HIGHPASS_1;
                                Q = 0.5;
                            } else  bt = BIQUAD_TYPE.HIGHPASS_2;
                            break;

                    }

                    bq[ci].DesignBiquad(bt,fs,fc,Q,0.0f);
                }
                break; // End of Butterworth

            case LINKWITZ_RILEY:

                // LR filter should be even order!
                if((order & 1) !=  0) order++;
                //FILTER::order = order;
                num_of_sections = order/2;
                Allocate();

                switch(filter_function){

                    case LPF:
                        bt = BIQUAD_TYPE.LOWPASS_2;
                        break;

                    case HPF:
                        bt = BIQUAD_TYPE.HIGHPASS_2;
                        break;

                }

                fi_step = Math.PI/order;
                for(ci = 0; ci < num_of_sections; ci += 2){

                    // Compute Q of each Butterworth section of LR filter
                    // Note: high Q sections first for better SNR

                    double fi = fi_step*(ci + 3*order/2 + 1);

                    //complx s(cos(fi),sin(fi));
                    //complx q = s/((s*s) + 1.0);
                    //double Q = q.real();
                    Complex s = new Complex(Math.cos(fi), Math.sin(fi));
                    Complex q = new Complex(s.times(s).plus(1.0));
                    q = s.over(q);
                    double Q = q.getReal();

                    // Take care of last section if odd number of sections
                    bq[ci].DesignBiquad(bt,fs,fc,Q,0.0f);

                    if((ci+1) < num_of_sections) bq[ci+1].DesignBiquad(bt,fs,fc,Q,0.0f);

                }
                break; // End of Linkwitz - Riley

            //
            // Note: Bessel is designed using BLT.
            // The fase is linear if fc is much less then fs/2
            // Table supports Bessel up to 12-th order
            //
            case BESSEL:

                if(order > 12) order = 12;
                //FILTER::order = order;
                num_of_sections = (int)Math.ceil(order/2.0);
                Allocate();
                
                switch(filter_function){

                    case LPF:
                        bt = BIQUAD_TYPE.A1A2_LOWPASS;
                        break;

                    case HPF:
                        bt = BIQUAD_TYPE.A1A2_HIGHPASS;
                        break;

                }
                /*
                const f64 *ptr = bessel_table[order-1];
                for(ci = 0;ci < FILTER::num_of_sections;ci++){

                    A1 = *ptr++;
                    A2 = *ptr++;
                    bq[ci]->DesignBiquad(bt,fs,fc,A1,A2);
                }
                 *
                 */

                double ptr[] = bessel_tables.bessel_table[order-1];
                
                for(ci = 0; ci < num_of_sections; ci++){

                    A1 = ptr[ci*2];
                    A2 = ptr[(ci*2) + 1];
                    bq[ci].DesignBiquad(bt,fs,fc,A1,(float)A2);
                    //System.out.println("biquad " + ci + "\n");
                    //bq[ci].print();
                }
                break; // end of Bessel

        }
        
    }

    /*
     * //-----------------------------------------------------
    // Design parametric EQ one section filter
    //
    void FILTER::DesignEQFilter(f64 fs, f64 fc, f64 Q, f64 gain_dB)
    {

        // Clean garbage first
        FILTER::Deallocate();

        FILTER::fs = fs;
        FILTER::fc = fc;
        FILTER::order = 2;
        FILTER::num_of_sections = 1;
        FILTER::filter_type = EQUALIZER;
        FILTER::filter_function = EQ;
        FILTER::Allocate();

        if((Q > 0.0)&&(gain_dB != 0.0)) bq[0]->DesignBiquad(PARAMETRIC_EQ,fs,fc,Q,gain_dB);
        else bq[0]->DesignBiquad(FLAT,fs,fc,Q,gain_dB);

    }
     */
    void DesignEQFilter(double fs_arg, double fc_arg, double Q, double gain_dB){
        

        fs = fs_arg;
        fc = fc_arg;
        order = 2;
        num_of_sections = 1;
        filter_type = FILTER_TYPE.EQUALIZER;
        filter_function = FILTER_FUNCTION.EQ;
        Allocate();

        if((Q > 0.0) && (gain_dB != 0.0)) bq[0].DesignBiquad(BIQUAD_TYPE.PARAMETRIC_EQ,fs,fc,Q,(float)gain_dB);
        else bq[0].DesignBiquad(BIQUAD_TYPE.FLAT, fs, fc, Q, (float)gain_dB);

    }

    /*
     *
    //-----------------------------------------
    // Get filter response at frequency f -> gain(dB) and phase(degrees)
    //
    void FILTER::GetFrqResponse(f64 &module_dB, f64 &phase_degree, f64 f){
        u32 ci;
        f64 module, phase;

        module_dB = 0.0;
        phase_degree = 0.0;

        // Calculate overall response

        for(ci = 0;ci < num_of_sections; ci++)
        {
            bq[ci]->GetFrqResponse(module,phase,f);
            module_dB += module;
            phase_degree += phase;
        }

        // Truncate phase to +/- 180 degree range

        TruncatePhaseDegrees(phase_degree);
    };
     */
    public void GetFrqResponse(modphase arg, double f){

        modphase mparr = new modphase();

        arg.modulus = 0.0;
        arg.phase = 0.0;

        // Calculate overall response

        for(int ci = 0; ci < num_of_sections; ci++)
        {
            bq[ci].GetFrqResponse(mparr,f);
            //System.out.println("module = " + mparr.modulus + "\tphase = " + mparr.phase + "\n");
            arg.modulus += mparr.modulus;
            arg.phase += mparr.phase;
        }

        // Truncate phase to +/- 180 degree range
        arg.phase = miscutil.TruncatePhaseDegrees(arg.phase);
        
    }

    /*
    // returns number of filter biquad sections
    //
    u32 FILTER::GetQuantizedCoeffs(u8 *coeffs){
        u32 ci;


        for(ci = 0; ci < FILTER::num_of_sections; ci++){
            bq[ci]->GetQuantizedCoeffs(coeffs);
            coeffs += 15;
        }

        return FILTER::num_of_sections;
     }
     */
    // returns number_of_sections; each section is 15 bytes
    int GetQuantizedCoeffs(byte coeffs[]){

        for(int ci = 0; ci < num_of_sections; ci++){
            if ((ci * 15) < coeffs.length) bq[ci].GetQuantizedCoeffs(coeffs, ci * 15);
        }

        return num_of_sections;
    }

    /*
    // returns number of filter biquad sections
    //
    u32 FILTER::GetCoeffs(f64 *coeffs){
        u32 ci;


        for(ci = 0; ci < FILTER::num_of_sections; ci++){
            bq[ci]->GetCoeffs(coeffs);
            coeffs += 5;
        }

        return FILTER::num_of_sections;
     }
     */
    //  returns number_of_sections; each section is 5 coeffs
    int GetCoeffs(double coeffs[]){

        for(int ci = 0; ci < num_of_sections; ci++){
            if ((ci * 5) < coeffs.length) bq[ci].GetCoeffs(coeffs, ci*5);
        }

        return num_of_sections;
        
    }
    /*
     * // returns number of filter biquad sections
     //
    u32 FILTER::GetNumSections(void)
    {
        return FILTER::num_of_sections;
    }
     */
    // returns number of biquad filter sections;
    int GetNumSections(){
        return num_of_sections;
    }
    
    
}

