/*
 *
 * Applies Izu delining method
 *
 * Izu et al. (1998) Theoretical Analysis of the Ca21 Spark Amplitude
   Distribution. Biophysical Journal 75, 1144–1162.
 *
 * Sean Parsons, April 2010
 *
 */

package spark;

import metapicture.*;
import SPUtils.MetaUtils.*;

import javax.swing.*;
import ij.process.*;
import edu.emory.mathcs.jtransforms.fft.*;
/**
 *
 * @author Sean
 */
public class IzuDeline extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)

    public IzuDeline(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;

        //output picture?
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Delined");
        output.name = output.name + "_" + "Delined";
        output.SetFilePath();
        output.SetPictureName();

    }

    void SetVariables(){

    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //dimensions
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();

        //fft object
        FloatFFT_1D trans = new FloatFFT_1D(xl);

        //array for holding data to be transformed
        float hold[] = new float[xl];

        //loop through rows
        for (int j = 0; j < yl; j++){

            //get data and sum
            for(int i = 0; i < xl; i++)
                hold[i] = imp.getf(i, j);
 
            //transform
            trans.realForward(hold);

            //zero zero frequency
            hold[0] = 0;
       
            //inverse transform
            trans.realInverse(hold, true);

            //put data back
            for(int i = 0; i < xl; i++)
                imp_o.setf(i, j, hold[i]);
                    

        }

        //find mean of input and output
        float mean_input = 0;
        float mean_output = 0;
        float total = (float)(xl * yl);
        for (int j = 0; j < yl; j++)
            for (int i = 0; i < xl; i++){
                mean_input += (imp.getf(i, j)/total);
                mean_output += (imp_o.getf(i, j)/total);
            }

        //calculate difference
        float diff = mean_output - mean_input;

        //subtract difference, set values < 0 to 1
        for (int j = 0; j < yl; j++)
            for (int i = 0; i < xl; i++){
                imp_o.setf(i, j, imp_o.getf(i, j) - diff);
                if (imp_o.getf(i, j) < 0) imp_o.setf(i, j, 1);
            }

        //if input was 8bit, set  min, max to 0, 255
        if (input.OImage.getBytesPerPixel() == 1) imp_o.setMinAndMax(0, 255);

        //set output processors to OImage
        output.SetToOriginal();

        return true;

    }

    @Override
    public void done() {

          parent.WhenDelineDone();

    }


}
