/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package spark;


import metapicture.*;
import SPUtils.*;

import ij.process.*;
import javax.swing.*;
import java.awt.*;

import ij.gui.*;

public class ScanCrop extends SwingWorker<Boolean, Void>{


    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)


    public ScanCrop(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;

        //output picture?
        output = new MetaPicture(input);
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Crop");
        output.name = output.name + "_" + "Cropped";
        output.SetFilePath();
        output.SetPictureName();

    }

    void SetVariables(){

    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //input and output image processors
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        
        //get roi of input DImage, scaled to input OImage
        Roi croi = input.GetTransROI(false, input.DImage.getRoi());

        //if croi is null set to entire image
        if (croi == null) croi = new Roi(0, 0, input.OImage.getWidth(), input.OImage.getHeight());

        //apply this roi to input OImage
        imp.setRoi(croi);
        
        //set both output images to cropped input OImage
        output.SetBothProcessors (imp.crop());
        
        //reset x/y origins of output
        Rectangle b = croi.getBounds();
        double xo = MetaUtils.StrToDbl(output.metadata.GetValue(MetaTagType.X_ORIGIN));
        double yo = MetaUtils.StrToDbl(output.metadata.GetValue(MetaTagType.Y_ORIGIN));
        double xr = MetaUtils.StrToDbl(output.metadata.GetValue(MetaTagType.X_RES));
        double yr = MetaUtils.StrToDbl(output.metadata.GetValue(MetaTagType.Y_RES));
        xo += (xr * b.x);
        yo += (yr * b.y);
        output.metadata.SetValue(MetaTagType.X_ORIGIN, MetaUtils.DblToStr(xo));
        output.metadata.SetValue(MetaTagType.Y_ORIGIN, MetaUtils.DblToStr(yo));

        //set colour lut of output DImage
        output.DImage.getProcessor().setColorModel(input.DImage.getProcessor().getCurrentColorModel());

        //return
        return true;

    }

    @Override
    public void done() {

          parent.WhenCropDone();

    }


}
