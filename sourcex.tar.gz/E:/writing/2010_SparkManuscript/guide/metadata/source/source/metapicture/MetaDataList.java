//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************
 Name: MetaDataList.java
 Function: Swing panel listing MetaPictures/MetaTraces/etc.
 Author: Sean Parsons
 Date: Spring 2010

 Description:


 ****************************************************************************/
//////////////////////////////////////////////////////////////////////////////

package metapicture;

import SPUtils.MetaUtils;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import ij.gui.*;
import ij.*;
import ij.process.*;

import PhysiolPlot.*;



import javax.swing.DefaultListModel.*;
import java.io.*;

public class MetaDataList  extends JPanel
        implements ActionListener, ListSelectionListener, TableModelListener, WindowFocusListener, MouseListener {
    
    //LISTS
    ArrayList<MetaObject> meta_list;                     //meta objects
    int curr;                                           //index of currently displayed (in table)
    
    ArrayList<Roi> roi_board;                           //roi copy board

    //GUI MEMBERS
    
    //scrolled table for displaying meta data
    int info_nrows = 100;
    String info_head[] = {"TAG TYPE", "VALUE"};
    JTable info_table;           
    JScrollPane info_scroll;
    
    //scrolled list for displaying list
    JList list_table;          
    DefaultListModel list_table_mdl;
    JScrollPane list_scroll;
    
    //Button Panel
    JPanel popup_panel;
    
    JLabel file_lb;             //file popup menu
    JPopupMenu file_pm;
        JMenuItem open_mi;
        JMenuItem close_mi;
        JMenuItem save_mi;
        JMenuItem saveas_mi;
        JMenuItem copy_mi;

    JLabel pic_lb;              //picture popup menu
    JPopupMenu pic_pm;
        JMenuItem show_mi;
        JMenuItem showv_mi;
        JMenuItem hide_mi;
        JMenuItem calibrate_mi;
        JMenuItem tofloat_mi;
    
    JLabel roi_lb;              //roi label
    JPopupMenu roi_pm;
       JMenuItem toclip_mi;
       JMenuItem fromclip_mi;
       JMenuItem clearclip_mi;
       JMenuItem clear_mi;
    

    //file dialog
    JFileChooser fdialog;

    //-----------------------------------------------
    //CNSTR
    MetaDataList(){

        //META OBJECT LIST
        meta_list = new ArrayList<MetaObject>();

        roi_board = new ArrayList<Roi>();
        
        //GUI
   
        //file dialog
        fdialog = new JFileChooser();
        fdialog.setMultiSelectionEnabled(true);
        fdialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
   
        //info table (scrolled table for displaying meta data)
        info_table = new JTable(info_nrows, 2);  
        info_table.getModel().addTableModelListener(this);
        info_scroll = new JScrollPane(info_table);

        //list (scrolled table for displaying list)
        list_table = new JList();         
        list_table_mdl = new DefaultListModel();
        list_table.setModel(list_table_mdl);
        list_table.addListSelectionListener(this);
        list_scroll = new JScrollPane(list_table);
        
        //file popup menu
        file_lb = new JLabel("file", JLabel.CENTER);
        file_lb.setBackground(Color.RED);
        file_lb.addMouseListener(this);
        file_pm = new JPopupMenu();

            open_mi = new JMenuItem("Open");
            open_mi.addActionListener(this);
            file_pm.add(open_mi);

            close_mi = new JMenuItem("Close");
            close_mi.addActionListener(this);
            file_pm.add(close_mi);

            save_mi = new JMenuItem("Save");
            save_mi.addActionListener(this);
            file_pm.add(save_mi);

            saveas_mi = new JMenuItem("SaveAs");
            saveas_mi.addActionListener(this);
            file_pm.add(saveas_mi);

            copy_mi = new JMenuItem("Copy");
            copy_mi.addActionListener(this);
            file_pm.add(copy_mi);

        //picture popup menu
        pic_lb = new JLabel("picture", JLabel.CENTER);
        pic_lb.setBackground(Color.ORANGE);
        pic_lb.addMouseListener(this);
        pic_pm = new JPopupMenu();

            show_mi = new JMenuItem("Show");
            show_mi.addActionListener(this);
            pic_pm.add(show_mi);

            showv_mi = new JMenuItem("Show V");
            showv_mi.addActionListener(this);
            pic_pm.add(showv_mi);

            hide_mi = new JMenuItem("Hide");
            hide_mi.addActionListener(this);
            pic_pm.add(hide_mi);

            calibrate_mi = new JMenuItem("Calibrate");
            calibrate_mi.addActionListener(this);
            pic_pm.add(calibrate_mi);

            tofloat_mi = new JMenuItem("To Float");
            tofloat_mi.addActionListener(this);
            pic_pm.add(tofloat_mi);

        //roi popup menu
        roi_lb = new JLabel("roi", JLabel.CENTER);
        roi_lb.setBackground(Color.YELLOW);
        roi_lb.addMouseListener(this);
        roi_pm = new JPopupMenu();

            toclip_mi = new JMenuItem("To Clipboard");
            toclip_mi.addActionListener(this);
            roi_pm.add(toclip_mi);

            fromclip_mi = new JMenuItem("From Clipboard");
            fromclip_mi.addActionListener(this);
            roi_pm.add(fromclip_mi);

            clearclip_mi = new JMenuItem("Clear Clipboard");
            clearclip_mi.addActionListener(this);
            roi_pm.add(clearclip_mi);

            clear_mi = new JMenuItem("Clear Current");
            clear_mi.addActionListener(this);
            roi_pm.add(clear_mi);


        //popup menu panel
        popup_panel = new JPanel();
        popup_panel.setLayout(new GridLayout(4,3));
            //1
            popup_panel.add(file_lb);
            popup_panel.add(pic_lb);
            popup_panel.add(roi_lb);
            //2
            popup_panel.add(new JLabel(""));
            popup_panel.add(new JLabel(""));
            popup_panel.add(new JLabel(""));
            //3
            popup_panel.add(new JLabel(""));
            popup_panel.add(new JLabel(""));
            popup_panel.add(new JLabel(""));
            //4
            popup_panel.add(new JLabel(""));
            popup_panel.add(new JLabel(""));
            popup_panel.add(new JLabel(""));

        //set current object
        AddEntry();
        SetCurrentlyDisplayed(0);

        //add gui elements
        setLayout(new GridLayout(3,1));
        add(info_scroll);
        add(list_scroll);
        add(popup_panel);
  
    }
    
    //-----------------------------------------------
    //LIST
    //idx = index of meta_list
    //return true if successful
    
    //set meta_list[idx] as currently displayed in table
    public boolean SetCurrentlyDisplayed(int idx){
    
        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;
            
        //update info table
        for (int j = 0; j < info_nrows; j++){
            info_table.setValueAt(meta_list.get(idx).metadata.GetDescription(j), j, 0);
            info_table.setValueAt(meta_list.get(idx).metadata.GetValue(j), j, 1);
        }
        curr = idx;

        return true;
        
    }

    //save MetaObject corresponding to meta_list[idx] under filename arg
    public boolean SaveEntry(int idx, String arg){
        
        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //set path to save to
        String stp = "";
        if (arg == null) stp = meta_list.get(idx).path + meta_list.get(idx).name;
            else stp = SPUtils.MetaUtils.GetFilePath(arg) + SPUtils.MetaUtils.GetFileName(arg);

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){
            MetaPicture mp  = (MetaPicture)meta_list.get(idx);
            mp.WriteData(stp + ".tif");
            return true;  
        }

        //if it is a trace....
        if(meta_list.get(idx).type == 2){
            MetaTable mt  = (MetaTable)meta_list.get(idx);
            mt.WriteData(stp + ".txt");
            return true;
        }

        return false;
    }

    //copy
    public boolean CopyEntry(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){

            AddObject(new MetaPicture((MetaPicture)meta_list.get(idx)));
            ShowLatestAdded();
            return true;

        }//end of if metapicture

        //if it is a trace....
        if(meta_list.get(idx).type == 2){

            AddObject(new MetaTable((MetaTable)meta_list.get(idx)));
            ShowLatestAdded();
            return true;

        }

        return false;
    }

    //add......
    
    //default (MetaPicture) entry
    public boolean AddEntry(){

        //add a default picture
        meta_list.add(new MetaPicture());
        MetaPicture mp  = (MetaPicture)meta_list.get(meta_list.size()-1);
        list_table_mdl.addElement(mp.picname);

        return true;

    }

    //from file
    public boolean AddEntry(String arg){
        
        //get extension
        String ext = MetaUtils.GetFileExtension(arg);
        
        //tif file (MetaPicture)
        if ((ext.equals("tiff")) ||
            (ext.equals("tif")) ||
            (ext.equals("TIFF")) ||
            (ext.equals("TIF"))){

            AddObject(new MetaPicture(arg));
            return true;

        }
        
        //txt file (MetaTable)
        if (ext.equals("txt")){

            AddObject(new MetaTable(arg));
            return true;

        }

        return false;
       
    }

    //MetaObject
    public boolean AddObject(MetaObject arg){
    
        if (arg != null){

            meta_list.add(arg);
            list_table_mdl.addElement(arg.picname);
            return true;

        } else AddEntry();

        return false;
    }

    //MetaPicture (for backwards compatability)
    public boolean AddPicture(MetaObject arg){

        if (arg != null){

            meta_list.add(arg);
            list_table_mdl.addElement(arg.picname);
            return true;

        } else AddEntry();

        return false;
    }
         
    //remove entry
    public boolean RemoveEntry(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;
        
        //if it is a metapicture hide display window
        if(meta_list.get(idx).type == 1){ 
            MetaPicture mp  = (MetaPicture)meta_list.get(idx);
            mp.DImage.hide();
        }//end of if metapicture

        //if it is a trace....
        /*
         SOMETHING HERE????
         */
        
        //remove meta_list entry
        meta_list.remove(idx);
        list_table_mdl.removeElementAt(idx);
        
        return true;
    } 
    
    //get current metapicture
    public MetaPicture GetCurrentPicture(){

        MetaObject cselec  = meta_list.get(curr);
        if (cselec.type == 1)
            return (MetaPicture)cselec;

        return null;
        
    }

    //get current displayed name (picname/etc)
    public String GetCurrentListName(){
        return meta_list.get(curr).picname;
    }

    //get currently selected index
    public int[] GetCurrentlySelected(){
        int list[] = new int[2];
        list = list_table.getSelectedIndices();
        return list;
    }

    //get currently selected Objects
    public MetaObject[] GetCurrentlySelectedObjects(){

        int list[] = new int[2];
        list = GetCurrentlySelected();
        MetaObject oblist[] = new MetaObject[list.length];
        for(int i = 0; i < list.length; i++)
            oblist[i] = meta_list.get(list[i]);

        return oblist;

    }
    
    //--------------------------------------------------
    //IMAGES AND ROIs

    //show and hide images/traces
    public boolean ShowEntry(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){
            
            MetaPicture mp  = (MetaPicture)meta_list.get(idx);
            ImageWindow w = mp.DImage.getWindow();
            if ((w != null) && (w.isShowing()))
                w.toFront();
            else {
                mp.Show();
                //add window listener
                mp.DImage.getWindow().addWindowFocusListener(this);
            }
            return true;

        }//end of if metapicture

        //if it is a trace....
        /*
         SOMETHING HERE
         */

        return false;

    }

    public boolean ShowLatestAdded(){
        return ShowEntry(meta_list.size()-1);
    }

    public boolean HideEntry(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){

                MetaPicture mp  = (MetaPicture)meta_list.get(idx);
                mp.DImage.hide();
                return true;

        }//end of if metapicture

        //if it is a trace....
        /*
         SOMETHING HERE
         */

        return false;

    }

    //show image in physiol (JScrollPane) viewer
    public boolean ShowEntryV(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){
   
            MetaPicture mp  = (MetaPicture)meta_list.get(idx);
            Viewer myv = new Viewer(mp);
            myv.Show();
            return true;
   
        }//end of if metapicture

        //if it is a trace....
        /*
         SOMETHING HERE
         */

        return false;

    }
    
    //convert to float
    public boolean ConvertToFloat(int idx){
        
        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;
        
        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){
            
            MetaPicture mp  = (MetaPicture)meta_list.get(idx);
            
            //check it is not a float already
            if(mp.OImage.getBitDepth() == 32) return false;

            //convert to float and adjust ares and aorig
            FloatProcessor ip = new FloatProcessor(10, 10);
            ip = (FloatProcessor) mp.OImage.getProcessor().convertToFloat();
            float ares = (float)MetaUtils.StrToDbl(mp.metadata.GetValue(MetaTagType.A_RES));
            float aorig = (float)MetaUtils.StrToDbl(mp.metadata.GetValue(MetaTagType.A_ORIGIN));
            for(int i = 0; i < ip.getPixelCount(); i++) ip.setf(i, (ip.getf(i) * ares) + aorig);
            ip.resetMinAndMax();

            //convert both processors
            mp.SetBothProcessors(ip);
            mp.metadata.SetValueUnEditable(MetaTagType.A_RES, "1.0");
            mp.metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, "0.0");
            
            //update
            mp.DImage.updateAndDraw();
            
            return true;  
        }
        
        return false;
    }
    
    //roi clipboard paste
    public boolean RoiClipboardPaste(int idx){
        
        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;
        
        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){
            
            MetaPicture mp  = (MetaPicture)meta_list.get(idx);

            //add picture's rois to board
            for(int i = 0; i < mp.rois.size(); i++)
                roi_board.add(mp.rois.get(i));

            return true;
        }
        
        return false;

    }
    
    //roi clipboard copy
    public boolean RoiClipboardCopy(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){

            MetaPicture mp  = (MetaPicture)meta_list.get(idx);

            //add copies of board's rois to picture
            for(int i = 0; i < roi_board.size(); i++)
                mp.rois.add((Roi)roi_board.get(i).clone());

            return true;
        }
        
        return false;
    }

    //roi clear
    public boolean RoiClear(int idx){

        //check idx is within range
        if ((idx < 0) || (idx >= meta_list.size())) return false;

        //if it is a metapicture.....
        if(meta_list.get(idx).type == 1){

            MetaPicture mp  = (MetaPicture)meta_list.get(idx);

            //clear pictures rois
            mp.ClearRois();
            mp.DImage.setOverlay(null);
            mp.UpdateAndDraw();

            return true;
        }

        return false;
    }

    
    //-------------------------------------------
    //LISTENERS
    
    //button listeners
    public void actionPerformed(ActionEvent ae){
       
        //OPEN
        if(ae.getSource() == open_mi){

            //show file selection dialog
            fdialog.setMultiSelectionEnabled(true);
            int returnVal = fdialog.showOpenDialog(this);
            if(returnVal == JFileChooser.APPROVE_OPTION) {

                //go through selected files
                File sfile[] = fdialog.getSelectedFiles();
                String fname = "";
                for(int i = 0; i < sfile.length; i++){
                    //get name and extension
                    fname = sfile[i].getPath();
                    //add entry
                    AddEntry(fname);
                }//end of for loop (through file list)

            }

        }
        //CLOSE
        else if(ae.getSource() == close_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = si.length - 1; i >= 0; i--) RemoveEntry(si[i]);
            else RemoveEntry(list_table.getSelectedIndex());

        }
        //SAVE
        else if(ae.getSource() == save_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) SaveEntry(si[i], null);
            else SaveEntry(list_table.getSelectedIndex(), null);
            
        }
        //SAVEAS
        else if(ae.getSource() == saveas_mi){

            int si = list_table.getSelectedIndex();

            File currpath = new File(meta_list.get(si).path +
                                     meta_list.get(si).name +
                                     "." +
                                     meta_list.get(si).ext);
            fdialog.setCurrentDirectory(currpath);
            fdialog.setSelectedFile(currpath);


            int returnVal = fdialog.showSaveDialog(this);
            if(returnVal == JFileChooser.APPROVE_OPTION) {
                //save current entry
                File sfile[] = fdialog.getSelectedFiles();
                String fname = sfile[0].getPath();
                SaveEntry(si, fname);
            }

        }
        //COPY
        else if(ae.getSource() == copy_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) CopyEntry(si[i]);
            else CopyEntry(list_table.getSelectedIndex());

        }
        //SHOW
        else if(ae.getSource() == show_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) ShowEntry(si[i]);
            else ShowEntry(list_table.getSelectedIndex());

        }
        //SHOW VIEWER
        else if(ae.getSource() == showv_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) ShowEntry(si[i]);
            else ShowEntryV(list_table.getSelectedIndex());

        }
        //HIDE
        else if(ae.getSource() == hide_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) HideEntry(si[i]);
            else HideEntry(list_table.getSelectedIndex());

        }
        //CALIBRATE
        else if(ae.getSource() == calibrate_mi){

            //show current entry
            if(ShowEntry(list_table.getSelectedIndex()) == true){

                CalPanel cp = new CalPanel(ij.IJ.getInstance());
                cp.show(GetCurrentPicture());
               
            }

        }
        //CONVERT TO FLOAT
        else if(ae.getSource() == tofloat_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) ConvertToFloat(si[i]);
            else ConvertToFloat(list_table.getSelectedIndex());

        }
        //ROI CLIPBOARD CLEAR
        else if(ae.getSource() == clearclip_mi){

                roi_board.clear();

        }
        //ROI CLIPBOARD PASTE
        else if(ae.getSource() == toclip_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) RoiClipboardPaste(si[i]);
            else RoiClipboardPaste(list_table.getSelectedIndex());

        }
        //ROI CLIPBOARD COPY
        else if(ae.getSource() == fromclip_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) RoiClipboardCopy(si[i]);
            else RoiClipboardCopy(list_table.getSelectedIndex());

        }
        //ROI CLEAR
        else if(ae.getSource() == clear_mi){

            int si[] = list_table.getSelectedIndices();
            if (si.length > 1)
                for(int i = 0; i < si.length; i++) RoiClear(si[i]);
            else RoiClear(list_table.getSelectedIndex());

        }


        else;

        
    }

    //change in list selection
    public void valueChanged(ListSelectionEvent le){

        if(le.getSource() == list_table){
            //change metadata displayed by table
            SetCurrentlyDisplayed(list_table.getSelectedIndex());
            
        }

    }

    //entry to Meta Data table
    public void tableChanged(TableModelEvent te){
        
        //entry to meta data table
        if(te.getSource() == info_table.getModel()){

            int col = te.getColumn();
            int row = te.getFirstRow();
            //if change was to second column....
            if (col == 1){

                int si = list_table.getSelectedIndex();
                //update current meta data
                String readval = (String)info_table.getModel().getValueAt(row, col);
                try{
                    meta_list.get(si).metadata.SetValue(row, readval);
                }catch(ArrayIndexOutOfBoundsException e){}
    
            }
        }
  
    }

    //window focus listeners...
    //window gained focus: change selected list entry to object corresponding to this window
    public void windowGainedFocus(WindowEvent we){
        
       int focused = -1;        //index in metalist object displayed by window

       //search through pictures
       for(int i = 0; i < meta_list.size(); i++){
           
           //if metapicture
           if (meta_list.get(i).type == 1){

               MetaPicture mp  = (MetaPicture)meta_list.get(i);
               if (we.getSource() == mp.DImage.getWindow()){
               focused = i;
               break;
               }
               
           }

           //if trace/etc
           
           
               
       }
       
       //if focused not -1, switch current to focused
       if (focused >= 0) {
           list_table.setSelectedIndex(focused);
           SetCurrentlyDisplayed(focused);
       }

    }

    public void windowLostFocus(WindowEvent we){

            //does nothing!!

    }
    
    //mouse listeners (for popupmenus)
    public void mouseClicked(MouseEvent me){

        //FILE MENU
        if(me.getComponent() == file_lb){  
            file_pm.show(file_lb, 0, 0);     
        }
        //PICTURE MENU
        else if (me.getComponent() == pic_lb){
            pic_pm.show(pic_lb, 0, 0);
        }
        //ROI MENU
        else if (me.getComponent() == roi_lb){
            roi_pm.show(roi_lb, 0, 0); 
        }
        
    }
    
    public void mouseEntered(MouseEvent me){
        
    }
    
    public void mouseExited(MouseEvent me){
        
    }
    
    public void mousePressed(MouseEvent me){
        
   
    }
    
    public void mouseReleased(MouseEvent me){
        
    }
    

 

}
