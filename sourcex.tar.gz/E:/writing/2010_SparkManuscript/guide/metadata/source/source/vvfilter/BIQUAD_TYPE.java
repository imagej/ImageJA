/*
 An IIR filter library, translated from the c++ code of Vladimir L. Vassilevsky.
 *
 * Sean Parsons, April 2010
 *
 * BIQUAD.java
 * FILTER.java
 *
 * BIQUAD_TYPE.java
 * FILTER_FUNCTION.java
 * FILTER_TYPE.java
 *
 * bessel_tables.java
 * misutil.java
 * modphase.java (added by SP)
 *
 *
 */
package vvfilter;

public enum BIQUAD_TYPE {

    FLAT,
    LOWPASS_1,
    LOWPASS_2,
    HIGHPASS_1,
    HIGHPASS_2,
    BANDPASS,
    PARAMETRIC_EQ,
    A1A2_LOWPASS,
    A1A2_HIGHPASS
}
