/*
 *
 * Applies Lee filtering algorithm along x axis
 *
 * Lee, J-S. (1986). Speckle suppression and analysis for synthetic aperture radar images. Optical
    Engineering 25, 636-643.
 *
 * Sean Parsons, April 2010
 *
 */

package spark;

import metapicture.*;
import SPUtils.MetaUtils.*;

import javax.swing.*;
import ij.process.*;
import ij.plugin.filter.*;
import ij.*;


public class LeeFilter extends SwingWorker<Boolean, Void>{


    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)
    
    Convolver myconv;       //convolver

    int dir;            //direction (0 = x, 1 = xy)
    double sigma;       //sigma
    int bxcarw;         //boxcar width

    public LeeFilter(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;
        
        myconv = new Convolver();

        dir = 0;
        sigma = 5;
        bxcarw = 5;

        //output picture?
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "LeeFilter");
        output.name = (output.name + "_" + "LeeFilter");
        output.SetFilePath();
        output.SetPictureName();

    }

    void SetVariables(double sigma_arg, int bxcar_arg, int dir_arg){
        if ((sigma_arg > 0) &&  (sigma_arg < 10)) sigma = sigma_arg;
        if ((bxcar_arg > 2) &&  (bxcar_arg < 10)) bxcarw = bxcar_arg;
        if (( bxcarw & 1 ) == 0)  bxcarw++;
        if ((dir_arg >= 0) && (dir_arg < 2)) dir = dir_arg;
    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //dimensions
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();

        //boxcar
        int bxcarh = 1;
        if (dir == 1) bxcarh = bxcarw;
        float boxcar[] = new float[bxcarw * bxcarh];             //!!!
        float boxsum = (float)(bxcarw * bxcarh);                 //!!!

        //calculate boxcar mean
        FloatProcessor mean = (FloatProcessor)imp_o.duplicate();
        for(int i = 0; i < boxcar.length; i++) boxcar[i] = 1f / boxsum;
        myconv.convolveFloat(mean, boxcar, bxcarw, bxcarh);  //!!!
        
        //calculate variance....
        //...square
        FloatProcessor var = (FloatProcessor)imp_o.duplicate();
        for(int i = 0; i < xl; i++)
           for(int j = 0; j < yl; j++)
               var.setf(i, j, var.getf(i, j) * var.getf(i, j));
        //.....sum of squares
        for(int i = 0; i < boxcar.length; i++) boxcar[i] = 1f;
        myconv.convolveFloat(var, boxcar, bxcarw, bxcarh);       //!!!
        //...variance
        Float ch = new Float(0);
        float vv = 0;
        for(int i = 0; i < xl; i++)
           for(int j = 0; j < yl; j++){
               vv = (var.getf(i, j) / boxsum) - ( mean.getf(i, j) * mean.getf(i, j));
               var.setf(i, j, vv);
           }
               
        //calculate Lee filter
        for(int i = 1; i < xl; i++)
           for(int j = 0; j < yl; j++){
               
               vv = var.getf(i, j) * (imp_o.getf(i, j) - mean.getf(i, j));
               vv /= ((mean.getf(i, j) * mean.getf(i, j) * sigma * sigma) + var.getf(i, j));
               vv += mean.getf(i, j);
               if((ch.isNaN(vv)) || (ch.isInfinite(vv))) vv = imp_o.getf(i-1, j);
               imp_o.setf(i, j, vv);
     
           }

        //if input was 8bit, set  min, max to 0, 255
        if (input.OImage.getBytesPerPixel() == 1) imp_o.setMinAndMax(0, 255);

        //set output processors to OImage
        output.SetToOriginal();

        return true;

    }

    @Override
    public void done() {

          parent.WhenFilterDone();

    }

}
