/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package frequency;

import metapicture.*;
import SPUtils.*;
import javax.swing.*;
import ij.*;

/**
 *
 * @author Sean
 */
public class fft2D extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    
    //parent panel
    fftPanel parent; 
    
    //input picture
    MetaPicture input;
    int xl;         //length (samples)
    int yl;
    float xd;       //samples length (units)
    float yd;
    
    //output picture
    MetaPicture output;    //output picture
    Dimension_Type direction;   //direction of operation
    int optype;            //operation type
                            //0 = spectra
                            //1 = filtered image
                            //2 = window function
                            //3 = filter kernal
                            //default = return copy
    Scale_Type scale;       //magnitude scale (abs, sqr, dB, etc)

    //x/y FFT processing objects
    FDomain xfreq;          
    FDomain yfreq;


    //--------------------------------------------
    //CNSTR
    public fft2D(fftPanel parent_arg, MetaPicture pic_arg){

        //parent panel
        parent = parent_arg;
        
        //input metapicture
        input = pic_arg;
        if(input != null){
            xl = input.OImage.getWidth();
            yl = input.OImage.getHeight();
            xd = (float)MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.X_RES));
            yd = (float)MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.Y_RES));
        }

        //output picture
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        
        //FDomain objects
        xfreq = new FDomain(xl, xd);
        yfreq = new FDomain(yl, yd);

    }

    //------------------------------------------------------------
    //set varaibles
    void SetVariables(Dimension_Type dimension_arg,
                      Window_Type window_arg,
                      Scale_Type scale_arg,
                      Filter_Type filter_arg,
                      Pass_Type pass_arg,
                      int order_arg,
                      float xf1_arg, float xf2_arg,
                      float yf1_arg, float yf2_arg,
                      int optype_arg){
        
        //operation type, direction of operation and output magnitude scale
        optype = optype_arg;
        direction = dimension_arg;
        scale = scale_arg;

        //FFT processing objects
        xfreq.SetFilter(filter_arg, pass_arg, order_arg, xf1_arg, xf2_arg);
        xfreq.SetWindow(window_arg);
        yfreq.SetFilter(filter_arg, pass_arg, order_arg, yf1_arg, yf2_arg);
        yfreq.SetWindow(window_arg);
        
    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        ////////////////////////////////////////////////
        //OPERATION

        //put image into array
        float data[][] = new float[xl][yl];
        for(int i = 0; i < xl; i++)
           for(int j = 0; j < yl; j++)
               data[i][j] = input.OImage.getProcessor().getf(i, j);
        
        //X DIRECTION
        if ((direction == Dimension_Type.X) ||
            (direction == Dimension_Type.XY)){

            //loop through rows
            for(int j = 0; j < yl; j++){
                        
                //get row data
                for(int i = 0; i < xl; i++)
                    xfreq.SetData(i, data[i][j]);
                        
                //do operation
                switch (optype){
                    
                    //spectra
                    case 0:
                        xfreq.DoSpectra();
                        break;

                    //filtered image
                    case 1:
                        xfreq.DoFilter();
                        break;

                    //window
                    case 2:
                        xfreq.DoWindow();
                        break;
                        
                    //kernal
                    case 3:
                        xfreq.DoKernal();
                        break;
                        
                    //default (need to put in filtered image, etc, etc)!!!!!!!!
                    default:
                        xfreq.DoNothing();
                        
                }
        
                //put transformed row data back
                for(int i = 0; i < xl; i++)
                     data[i][j] = xfreq.GetOutput(i);
                        
            }//end of row loop
            
        }//end of if direction if x or xy
        
        //Y DIRECTION
        if ((direction == Dimension_Type.Y) ||
            (direction == Dimension_Type.XY)){

            //loop through columns
            for(int i = 0; i < xl; i++){
                        
                //get column data
                for(int j = 0; j < yl; j++)
                    yfreq.SetData(j, data[i][j]);
                        
                //do operation
                switch (optype){
                    
                    //spectra
                    case 0:
                        yfreq.DoSpectra();
                        break;

                    //filtered image
                    case 1:
                        yfreq.DoFilter();
                        break;

                    //window
                    case 2:
                        yfreq.DoWindow();
                        break;

                    //kernal
                    case 3:
                        yfreq.DoKernal();
                        break;
                        
                    //default (need to put in filtered image, etc, etc)!!!!!!!!
                    default:
                        yfreq.DoNothing();
                        
                }
        
                //put transformed column data back
                if (optype == 3){
                    for(int j = 0; j < yl; j++)
                        data[i][j] *= yfreq.GetOutput(j);
                } else {
                    for(int j = 0; j < yl; j++)
                        data[i][j] = yfreq.GetOutput(j);
                }
                        
            }//end of column loop
                
        }//end of if direction if x or xy        

        

        /////////////////////////////////////////////////////////
        //OUTPUT PICTURE

        //operations with output image in frequency domain
        //(spectra and filter kernal)
        if ((optype == 0) ||
            (optype == 3)){
            
            double xint = 1 / (xl * xd);
            double yint = 1 / (yl * yd);

            //amplitude metadata
            output.metadata.SetValue(MetaTagType.A_NAME, "power");
            String punit = input.metadata.GetValue(MetaTagType.A_UNIT);

            //x and y dimension metadata
            if ((direction == Dimension_Type.X) ||
                (direction == Dimension_Type.XY)){
                output.metadata.SetValue(MetaTagType.X_NAME, "frequency");
                output.metadata.SetValue(MetaTagType.X_UNIT, input.metadata.GetValue(MetaTagType.X_UNIT) + "^-1");
                output.metadata.SetValue(MetaTagType.X_ORIGIN, SPUtils.MetaUtils.DblToStr(-(xl/2) * xint));
                output.metadata.SetValue(MetaTagType.X_RES, SPUtils.MetaUtils.DblToStr(xint));
                punit += ("." + input.metadata.GetValue(MetaTagType.X_UNIT));
            }

            if ((direction == Dimension_Type.Y) ||
                (direction == Dimension_Type.XY)){
                output.metadata.SetValue(MetaTagType.Y_NAME, "frequency");
                output.metadata.SetValue(MetaTagType.Y_UNIT, input.metadata.GetValue(MetaTagType.Y_UNIT) + "^-1");
                output.metadata.SetValue(MetaTagType.Y_ORIGIN, SPUtils.MetaUtils.DblToStr(-(xl/2) * yint));
                output.metadata.SetValue(MetaTagType.Y_RES, SPUtils.MetaUtils.DblToStr(yint));
                punit += ("." + input.metadata.GetValue(MetaTagType.Y_UNIT));
            }
   
            //scale data
            switch(scale){

                case ABS:
                    output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, punit);
                    for(int i = 0; i < xl; i++)
                        for(int j = 0; j < yl; j++)
                            data[i][j] = Math.abs(data[i][j]);
                break;

                case SQR:
                    output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "(" + punit + ")^2");
                    for(int i = 0; i < xl; i++)
                        for(int j = 0; j < yl; j++)
                            data[i][j] = (float)Math.pow(data[i][j], 2.0);
                break;

                case DB:
                    output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "dB");
                    for(int i = 0; i < xl; i++)
                        for(int j = 0; j < yl; j++)
                            if (data[i][j] > 0) data[i][j] = 10 * (float)Math.log10(Math.abs(data[i][j]));
                break;

            }
            
        }//end of if spectra or kernal
        

        //put data into output image
        for(int i = 0; i < xl; i++)
           for(int j = 0; j < yl; j++)
               output.OImage.getProcessor().setf(i, j, data[i][j]);
        
        //rescale....
        switch (optype){
            
            //spectra
            case 0:
            //find maxiumum in upper-left quadrant
            float mx = 0;
            for(int i = 0; i < (xl/2)-10; i++)
                for(int j = 0; j < (yl/2)-10; j++)
                    if (data[i][j] > mx) mx = data[i][j];
            output.OImage.getProcessor().setMinAndMax(0, mx);
            break;

            //filtered image
            case 1:
            output.OImage.getProcessor().resetMinAndMax();
            break;

            //window
            case 2:
            output.OImage.getProcessor().setMinAndMax(0, 1.0);
            break;

            //filter kernal
            case 3:
            output.OImage.getProcessor().setMinAndMax(0, 1.0);
            break;

            default:
            output.OImage.getProcessor().resetMinAndMax();
            
        }

        //set DImage to OImage
        output.SetToOriginal();

        //other metadata
        String process = "";        //string to set metadata.CREATE_P
        if ((direction == Dimension_Type.X) ||
            (direction == Dimension_Type.XY)) process += "x";
        if ((direction == Dimension_Type.Y) ||
            (direction == Dimension_Type.XY)) process += "y";
        output.metadata.AddTag(MetaTagType.FFT_DIR, process);
        
        String filter_desc = MetaUtils.IntToStr(xfreq.filter_order) + "thOrder" +
                             xfreq.filter_type.GetDescription() + 
                             xfreq.pass_type.GetDescription();
        
        String window_desc = xfreq.window_type.GetDescription();
        
        switch (optype){
                    
            //spectra
            case 0:
                process += ("FFTSpectra" + window_desc);
                output.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "FFT spectra");
                output.metadata.AddTag(MetaTagType.FFT_WIN, window_desc);
                break;

            //filtered image
            case 1:
                process += ("FFTFiltered" + filter_desc);
                output.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "FFT filtered image");
                output.metadata.AddTag(MetaTagType.FILT_TYPE, filter_desc);
                output.metadata.AddTag(MetaTagType.FILT_XL, MetaUtils.DblToStr(xfreq.f1));
                output.metadata.AddTag(MetaTagType.FILT_XH, MetaUtils.DblToStr(xfreq.f2));
                output.metadata.AddTag(MetaTagType.FILT_YL, MetaUtils.DblToStr(yfreq.f1));
                output.metadata.AddTag(MetaTagType.FILT_YH, MetaUtils.DblToStr(yfreq.f2));
                break;

            //window
            case 2:
                process += ("Window" + window_desc);
                output.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "Window");
                output.metadata.SetValueUnEditable(MetaTagType.A_NAME, "coefficient");
                output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "fraction");
                output.metadata.AddTag(MetaTagType.FFT_WIN, window_desc);
                break;

            //filter kernal
            case 3:
                process += ("Kernal" + filter_desc);
                output.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "filter kernal");
                output.metadata.SetValueUnEditable(MetaTagType.A_NAME, "coefficient");
                output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "fraction");
                output.metadata.AddTag(MetaTagType.FILT_TYPE, filter_desc);
                output.metadata.AddTag(MetaTagType.FILT_XL, MetaUtils.DblToStr(xfreq.f1));
                output.metadata.AddTag(MetaTagType.FILT_XH, MetaUtils.DblToStr(xfreq.f2));
                output.metadata.AddTag(MetaTagType.FILT_YL, MetaUtils.DblToStr(yfreq.f1));
                output.metadata.AddTag(MetaTagType.FILT_YH, MetaUtils.DblToStr(yfreq.f2));
                break;

            //default
            default:
                process += "NoProcess";
                output.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "image");
                break;
             
        }

        //creation  process, picturename, file name
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, process);
        output.name = output.name + "_" + process;
        output.SetFilePath();
        output.SetPictureName();

        ///////////////////////////////////////////////////////////////////
        //RETURN
        return true;

    }

    @Override
    public void done() {

          parent.WhenDone();

    }

}
