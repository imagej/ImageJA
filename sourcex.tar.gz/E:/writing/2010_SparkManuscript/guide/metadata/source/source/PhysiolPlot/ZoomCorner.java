/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PhysiolPlot;

import javax.swing.*;
import ij.process.*;
import java.awt.*;

public class ZoomCorner extends JPanel{
    
    JButton in_but;
    JButton out_but;
    
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    
    ZoomCorner(int o, int x, int y){

        setPreferredSize(new Dimension(x, y));
        
        if (o == HORIZONTAL){
            setLayout(new GridLayout(1,2));
            in_but = new JButton(CreateArrowIcon(x/2, y, 2));
            out_but = new JButton(CreateArrowIcon(x/2, y, 0));
            add(in_but);
            add(out_but);
        } else {
            setLayout(new GridLayout(2,1));
            in_but = new JButton(CreateArrowIcon(x, y/2, 1));
            out_but = new JButton(CreateArrowIcon(x, y/2, 3));
            add(out_but);
            add(in_but);
        }
  
    }
    
    //dir   0 = >
    //      1 = down
    //      2 = <
    //      3 = ^
    ImageIcon CreateArrowIcon(int x, int y, int dir){
        
        ByteProcessor arr = new ByteProcessor(x, x);
        arr.setBackgroundValue(255);
        for (int i = 0; i < x/2; i++)
            for (int j = 0; j < x - i; j++) 
                arr.set(j, i, 0);
        
        for (int i = 0; i < dir; i++)
            arr.rotate(90);
        
        return new ImageIcon(arr.resize(x, y).getBufferedImage());
  
    }
    

}
     



