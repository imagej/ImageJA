/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package metapicture;


//enumeration of possible Meta Tags with their descriptions
public enum MetaTagType {

    //META TAGS
    //identification/etc
    CLASS_ID("Class ID", false, false, false),          //class of meta data. e.g. PICTURE
    UNIQ_ID("Unique ID", false, false, false),          //random string to uniquely identify data
    CREAT_P("Creation Process", false, false, true),    //method used to create data e.g. gMap_OrganBath/etc
    DATATYPE("Data Type", false, false, true),          //data type. e.g. gMAPabolute/ etc)
    CREAT_D("Creation Date", false, false, false),      //creation date and time
    PARENT_ID("Parent's ID", false, false, false),      //unique ID of parent

    //meta picture
    X_NAME("x name", false, false, true),                   //x name. e.g. "space"
    X_UNIT("x unit", false, false, true),                   //x unit. e.g. "microns"
    X_ORIGIN("x origin (units)", true, true, true),         //x origin. e.g. 0 units
    X_RES("x resolution (units/pixel)", true, true, true),  //x resolution e.g. 0.55 units/pixel
    X_NPIXELS("x width (pixels)", true, false, false),       //x width (pixels)
    X_WIDTH("x width (units)", true, true, false),           //x width (units)
    Y_NAME("y name", false, false, true),                   //y name. e.g. "space"
    Y_UNIT("y unit", false, false, true),                   //y unit. e.g. "microns"
    Y_ORIGIN("y origin (units)", true, true, true),         //y origin. e.g. 0 units
    Y_RES("y resolution (units/pixel)", true, true, true),  //y resolution e.g. 0.55 units/pixel
    Y_NPIXELS("y width (pixels)", true, false, false),       //y width
    Y_WIDTH("y width (units)", true, true, false),           //y width (units)
    Z_NAME("z name", false, false, true),                   //z name. e.g. "time"
    Z_UNIT("z unit", false, false, true),                   //z unit. e.g. "seconds"
    Z_ORIGIN("z origin (units)", true, true, true),         //z origin. e.g. 0 units
    Z_RES("z resolution (units/pixel)", true, true, true),  //z resolution e.g. 0.55 units/pixel
    A_NAME("amplitude name", false, false, true),                   //amplitude name. e.g. "intensity"
    A_UNIT("amplitude unit", false, false, true),                   //amplitude unit. e.g. "%"
    A_ORIGIN("amplitude origin (units)", true, true, true),         //amplitude origin. e.g. 0 units
    A_RES("amplitude resolution (units/pixel intensity)", true, true, true),  //amplitude resolution e.g. 0.55 units/pixel pixel
    AN_RESV("top pixels reserved for annotation", true, false, false),    //no. of top index pixels reserved for annotation

    //fft panel
    SINE_FREQ("frequency (x units-1)", true, true, true),       //sine wave frequency of test image
    SINE_VELO("velocity (y unit/x unit)", true, true, true),    //sine wave velocity of test image
    SINE_AMP("amplitude (a units)", true, true, true),           //sine wave amplitude of test image
    FFT_DIR("FFT direction", false, false, false),              //FFT direction (x || y || xy)
    FFT_WIN("Window", false, false, false),                     //window (Hamming/etc)
    FILT_TYPE("Filter", false, false, false),                   //filter type (e.g. 8th order Bessel LP)
    FILT_XL("x low cutoff (/unit)", true, true, false),         //x direction low cutoff frequency
    FILT_XH("x high cutoff (/unit)", true, true, false),         //x direction high cutoff frequency
    FILT_YL("y low cutoff (/unit)", true, true, false),         //y direction low cutoff frequency
    FILT_YH("y high cutoff (/unit)", true, true, false)         //y direction high cutoff frequency

    ;

    //MEMBERS
    private String typedescription;     //string for display (tables/etc) e.g. "Unique ID"
    private boolean IsNumber;           //value should be a number
    private boolean IsDouble;           //value should be a double
    private boolean IsEditable;         //value should be changable

    //CNSTR
    MetaTagType(String typedescription_arg, boolean IsNumber_arg,
                boolean IsDouble_arg, boolean IsEditable_arg){

        typedescription = typedescription_arg;
        IsNumber = IsNumber_arg;
        IsDouble = IsDouble_arg;
        IsEditable = IsEditable_arg;

    }

    //GET METHODS
    String GetDescription(){return typedescription;}
    String GetTagString(String typedescription_arg){
        String ret = "";
        MetaTagType vals[] = this.values();
        for(int i = 0; i < vals.length; i++){
            if(vals[i].typedescription.matches(typedescription_arg)){
                return vals[i].toString();
            }
        }

        return ret;
    }
    boolean IsNumber(){return IsNumber;}
    boolean IsDouble(){return IsDouble;}
    boolean IsEditable(){return IsEditable;}

}