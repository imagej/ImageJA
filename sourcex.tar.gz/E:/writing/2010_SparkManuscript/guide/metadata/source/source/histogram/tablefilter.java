/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package histogram;


import metapicture.*;
import SPUtils.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import ij.*;
import ij.process.*;
import ij.plugin.filter.*;
import ij.gui.*;


/**
 *
 * @author Sean
 */
public class tablefilter extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    histpanel parent;        //parent panel

    MetaObject input[];     //array of input objects
    ArrayList<MetaTable> output;     //arraylist of output metatables
    
    int collidx;            //index of column to filter
    double fmin;            //min and max of filter range
    double fmax;
 

    public tablefilter(histpanel parent_arg, MetaObject arg[]){

        parent = parent_arg;
        input = arg;
        
        output = new ArrayList<MetaTable>();

        collidx = 0;
        fmin = 0;
        fmax = 1;    

    }


    void SetVariables(int colidx_arg, double fmin_arg, double fmax_arg){
        
        if (colidx_arg  > 0) collidx = colidx_arg;
        if (fmin_arg > fmax_arg){
            fmin = fmax_arg;
            fmax = fmin_arg; 
        } else {
            fmin = fmin_arg;
            fmax = fmax_arg;
        }
        
    }



    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;


        //loop through input objects
        MetaTable curr;
        double val;
        int ai = 0;
        for(int i = 0; i < input.length; i++){

            //get metatable 
            if(input[i].type != 2) continue;
            curr = (MetaTable)input[i];
            
            if(collidx >= curr.ncols) continue;

            //add copy of current to output arraylist 
            output.add(new MetaTable(curr));
            ai = output.size()-1;

            //delete all rows
            output.get(ai).DeleteAllRows();

            //adjust name
            output.get(ai).name = (curr.name + "_Filtered");
            output.get(ai).SetFilePath();
            output.get(ai).SetPictureName();
            output.get(ai).metadata.SetFileData(output.get(ai).fpath);

            //add variables describing filter
            output.get(ai).AddVariable("filtered column index", collidx);
            output.get(ai).AddVariable("filter min", fmin);
            output.get(ai).AddVariable("filtered max", fmax);

            //add filtered rows
            for(int r = 0; r < curr.nrows; r++){
                
                //get value
                val = MetaUtils.StrToDbl(curr.Get(r, collidx));
                
                //if within range add row to filt
                if((val >= fmin) && (val <= fmax)){
                    output.get(ai).AddRow();
                    for(int c = 0; (c < output.get(ai).ncols) && (c < curr.ncols); c++){
                        output.get(ai).Set(output.get(ai).nrows - 1, c, curr.Get(r, c));
                    }
                }//end of if within range
     
            }//end of row loop


            
        }//end of metatable loop


        //return
        return true;
    }


    @Override
    public void done() {

        parent.WhenFilterDone();

    }


}

