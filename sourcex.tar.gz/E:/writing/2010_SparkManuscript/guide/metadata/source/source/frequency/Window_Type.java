
package frequency;

public enum Window_Type {

    HAMMING("Hamming"),
    NONE("No window");

    //MEMBERS
    private String description;

    //CNSTR
    Window_Type(String description_arg){
        description = description_arg;
    }

    //GET
    String GetDescription(){
        return description;
    }
}
