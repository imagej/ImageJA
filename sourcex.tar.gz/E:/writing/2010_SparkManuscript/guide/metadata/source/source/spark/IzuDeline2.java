/*
 *
 * Applies Izu delining method
 *
 * Izu et al. (1998) Theoretical Analysis of the Ca21 Spark Amplitude
   Distribution. Biophysical Journal 75, 1144–1162.
 *
 * Sean Parsons, April 2010
 *
 */

package spark;

import metapicture.*;
import SPUtils.MetaUtils.*;

import javax.swing.*;
import ij.process.*;
import edu.emory.mathcs.jtransforms.fft.*;
import flanagan.analysis.*;
import SPUtils.*;
/**
 *
 * @author Sean
 */
public class IzuDeline2 extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)

    int nsec;           //number of sections

    public IzuDeline2(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;

        nsec = 1;

        //output picture?
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Delined");
        

    }

    void SetVariables(int nsec_arg){

        nsec = nsec_arg;

        output.name = output.name + "_" + "Delined" + MetaUtils.IntToStr(nsec);
        output.SetFilePath();
        output.SetPictureName();
    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;
        
        if(nsec < 1) nsec = 1;

        //dimensions
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();
        int xh = (int)Math.floor((double)xl/(double)nsec);
        
        //check for NaN
        Float myf = new Float(0);
        for (int j = 0; j < yl; j++)
            for(int i = 0; i < xl; i++)
                if(myf.isNaN(imp.getf(i, j))) imp.setf(i, j, 0);

        //fft object and array for holding data to be transformed
        FloatFFT_1D trans = new FloatFFT_1D(xh);
        float hold[] = new float[xh];

        //array for holding DC values from each section and regression object for this data
        double dc_y[] = new double[nsec];
        double dc_x[] = new double[nsec];
        Regression myreg = new Regression(dc_x, dc_y);
        double dc_fit[] = new double[2];

        //loop through rows
        for (int j = 0; j < yl; j++){

            //loop through sections
            for(int k = 0; k < nsec; k++){
                
                //get data
                for(int i = 0; i < xh; i++)
                    hold[i] = imp.getf(i + (k*xh), j);

                //transform
                trans.realForward(hold);

                //get DC amplitude
                dc_y[k] = (hold[0]/(float)xh);
                dc_x[k] = ((k*xh) + (0.5*xh));

            }
            
            //linear fit to DC values
            switch (nsec){
                
                case 1:
                    dc_fit[0] = dc_y[0];
                    dc_fit[1] = 0;
                    break;
                    
                case 2:
                    dc_fit[1] = (dc_y[1] - dc_y[0])/(dc_x[1] - dc_x[0]);
                    dc_fit[0] = dc_y[0] - (dc_x[0] * dc_fit[1]);
                    break;
                    
                default:
                    myreg = new Regression(dc_x, dc_y);
                    myreg.linear();
                    dc_fit = myreg.getBestEstimates();
                
            }
            
            //subtract
            for(int i = 0; i < xl; i++)
                imp_o.setf(i, j, imp.getf(i, j) - (float)(dc_fit[0] + (dc_fit[1]*i)));

        }


        //find mean of input and output
        float mean_input = 0;
        float mean_output = 0;
        float total = (float)(xl * yl);
        for (int j = 0; j < yl; j++)
            for (int i = 0; i < xl; i++){
                mean_input += (imp.getf(i, j)/total);
                mean_output += (imp_o.getf(i, j)/total);
            }

        //calculate difference
        float diff = mean_output - mean_input;

        //subtract difference, set values < 0 to 1
        for (int j = 0; j < yl; j++)
            for (int i = 0; i < xl; i++){
                imp_o.setf(i, j, imp_o.getf(i, j) - diff);
                if (imp_o.getf(i, j) < 0) imp_o.setf(i, j, 1);
            }

        //if input was 8bit, set  min, max to 0, 255
        if (input.OImage.getBytesPerPixel() == 1) imp_o.setMinAndMax(0, 255);

        //set output processors to OImage
        output.SetToOriginal();

        return true;

    }

    @Override
    public void done() {

          parent.WhenDelineDone();

    }


}
