/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package histogram;


import metapicture.*;
import SPUtils.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import ij.*;
import ij.process.*;
import ij.plugin.filter.*;
import ij.gui.*;

import flanagan.math.*;
/**
 *
 * @author Sean
 */
public class two2hist extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    histpanel parent;        //parent panel

    MetaObject input[];     //array of input objects
    MetaPicture output;     //histogram
    MetaTable moments;      //moments

    int polation_type;      //interpolation type (0 = none, 1 = bilinear, 2 = bicubic)
    boolean IsNormalised;   //normalise (probability density)
    boolean DoMoments;      //overlay moments

    int x_col;          //column index
    float x_min;        //range min
    float x_max;        //range max
    float x_bin;        //binsize
    int x_pixels;       //pixel width of output

    int y_col;          //column index
    float y_min;        //range min
    float y_max;        //range max
    float y_bin;        //binsize
    int y_pixels;       //pixel width of output

    public two2hist(histpanel parent_arg, MetaObject arg[]){

        parent = parent_arg;
        input = arg;

        polation_type = 0;
        IsNormalised = false;
        DoMoments = false;

        x_col = 0;
        x_min = 0;
        x_max = 10;
        x_bin = 1;
        x_pixels = 100;

        y_col = 0;
        y_min = 0;
        y_max = 10;
        y_bin = 1;
        y_pixels = 100;
        /*
        x_col = 17;
        x_min = -2.5f;
        x_max = 0.1f;
        x_bin = 0.01f;
        x_pixels = 500;

        y_col = 18;
        y_min = -5f;
        y_max = 0f;
        y_bin = 0.05f;
        y_pixels = 500;
        */
        //output picture
        output = new MetaPicture();

        //output metatable
        moments = new MetaTable();

    }

    void SetOptions(int polation_type_arg, boolean IsNormalised_arg, boolean DoMoments_arg){

        if ((polation_type_arg >= 0) || (polation_type_arg < 3)) polation_type = polation_type_arg;
        IsNormalised = IsNormalised_arg;
        DoMoments = DoMoments_arg;

    }

    void SetXVariables(int col, float min, float max, float bin, int pixels){

        if(col >= 0) x_col = col;
        x_min = min;
        x_max = max;
        if(x_max < x_min){
            float hold = x_max;
            x_max = x_min;
            x_min = hold;
        }
        if(bin > 0) x_bin = bin;
        if(pixels > 0) x_pixels = pixels;

    }

    void SetYVariables(int col, float min, float max, float bin, int pixels){

        if(col >= 0) y_col = col;
        y_min = min;
        y_max = max;
        if(y_max < y_min){
            float hold = y_max;
            y_max = y_min;
            y_min = hold;
        }
        if(bin > 0) y_bin = bin;
        if(pixels > 0) y_pixels = pixels;

    }


    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //calculate number of bins
        int x_nbins = (int)Math.ceil((x_max - x_min) / x_bin);
        int y_nbins = (int)Math.ceil((y_max - y_min) / y_bin);
        //bin maxima
        float x_b[] = new float[x_nbins];
        for(int i = 1; i <= x_nbins; i++) x_b[i-1] = x_min + (i * x_bin);
        float y_b[] = new float[y_nbins];
        for(int i = 1; i <= y_nbins; i++) y_b[i-1] = y_min + (i * y_bin);
        //count array
        float count[][] = new float[x_nbins][y_nbins];
        float sum = 0;      //total count
        
        //data for moment analysis
        ArrayList<CoorPair> xydata_total = new ArrayList<CoorPair>();
        ArrayList<CoorPair> xydata_item = new ArrayList<CoorPair>();
        ArrayList<MomentGroup> moment_list = new ArrayList<MomentGroup>();
        moment_list.add(new MomentGroup());     //add first MomentGroup object for total data

        //loop through input objects
        MetaTable curr = new MetaTable();
        double xval, yval;
        for(int i = 0; i < input.length; i++){

            //get metatable 
            if(input[i].type != 2) continue;
            curr = (MetaTable)input[i];
            
            //check has columns selected and at least one row
            if((curr.ncols <= x_col) ||
               (curr.ncols <= y_col) ||
               (curr.nrows <= 0)) continue;
            
            //loop through rows
            for(int r = 0; r < curr.nrows; r++){
                
                //get x and y values
                xval = MetaUtils.StrToDbl(curr.Get(r, x_col));
                yval = MetaUtils.StrToDbl(curr.Get(r, y_col));
         
                //make sure are in range
                if((xval < x_min) ||
                    (xval > x_b[x_nbins - 1]) ||
                    (yval < y_min) ||
                    (yval > y_b[y_nbins - 1])) continue;
                
                //add xy coordinates for moment analysis
                if(DoMoments == true){
                    xydata_total.add(new CoorPair(xval, yval));
                    xydata_item.add(new CoorPair(xval, yval));
                }
                
                //find x bin and y bin
                int xi, yi;
                for(xi = 0; xi < x_nbins; xi++)
                    if(xval < x_b[xi]) break;
                for(yi = 0; yi < y_nbins; yi++)
                    if(yval < y_b[yi]) break;
                
                //add count
                count[xi][y_nbins - yi - 1]++;
                sum++;
                
            }//end of row loop

            if(DoMoments == true){
                //add MomentGroup
                moment_list.add(new MomentGroup());
                moment_list.get(moment_list.size() - 1).name = curr.name;
                //calculate moments for current xy coordinates
                moment_list.get(moment_list.size() - 1).CalculateMoments(xydata_item);
                //clear current xy coordinates
                xydata_item.clear();
            }

            
        }//end of metatable loop


        //HISTOGRAM
        
        //create processor from count array
        FloatProcessor histo = new FloatProcessor(count);
        
        //normalise?
        if(IsNormalised == true){
            for(int i = 0; i < histo.getPixelCount(); i++)
                histo.setf(i, histo.getf(i) / sum);
            histo.setMinAndMax(0, 1);
        }

        //resize
        histo.setInterpolationMethod(polation_type);
        histo = (FloatProcessor)histo.resize(x_pixels, y_pixels);

        //set ouput image
        String proc =  curr.GetColumnTitle(x_col) + "vs" + curr.GetColumnTitle(y_col);
        if(DoMoments == true) output.SetBothProcessors(histo.duplicate());
            else output.SetBothProcessors(histo.duplicate());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input[0].metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Histogram2D");
        output.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "Histogram");
        
        double x_res = (double)x_bin * ((double)x_nbins / (double)x_pixels);
        output.metadata.SetValue(MetaTagType.X_NAME, curr.GetColumnTitle(x_col));
        output.metadata.SetValue(MetaTagType.X_UNIT, curr.GetColumnUnits(x_col));
        output.metadata.SetValue(MetaTagType.X_ORIGIN, MetaUtils.DblToStr(x_min));
        output.metadata.SetValue(MetaTagType.X_RES, MetaUtils.DblToStr(x_res));

        double y_res = (double)y_bin * ((double)y_nbins / (double)y_pixels);
        output.metadata.SetValue(MetaTagType.Y_NAME, curr.GetColumnTitle(y_col));
        output.metadata.SetValue(MetaTagType.Y_UNIT, curr.GetColumnUnits(y_col));
        output.metadata.SetValue(MetaTagType.Y_ORIGIN, MetaUtils.DblToStr(y_min));
        output.metadata.SetValue(MetaTagType.Y_RES, MetaUtils.DblToStr(y_res));


        if(IsNormalised == true) output.metadata.SetValue(MetaTagType.A_NAME, "P");
            else output.metadata.SetValue(MetaTagType.A_NAME, "N");
        output.metadata.SetValue(MetaTagType.A_UNIT, " ");
        output.metadata.SetValue(MetaTagType.A_ORIGIN, "0.0");
        output.metadata.SetValue(MetaTagType.A_RES, "1.0");
        
        output.path = input[0].path;
        output.name = ("2DHistogram" + proc);
        output.SetFilePath();
        output.SetPictureName();

        //MOMENTS
        
        if(DoMoments == true){

                //calculate moments for total data
                moment_list.get(0).CalculateMoments(xydata_total);
                moment_list.get(0).name = "TOTAL";

                //metadata
                moments.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input[0].metadata.GetValue(MetaTagType.UNIQ_ID));
                moments.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Histogram2D");
                moments.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "Moments");
                moments.path = input[0].path;
                moments.name = ("2DHistogram_moments");
                moments.SetFilePath();
                moments.SetPictureName();
            
                //add columns
                String x_unit = output.metadata.GetValue(MetaTagType.X_UNIT);
                String y_unit = output.metadata.GetValue(MetaTagType.Y_UNIT);
                String a_unit = output.metadata.GetValue(MetaTagType.A_UNIT);
                moments.AddColumn("file", "", 1);
                moments.AddColumn("N", "", 2);
                moments.AddColumn("centroid x", x_unit, 3);
                moments.AddColumn("centroid y", y_unit, 3);
                moments.AddColumn("minor axis eigenvalue", "", 3);
                moments.AddColumn("minor axis slope", y_unit + "." + x_unit + "-1", 3);
                moments.AddColumn("major axis eigenvalue", "", 3);
                moments.AddColumn("major axis slope", y_unit + "." + x_unit + "-1", 3);
                moments.AddColumn("eccentricity", "unitless", 3);

                //loop through moment list
                for (int i = 0; i < moment_list.size(); i++){

                    //add data to metatable
                    moments.AddRow();
                    moments.Set(i, 0, moment_list.get(i).name);
                    moments.Set(i, 1, moment_list.get(i).area);
                    moments.Set(i, 2, moment_list.get(i).centroid_x);
                    moments.Set(i, 3, moment_list.get(i).centroid_y);
                    moments.Set(i, 4, moment_list.get(i).minor_eigenvalue);
                    moments.Set(i, 5, moment_list.get(i).minor_slope);
                    moments.Set(i, 6, moment_list.get(i).major_eigenvalue);
                    moments.Set(i, 7, moment_list.get(i).major_slope);
                    moments.Set(i, 8, moment_list.get(i).eccentricity);

                }
                
                //draw centroid/vector on output image........
                
                //transformed centroid coordinates (pixels)
                int x0 = (int)Math.floor((moment_list.get(0).centroid_x - x_min) / x_res);
                int y0 = (int)Math.floor((moment_list.get(0).centroid_y - y_min) / y_res);

                //transformed major axis slope (dp/dp = dy/dx * xres/yres) and angle
                double mS = moment_list.get(0).major_slope * (x_res / y_res);
                double mA = Math.atan(mS);

                //transformed finish coordinates for major axis (pixels)
                int len = (int)Math.floor((double)y_pixels * 0.4);
                int x1 = x0 + (int)(Math.cos(mA) * (double)len);
                int y1 = y0 + (int)(Math.sin(mA) * (double)len);

                //draw
                int cw = 2;
                output.AddROI_fromDimage(new OvalRoi(x0 - cw, (y_pixels - y0) - 1 - cw, cw * 2, cw * 2));
                output.SetROIProperties(Color.GREEN, 2);
                output.AddROI(new Line(x0, (y_pixels - y0) - 1, x1, (y_pixels - y1) - 1));
                output.SetROIProperties(Color.RED, 2);
  
        }

        //return
        return true;
    }


    @Override
    public void done() {

        parent.WhenHistDone();

    }


}

