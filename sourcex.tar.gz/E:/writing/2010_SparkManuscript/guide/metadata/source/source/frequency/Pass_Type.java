/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package frequency;

/**
 *
 * @author Sean
 */
public enum Pass_Type {

    LOWPASS("LowPass"),
    HIGHPASS("HighPass"),
    BANDPASS("BandPass"),
    BANDSTOP("BandStop");

    //MEMBERS
    private String description;

    //CNSTR
    Pass_Type(String description_arg){
        description = description_arg;
    }

    //GET
    String GetDescription(){
        return description;
    }

}
