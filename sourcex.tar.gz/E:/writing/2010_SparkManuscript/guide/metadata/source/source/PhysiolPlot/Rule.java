/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PhysiolPlot;

import java.awt.*;
import javax.swing.*;
import SPUtils.*;


public class Rule extends JComponent { 
    
    int orientation;                            //orientation
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    public static final int SIZE = 35;          //width of ruler (pixels)
    public static final int TICKINTERVAL = 300;  //target tick interval (pixels)
    double major_int;                           //major tick interval (units)                       
    int major_ad;                               //number of places after decimel place

    int lenp;               //length (pixels)
    double lenu;            //length (units)
    double strt;            //start (units)
    String uname;           //unit name

    public Rule(int o, double strt_arg, double lenu_arg, String uname_arg) {

        orientation = o;
        lenp = 1000;                //length (pixels)
        strt = strt_arg;            //start (units)
        lenu = lenu_arg;           //length (units)
        uname = uname_arg;           //unit name
        SetMajorInterval();     //major tick interval (units)
        
    }

    //set pixel length
    public void setPixelSize(int lenp_arg) {
        
        lenp = lenp_arg;
        if (orientation == VERTICAL){
            setPreferredSize(new Dimension(SIZE, lenp));
        } else {
            setPreferredSize(new Dimension(lenp, SIZE));
        }
        SetMajorInterval();

    }
    
    //return major tick interval (units)
    private void SetMajorInterval(){
        
        //calculate target tick interval in units
        double target = ((double)TICKINTERVAL * lenu) / lenp;
        major_int = MetaUtils.GetNearestBase10(target); //major interval (units)

        //get places after decimel place
        double log_tick = Math.log10(major_int);
        if (log_tick < 0) major_ad = (int)Math.ceil(-log_tick);
            else major_ad = -1;

    }

    protected void paintComponent(Graphics g) {

        Rectangle drawHere = g.getClipBounds();
        
        double res =  (float)lenu / (float)lenp;   // resolution (units/pixel) 
        double minor_int = major_int / 10;  //minor tick intervals (units)
        
        // Fill clipping area with dirty brown/orange.
        g.setColor(new Color(100, 100, 255));  //!!!!!!!!!!!!!!!!!color
        g.fillRect(drawHere.x, drawHere.y, drawHere.width, drawHere.height);

        // Do the ruler labels in a small font that's black.
        g.setFont(new Font("SansSerif", Font.PLAIN, 10));
        g.setColor(Color.black);
        
        //unit names
        if (orientation == HORIZONTAL) g.drawString(uname,drawHere.x + 2, 21);
            else g.drawString(uname, 9, drawHere.y + 10);

        //start and end of visible ruler (units)
        double end = 0;
        double start = 0;
        if (orientation == HORIZONTAL) {
            start = strt + ((double)drawHere.x * res);
            end = strt + ((double)(drawHere.x + drawHere.width) * res);
        } else {
            start = strt + ((double)drawHere.y * res);
            end = strt + ((double)(drawHere.y + drawHere.height) * res);
        }

        
        //add ticks
        double tick_int = 0;
        int tick_len = 0;
        int pos = 0;
        //t = 0, major; t = 1, minor
        for (int t = 0; t < 2; t++){
            
            if (t == 0){
                tick_int = major_int;
                tick_len = 8;
            } else {
                tick_int = minor_int;
                tick_len = 4;
            }
        
            //mark positive ticks
            if (end > 0){
                
                for (double i = 0; i < end; i += tick_int){

                    if (i > start) {
                        pos = (int)((i - strt) / res);
                
                        if (orientation == HORIZONTAL) {
                            g.drawLine(pos, SIZE-1, pos, SIZE - tick_len);
                            if (t == 0) g.drawString(MetaUtils.DblToStr(i, major_ad), pos-3, 21);
                        } else {
                            g.drawLine(SIZE-1, pos, SIZE - tick_len, pos);
                            if (t == 0) g.drawString(MetaUtils.DblToStr(i, major_ad), 9, pos+3);
                        }
                    }

                }//end of tick loop

            }//end of positive ticks

            //mark positive ticks
            if (start < 0){

                for (double i = 0; i > start; i -= tick_int){

                    if (i < end) {
                        pos = (int)((i - strt) / res);

                        if (orientation == HORIZONTAL) {
                            g.drawLine(pos, SIZE-1, pos, SIZE - tick_len);
                            if (t == 0) g.drawString(MetaUtils.DblToStrNoZeroes(i), pos-3, 21);
                        } else {
                            g.drawLine(SIZE-1, pos, SIZE - tick_len, pos);
                            if (t == 0) g.drawString(MetaUtils.DblToStrNoZeroes(i), 9, pos+3);
                        }
                    }

                }//end of tick loop

            }//end of negative ticks

        }//end of major/minor tick loop

    }//end of function

}

