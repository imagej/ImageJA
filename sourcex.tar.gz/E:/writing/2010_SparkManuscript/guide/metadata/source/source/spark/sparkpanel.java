/*
 *
 * Analysis of linescans with sparks/puffs/etc, where linescan image x axis
   corresponds to time.
 *
 * - Cropping
 * - Izu method for delining
 * - Cheng method for normalisation
 * - Lee filter
 * - Confinement Tree algorithm for metric calculation
 *
 *
 * Sean Parsons, April 2010
 *
 * 
 */

package spark;

import metapicture.*;
import metapicture.MetaDataList.*;
import SPUtils.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.SwingWorker.*;

import ij.measure.Calibration.*;

public class sparkpanel extends JPanel implements ActionListener{

    //REFERENCE TO LIST
    MetaDataList myparent;  //metalist panel (to pass data to)

    //SWING WORKERS
    ScanCrop crop_task;
    IzuDeline2 deline_task;
    ChengRatio ratio_task;
    ManualRatio mratio_task;
    MXRRatio2 mxr_task;
    LeeFilter filter_task;
    Ctree ctree_task;
    NoiseImage noise_task;
    
    int indxs[];
    int indx_i;

    //GUI ELEMENTS
    //crop
    JButton crop_bt;        //do crop
    //Izu line removal
    JButton izu_bt;         //do Izu line removal
    JTextField izu_tf;
    //...Cheng ratioing
    JTextField sigmaf_tf;   //noise factor
    JTextField nmax_tf;     //maximum number of loops
    JButton ratio_bt;       //do ratio
    //Manual Ratio (select roi)
    JButton mratio_bt;        //do crop
    //MaxRegions ratio
    JTextField step_tf;      //level step
    JTextField back_tf;      //look back
    JRadioButton lineav_rb;     //line average f0?
    JButton mxr_bt;
    //....Lee filter
    JComboBox lee_cbx;
    String lee_arr[] = {"x", "xy"};
    JTextField sig_tf;      //sigma
    JTextField bxcar_tf;     //boxcar width
    JButton lee_bt;       //do filter
    //....confinement tree algorithm
    JTextField alphai_tf;   //alpha<i>
    JTextField beta_tf;     //beta
    JTextField minarea_tf;  //minimum area
    JButton ctree_bt;       //do confinement tree algorithm
    //Poisson noise image
    JTextField noisew_tf;   //width and height of image
    JTextField noiseh_tf;
    JTextField noisen_tf;   //number of images to generate
    JTextField noiseb_tf;   //base amplitude
    JTextField noisea_tf;   //noise amplitude (mean of Poisson distribution)
    JButton noise_bt;       //calculate image

    //CNSTR
    public sparkpanel(MetaDataList arg){

        //metadata list
        myparent = arg;
        indxs = new int[1];
        indx_i = -1;

        //input variable text fields and action buttons

        //crop
        crop_bt = new JButton("crop");
        crop_bt.addActionListener(this);
        //Izu line removal
        izu_bt = new JButton("calculate");
        izu_bt.addActionListener(this);
        izu_tf = new JTextField("1");
        //...Cheng ratioing
        sigmaf_tf = new JTextField("2.0");   //noise factor
        nmax_tf = new JTextField("20");     //maximum number of loops
        ratio_bt = new JButton("calculate"); //do ratio
        ratio_bt.addActionListener(this);
        //Manual Ratio (select roi)
        mratio_bt = new JButton("calculate");        //do ratio
        mratio_bt.addActionListener(this);
        //MaxRegions ratio
        step_tf = new JTextField("2");      //level step
        back_tf = new JTextField("2");      //back comparison
        lineav_rb = new JRadioButton("", true);
        mxr_bt = new JButton("calculate");
        mxr_bt.addActionListener(this);
        //....Lee filter
        lee_cbx = new JComboBox();
        for(int i = 0; i < lee_arr.length; i++) lee_cbx.addItem(lee_arr[i]);
        sig_tf = new JTextField("5.0");      //sigma
        bxcar_tf = new JTextField("5");     //boxcar width
        lee_bt = new JButton("calculate");       //do filter
        lee_bt.addActionListener(this);
        //....confinement tree algorithm
        alphai_tf = new JTextField("1.0");   //alpha<i>
        beta_tf = new JTextField("0.1");     //beta
        minarea_tf = new JTextField("5");  //minimum area
        ctree_bt = new JButton("calculate");  //do confinement tree algorithm
        ctree_bt.addActionListener(this);
        //Poisson noise image
        noisew_tf = new JTextField("512");   //width and height of image
        noiseh_tf = new JTextField("512");
        noisen_tf = new JTextField("10");   //number of images to generate
        noiseb_tf = new JTextField("10");   //base amplitude
        noisea_tf = new JTextField("5");   //noise amplitude (mean of Poisson distribution)
        noise_bt = new JButton("calculate");       //calculate image
        noise_bt.addActionListener(this);

        JPanel var_pn = new JPanel();
        var_pn.setLayout(new GridLayout(25, 3));

        //1
        var_pn.add(new JLabel("CROP"));
        var_pn.add(crop_bt);
        var_pn.add(new JLabel(""));
        //2
        var_pn.add(new JLabel("DELINE"));
        var_pn.add(izu_bt);
        var_pn.add(new JLabel(""));
        //3
        var_pn.add(new JLabel("n sections"));
        var_pn.add(izu_tf);
        var_pn.add(new JLabel(""));
        //4
        var_pn.add(new JLabel("CHENG RATIO"));
        var_pn.add(ratio_bt);
        var_pn.add(new JLabel(""));
        //5
        var_pn.add(new JLabel("F<sigma>"));
        var_pn.add(sigmaf_tf);
        var_pn.add(new JLabel(""));
        //6
        var_pn.add(new JLabel("N<loop>"));
        var_pn.add(nmax_tf);
        var_pn.add(new JLabel(""));
        //7
        var_pn.add(new JLabel("MANUAL RATIO"));
        var_pn.add(mratio_bt);
        var_pn.add(new JLabel(""));
        //8
        var_pn.add(new JLabel("MXR RATIO"));
        var_pn.add(mxr_bt);
        var_pn.add(new JLabel(""));
        //9
        var_pn.add(new JLabel("step"));
        var_pn.add(step_tf);
        var_pn.add(new JLabel(""));
        //10
        var_pn.add(new JLabel("Nback"));
        var_pn.add(back_tf);
        var_pn.add(new JLabel(""));
        //11
        var_pn.add(new JLabel("Line AV"));
        var_pn.add(lineav_rb);
        var_pn.add(new JLabel(""));
        //12
        var_pn.add(new JLabel("LEE FILTER"));
        var_pn.add(lee_bt);
        var_pn.add(new JLabel(""));
        //13
        var_pn.add(new JLabel("direction"));
        var_pn.add(lee_cbx);
        var_pn.add(new JLabel(""));
        //14
        var_pn.add(new JLabel("F<sigma>"));
        var_pn.add(sig_tf);
        var_pn.add(new JLabel(""));
        //15
        var_pn.add(new JLabel("W<boxcar>"));
        var_pn.add(bxcar_tf);
        var_pn.add(new JLabel("pixels"));
        //16
        var_pn.add(new JLabel("C TREE"));
        var_pn.add(ctree_bt);
        var_pn.add(new JLabel(""));
        //17
        var_pn.add(new JLabel("alpha<i>"));
        var_pn.add(alphai_tf);
        var_pn.add(new JLabel("F/F0"));
        //18
        var_pn.add(new JLabel("beta"));
        var_pn.add(beta_tf);
        var_pn.add(new JLabel("F/F0"));
        //19
        var_pn.add(new JLabel("Area<min>"));
        var_pn.add(minarea_tf);
        var_pn.add(new JLabel("xunit.yunit"));
        //20
        var_pn.add(new JLabel("POISSON NOISE"));
        var_pn.add(noise_bt);
        var_pn.add(new JLabel(""));
        //21
        var_pn.add(new JLabel("width"));
        var_pn.add(noisew_tf);
        var_pn.add(new JLabel("pixels"));
        //22
        var_pn.add(new JLabel("height"));
        var_pn.add(noiseh_tf);
        var_pn.add(new JLabel("pixels"));
        //23
        var_pn.add(new JLabel("n images"));
        var_pn.add(noisen_tf);
        var_pn.add(new JLabel(""));
        //24
        var_pn.add(new JLabel("base"));
        var_pn.add(noiseb_tf);
        var_pn.add(new JLabel(""));
        //25
        var_pn.add(new JLabel("noise mean"));
        var_pn.add(noisea_tf);
        var_pn.add(new JLabel(""));

        //add elements to this panel
        setLayout(new GridLayout(1, 1));
        add(var_pn);

    }

    //SWING WORKERS

    //crop
    void DoCrop(){
        
        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]); 
        //set up swing worker
        crop_task = new ScanCrop(this, myparent.GetCurrentPicture());
        crop_task.SetVariables();
        //set button text
        crop_bt.setText("processing...");
        crop_bt.disable();
        //execute
        crop_task.execute();

        
    }
    
    void WhenCropDone(){
        
        //add picture
        myparent.AddPicture(new MetaPicture(crop_task.output));
        myparent.ShowLatestAdded();   
        //set button
        crop_bt.enable();
        crop_bt.setText("crop");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoCrop();

    }

    //Izu deline
    void DoDeline(){

        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]);
        //set up swing worker
        deline_task = new IzuDeline2(this, myparent.GetCurrentPicture());
        deline_task.SetVariables((int)Math.floor(MetaUtils.StrToDbl(izu_tf.getText())));
        //set button text
        izu_bt.setText("processing...");
        izu_bt.disable();
        //execute
        deline_task.execute();

    }

    void WhenDelineDone(){

        //add picture
        myparent.AddPicture(new MetaPicture(deline_task.output));
        myparent.ShowLatestAdded();
        //set button
        izu_bt.enable();
        izu_bt.setText("calculate");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoDeline();


    }

    //Cheng ratio
    void DoRatio(){

        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]);
        //set up swing worker
        ratio_task = new ChengRatio(this, myparent.GetCurrentPicture());
        ratio_task.SetVariables((double)MetaUtils.StrToDbl(sigmaf_tf.getText()),
                                 (int)MetaUtils.StrToDbl(nmax_tf.getText()));
        //set button text
        ratio_bt.setText("processing...");
        ratio_bt.disable();
        //execute
        ratio_task.execute();

    }

    void WhenRatioDone(){

        //add picture
        myparent.AddPicture(new MetaPicture(ratio_task.output));
        myparent.ShowLatestAdded();
        //set button
        ratio_bt.enable();
        ratio_bt.setText("calculate");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoRatio();

    }

    //manual ratio
    void DoMRatio(){

        //ManualRatio mratio_task;
        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]);
        //set up swing worker
        mratio_task = new ManualRatio(this, myparent.GetCurrentPicture());
        mratio_task.SetVariables();
        //set button text
        mratio_bt.setText("processing...");
        mratio_bt.disable();
        //execute
        mratio_task.execute();


    }

    void WhenMRatioDone(){

        //add picture
        myparent.AddPicture(new MetaPicture(mratio_task.output));
        myparent.ShowLatestAdded();
        //set button
        mratio_bt.enable();
        mratio_bt.setText("calculate");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoMRatio();

    }

    //manual ratio
    void DoMXRRatio(){

        //ManualRatio mratio_task;
        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]);
        //set up swing worker
        mxr_task = new MXRRatio2(this, myparent.GetCurrentPicture());
        mxr_task.SetVariables((float)MetaUtils.StrToDbl(step_tf.getText()),
                                (int)MetaUtils.StrToDbl(back_tf.getText()),
                                lineav_rb.isSelected());
        //set button text
        mxr_bt.setText("processing...");
        mxr_bt.disable();
        //execute
        mxr_task.execute();


    }

    void WhenMXRRatioDone(){

        //add picture
        myparent.AddPicture(new MetaPicture(mxr_task.output));
        myparent.ShowLatestAdded();
        //set button
        mxr_bt.enable();
        mxr_bt.setText("calculate");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoMXRRatio();

    }

    //Lee filter
    void DoFilter(){

        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]);  
        //set up swing worker
        filter_task = new LeeFilter(this, myparent.GetCurrentPicture());
        filter_task.SetVariables((double)MetaUtils.StrToDbl(sig_tf.getText()),
                                 (int)MetaUtils.StrToDbl(bxcar_tf.getText()), lee_cbx.getSelectedIndex());  
        //set button text
        lee_bt.setText("processing...");
        lee_bt.disable();
        //execute
        filter_task.execute();

    }

    void WhenFilterDone(){
        
        //add picture
        myparent.AddPicture(new MetaPicture(filter_task.output));
        myparent.ShowLatestAdded();
        //set button
        lee_bt.enable();
        lee_bt.setText("calculate");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoFilter();

    }

    //confinement tree algorithm
    void DoCtree(){

        //set currently selected
        myparent.SetCurrentlyDisplayed(indxs[indx_i]);
        //set up swing worker
        ctree_task = new Ctree(this, myparent.GetCurrentPicture());
        ctree_task.SetVariables(MetaUtils.StrToDbl(alphai_tf.getText()),
                                MetaUtils.StrToDbl(beta_tf.getText()),
                                MetaUtils.StrToDbl(minarea_tf.getText()));
        //set button text
        ctree_bt.setText("processing...");
        ctree_bt.disable();
        //execute
        ctree_task.execute();

    }

    void WhenCtreeDone(){
        //add picture
        myparent.AddPicture(new MetaPicture(ctree_task.output));
        myparent.ShowLatestAdded();
        myparent.AddObject(new MetaTable(ctree_task.metrics));
        //set button
        ctree_bt.enable();
        ctree_bt.setText("calculate");
        //loop to next image selected
        indx_i++;
        if(indx_i < indxs.length) DoCtree();
    }

    //Poisson noise image
    void DoNoise(){

        //set up swing worker
        noise_task = new NoiseImage(this);
        noise_task.SetVariables((int)MetaUtils.StrToDbl(noisew_tf.getText()),
                                (int)MetaUtils.StrToDbl(noiseh_tf.getText()),
                                (int)MetaUtils.StrToDbl(noisen_tf.getText()),
                                MetaUtils.StrToDbl(noiseb_tf.getText()),
                                MetaUtils.StrToDbl(noisea_tf.getText()));
        //set button text
        noise_bt.setText("processing...");
        noise_bt.disable();
        //execute
        noise_task.execute();
    }
    
    void WhenNoiseDone(){
        
        //add picture
        for(int i = 0; i < noise_task.output.length; i++){
            myparent.AddPicture(new MetaPicture(noise_task.output[i]));
            myparent.ShowLatestAdded();
        }
        //set button
        noise_bt.enable();
        noise_bt.setText("calculate");
    }

    //BUTTON LISTENER
    public void actionPerformed(ActionEvent ae){

        //CROP
        if(ae.getSource() == crop_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoCrop();
        }
        //DELINE
        else if(ae.getSource() == izu_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoDeline();
        }
        //CHENG RATIO
        else if(ae.getSource() == ratio_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoRatio();
        }
        //MANUAL RATIO
        else if(ae.getSource() == mratio_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoMRatio();
        }
        //MAXIMUM REGION RATIO
        else if(ae.getSource() == mxr_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoMXRRatio();
        }
        //LEE FILTER
        else if(ae.getSource() == lee_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoFilter();
        }
        //CONFINEMENT TREE ALGORITHM
        else if(ae.getSource() == ctree_bt){
            indxs = myparent.GetCurrentlySelected();
            indx_i = 0;
            DoCtree();
        }
        //POISSON NOISE
        else if(ae.getSource() == noise_bt){   
            DoNoise();
        }


    }


}
