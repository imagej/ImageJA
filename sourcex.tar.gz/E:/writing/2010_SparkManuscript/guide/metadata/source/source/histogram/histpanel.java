/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package histogram;

import metapicture.*;
import metapicture.MetaDataList.*;
import SPUtils.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.SwingWorker.*;

import ij.measure.Calibration.*;
import ij.*;

/**
 *
 * @author Sean
 */
public class histpanel extends JPanel implements ActionListener{

    //REFERENCE TO LIST
    MetaDataList myparent;  //metalist panel (to pass data to)
    
    //SWING WORKERS
    two2hist hist_task;
    tablecollate coll_task;
    tablefilter filt_task;
    
    //GUI ELEMENTS
    
    //2D histogram
    JTextField xyvar_tf[][];     //array of text fields for xy variable input
    JComboBox intp_cbx;           //interpolatioin method
    String intp_arr[] = {"None", "Bilinear", "Bicubic"};
    JRadioButton norm_rb;       //normalise output (output probability density)
    JRadioButton mom_rb;        //overlay histogram with moments (RGB image)
    JButton do_bt;              //calculate histogram
    
    //metatable collate/filter table
    JButton collate_bt;        //do collation
    JTextField coli_tf;         //filter - column index
    JTextField cmin_tf;         //filter - min
    JTextField cmax_tf;         //filter - max
    JButton filt_bt;            //do filter
    
    //CNSTR
    public histpanel(MetaDataList arg){
        
        //metadata list
        myparent = arg;
        
        //2D HISTOGRAM
        
        //array of text fields for xy variable input
        // x column index           y column index
        // x min                    y min
        // x max                    y max
        // x binsize                y binsize
        // x width (pixels)         y width (pixels)
        xyvar_tf = new JTextField[2][5];
        for(int i = 0; i < 2; i++)
            for(int j = 0; j < 5; j++)
                xyvar_tf[i][j] = new JTextField("1");

        //interpolation
        intp_cbx = new JComboBox();
        for(int i = 0; i < intp_arr.length; i++) intp_cbx.addItem(intp_arr[i]);

        //radio button selections
        norm_rb = new JRadioButton("normalise", false);       //normalise output (output probability density)
        mom_rb = new JRadioButton("moments", false);        //overlay histogram with moments (RGB image)
        
        //calculate button
        do_bt = new JButton("calculate");
        do_bt.addActionListener(this);

        //add to panel
        JPanel var_pn = new JPanel();
        var_pn.setLayout(new GridLayout(10, 3));

        //1
        var_pn.add(new JLabel(""));
        var_pn.add(new JLabel("X"));
        var_pn.add(new JLabel("Y"));
        //2
        var_pn.add(new JLabel("column index"));
        var_pn.add(xyvar_tf[0][0]);
        var_pn.add(xyvar_tf[1][0]);
        //3
        var_pn.add(new JLabel("range min"));
        var_pn.add(xyvar_tf[0][1]);
        var_pn.add(xyvar_tf[1][1]);
        //4
        var_pn.add(new JLabel("range max"));
        var_pn.add(xyvar_tf[0][2]);
        var_pn.add(xyvar_tf[1][2]);
        //5
        var_pn.add(new JLabel("bin size"));
        var_pn.add(xyvar_tf[0][3]);
        var_pn.add(xyvar_tf[1][3]);
        //6
        var_pn.add(new JLabel("pixels"));
        var_pn.add(xyvar_tf[0][4]);
        var_pn.add(xyvar_tf[1][4]);
        //7
        var_pn.add(new JLabel("interpolation"));
        var_pn.add(intp_cbx);
        var_pn.add(new JLabel(""));
        //8
        var_pn.add(norm_rb);
        var_pn.add(new JLabel(""));
        var_pn.add(new JLabel(""));
        //9
        var_pn.add(mom_rb);
        var_pn.add(new JLabel(""));
        var_pn.add(new JLabel(""));
        //10
        var_pn.add(do_bt);
        var_pn.add(new JLabel(""));
        var_pn.add(new JLabel(""));
        
        //METATABLE FUNCTIONS
        collate_bt = new JButton("calculate");          //do collation
        collate_bt.addActionListener(this);
        coli_tf = new JTextField("1");                  //filter - column index
        cmin_tf = new JTextField("0");                  //filter - min
        cmax_tf = new JTextField("1");                  //filter - max
        filt_bt = new JButton("calculate");             //do filter
        filt_bt.addActionListener(this);

        //add to panel
        JPanel mt_pn = new JPanel();
        mt_pn.setLayout(new GridLayout(7, 2));

        //1
        mt_pn.add(new JLabel("COLLATE"));
        mt_pn.add(new JLabel(""));
        //2
        mt_pn.add(collate_bt);
        mt_pn.add(new JLabel(""));
        //3
        mt_pn.add(new JLabel("FILTER"));
        mt_pn.add(new JLabel(""));
        //4
        mt_pn.add(new JLabel("col index"));
        mt_pn.add(coli_tf);
        //5
        mt_pn.add(new JLabel("min"));
        mt_pn.add(cmin_tf);
        //6
        mt_pn.add(new JLabel("max"));
        mt_pn.add(cmax_tf);
        //7
        mt_pn.add(filt_bt);
        mt_pn.add(new JLabel(""));

        //MAIN PANEL
        setLayout(new GridLayout(2, 1));
        add(var_pn);
        add(mt_pn);
        
    }

    
    //SWING WORKERS
    
    //2D histogram
    public void DoHist(){
        
        //set up swing worker
        hist_task = new two2hist(this, myparent.GetCurrentlySelectedObjects());
        hist_task.SetOptions(intp_cbx.getSelectedIndex(), norm_rb.isSelected(), mom_rb.isSelected());

        hist_task.SetXVariables((int)MetaUtils.StrToDbl(xyvar_tf[0][0].getText()),
                                (float)MetaUtils.StrToDbl(xyvar_tf[0][1].getText()),
                                (float)MetaUtils.StrToDbl(xyvar_tf[0][2].getText()),
                                (float)MetaUtils.StrToDbl(xyvar_tf[0][3].getText()),
                                (int)MetaUtils.StrToDbl(xyvar_tf[0][4].getText()));
        hist_task.SetYVariables((int)MetaUtils.StrToDbl(xyvar_tf[1][0].getText()),
                                (float)MetaUtils.StrToDbl(xyvar_tf[1][1].getText()),
                                (float)MetaUtils.StrToDbl(xyvar_tf[1][2].getText()),
                                (float)MetaUtils.StrToDbl(xyvar_tf[1][3].getText()),
                                (int)MetaUtils.StrToDbl(xyvar_tf[1][4].getText()));

        //set button text
        do_bt.setText("processing...");
        do_bt.disable();
        //execute
        hist_task.execute();
            
    }
    
    public void WhenHistDone(){

        //add picture
        myparent.AddObject(new MetaPicture(hist_task.output));
        myparent.ShowLatestAdded();
        myparent.AddObject(new MetaTable(hist_task.moments));
        //set button
        do_bt.enable();
        do_bt.setText("calculate");

    }

    //2D histogram
    public void DoCollate(){

        //set up swing worker
        coll_task = new tablecollate(this, myparent.GetCurrentlySelectedObjects());
   
        //set button text
        collate_bt.setText("processing...");
        collate_bt.disable();
        //execute
        coll_task.execute();

    }

    public void WhenCollateDone(){

        //add collated table
        myparent.AddObject(new MetaTable(coll_task.output));
        //set button
        collate_bt.enable();
        collate_bt.setText("calculate");
        
    }

    //2D histogram
    public void DoFilter(){

        //set up swing worker
        filt_task = new tablefilter(this, myparent.GetCurrentlySelectedObjects());
        
        filt_task.SetVariables((int)MetaUtils.StrToDbl(coli_tf.getText()),
                                MetaUtils.StrToDbl(cmin_tf.getText()),
                                MetaUtils.StrToDbl(cmax_tf.getText()));
        

        //set button text
        filt_bt.setText("processing...");
        filt_bt.disable();
        //execute
        filt_task.execute();

    }

    public void WhenFilterDone(){

        //add tables
        for(int i = 0; i < filt_task.output.size(); i++)
            myparent.AddObject(new MetaTable(filt_task.output.get(i)));
        
        //set button
        filt_bt.enable();
        filt_bt.setText("calculate");

    }
    
    //BUTTON LISTENER
    public void actionPerformed(ActionEvent ae){

        //2D HISTOGRAM
        if(ae.getSource() == do_bt){
            DoHist();
        }
        //COLLATE
        else if(ae.getSource() == collate_bt){
            DoCollate();
        }
        //FILTER
        else if(ae.getSource() == filt_bt){
            DoFilter();
        }
      

    }

    
}
