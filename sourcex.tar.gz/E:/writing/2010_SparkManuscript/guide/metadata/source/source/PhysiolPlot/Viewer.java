/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PhysiolPlot;

import java.awt.*;
import java.awt.event.*;
import ij.*;
import ij.gui.*;
import ij.process.*;
import ij.WindowManager.*;

import ij.plugin.frame.*;

import metapicture.*;


import javax.swing.*;

public class Viewer extends JFrame {

        PhysiolViewer myv;

	public Viewer(MetaPicture arg) {

            super(arg.picname);

            myv = new PhysiolViewer(arg);
            myv.setOpaque(true);
            setContentPane(myv);

            pack();

        }
        
        public void Show(){
                
              setVisible(true);
                
        }

        public void Dispose(){

            dispose();

        }

}
