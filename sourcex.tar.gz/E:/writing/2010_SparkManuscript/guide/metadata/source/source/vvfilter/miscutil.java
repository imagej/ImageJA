/*
 An IIR filter library, translated from the c++ code of Vladimir L. Vassilevsky.
 *
 * Sean Parsons, April 2010
 *
 * BIQUAD.java
 * FILTER.java
 *
 * BIQUAD_TYPE.java
 * FILTER_FUNCTION.java
 * FILTER_TYPE.java
 *
 * bessel_tables.java
 * misutil.java
 * modphase.java (added by SP)
 *
 *
 */

package vvfilter;


public abstract class miscutil {

    miscutil(){}

    public static double srd(double x){
        return x*x;
    }

    public static int FloatToFract_4_20(double x){

        double xtmp;

        xtmp = Math.floor(0.5 + 1048576.0 * x);

        if(xtmp > 8388607.0) xtmp = 8388607.0;
        else if(xtmp < -8388607.0) xtmp = -8388607.0;

        x = xtmp/1048576.0;

        return(int)xtmp;
    }

    public static void Split24(byte bytes[], int x, int offset){
        if(0 + offset < bytes.length) bytes[0 + offset] = (byte) (0xff&(x>>16));
        if(1 + offset < bytes.length) bytes[1 + offset] = (byte) (0xff&(x>>8));
        if(2 + offset < bytes.length) bytes[2 + offset] = (byte) (0xff&x);
    }
    
    public static double TruncatePhaseDegrees(double phase_degree){

        if(phase_degree > 180.0)
        {
            while(phase_degree > 180.0) phase_degree -= 360.0;
        }
        else if(phase_degree < -180.0)
        {
            while(phase_degree < -180.0) phase_degree += 360.0;
        }

        return phase_degree;

    }
     
}
