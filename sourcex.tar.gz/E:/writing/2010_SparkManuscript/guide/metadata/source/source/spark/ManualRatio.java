/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package spark;


import metapicture.*;
import SPUtils.*;

import ij.process.*;
import javax.swing.*;
import java.awt.*;

import ij.gui.*;

public class ManualRatio extends SwingWorker<Boolean, Void>{


    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)


    public ManualRatio(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;

        //output picture?
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "ManualRatio");
        output.metadata.SetValueUnEditable(MetaTagType.A_NAME, "F/F0");
        output.metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, "0.0");
        output.metadata.SetValueUnEditable(MetaTagType.A_RES, "1.0");
        output.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "");
        output.name = output.name + "_" + "ManualRatio";
        output.SetFilePath();
        output.SetPictureName();

    }

    void SetVariables(){

    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //input and output image processors
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();
        
        //get roi of input DImage, scaled to input OImage
        Roi croi = input.GetTransROI(false, input.DImage.getRoi());

        //if croi is null set to entire image
        if (croi == null) croi = new Roi(0, 0, input.OImage.getWidth(), input.OImage.getHeight());

        //find average
        Rectangle b = croi.getBounds();
        float mean = 0;
        float total = b.width * b.height;
        for(int i = b.x; (i < (b.x + b.width)) && (i < xl); i++)
           for(int j = b.y; (j < (b.y + b.height)) && (j < yl); j++)
               mean += (imp.getf(i, j) / total);

        //divide image through by mean
        for(int i = 0; i < xl; i++)
           for(int j = 0; j < yl; j++)
               imp_o.setf(i, j, (imp.getf(i, j)/mean));

        //set output processors to OImage
        imp_o.setMinAndMax(0, 10.0);
        output.SetToOriginal();

        //return
        return true;

    }

    @Override
    public void done() {

          parent.WhenMRatioDone();

    }


}
