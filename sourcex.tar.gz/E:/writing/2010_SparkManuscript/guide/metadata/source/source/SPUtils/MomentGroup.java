/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SPUtils;

import java.util.ArrayList;
import flanagan.math.*;
/**
 *
 * @author Sean
 */
public class MomentGroup {

    public String name;             //name

    public double area;               //area = m<00>
    public double mass;               //mass

    public double centroid_x;         //centroid x coordinate = m<10>/m<00>
    public double centroid_y;         //centroid y coordinate = m<01>/m<00>

    public double minor_eigenvalue;          //major and minor axis
    public double minor_slope;
    public double minor_angle;
    public double major_eigenvalue;
    public double major_slope;
    public double major_angle;
    public double eccentricity;             //eccentricity

    public MomentGroup(){

        name = "";          //name

        area = 0;               //area
        mass = 0;               //mass

        centroid_x = 0;         //centroid coordinates
        centroid_y = 0;

        minor_eigenvalue = 0;          //major and minor axis
        minor_slope = 0;
        minor_angle = 0;
        major_eigenvalue = 0;
        major_slope = 0;
        major_angle = 0;
        eccentricity = 0;

    }

    //calculate moments for coordinate pairs
    public void CalculateMoments(ArrayList<CoorPair> xydata){
        
        //calculate moments
        double m00 = Moments.Moment(xydata, 0, 0);
        double m10 = Moments.Moment(xydata, 1, 0);
        double m01 = Moments.Moment(xydata, 0, 1);

        //calculate central moments
        double c00 = Moments.CentralMoment(xydata, 0, 0);
        double c20 = Moments.CentralMoment(xydata, 2, 0);
        double c02 = Moments.CentralMoment(xydata, 0, 2);
        double c11 = Moments.CentralMoment(xydata, 1, 1);

        //mjor and minor axis
        Matrix eigen = new Matrix(2, 2);
        eigen.setElement(0, 0, (c20 / c00));
        eigen.setElement(1, 0, (c11 / c00));
        eigen.setElement(0, 1, (c11 / c00));
        eigen.setElement(1, 1, (c02 / c00));
        double ev[] = new double[2];
        ev = eigen.getEigenValues();
        int c_major = MetaUtils.GetMaxCoor(ev);
        int c_minor = MetaUtils.GetMinCoor(ev);
        
        //set values
        mass = m00;
        area = m00;
        centroid_x = (m10 / m00);
        centroid_y = (m01 / m00);
        major_eigenvalue = ev[c_major];
        major_slope = -c11 / (ev[c_major] - c20);
        major_angle = Math.atan(major_slope);
        minor_eigenvalue = ev[c_minor];
        minor_slope = -c11 / (ev[c_minor] - c20);
        minor_angle = Math.atan(minor_slope);
        eccentricity = Math.sqrt(1 - (ev[c_minor] / ev[c_major]));
        
    }

    public void ConvertToReal(double xres_arg, double yres_arg, double ares_arg){

        area = (area * xres_arg * yres_arg);
        mass = (mass * xres_arg * yres_arg * ares_arg);
        centroid_x = (centroid_x * xres_arg);
        centroid_y = (centroid_y * yres_arg);
        minor_slope = (minor_slope * (yres_arg/xres_arg));
        major_slope = (major_slope * (yres_arg/xres_arg));
    }

    public void ConvertToPixels(double xres, double yres, double ares){

        //????????????????????????????????????????
    }

}
