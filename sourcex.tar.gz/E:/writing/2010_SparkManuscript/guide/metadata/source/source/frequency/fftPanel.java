/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package frequency;

import metapicture.*;
import metapicture.MetaDataList.*;
import SPUtils.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import javax.swing.SwingWorker.*;
import ij.process.*;

import ij.measure.Calibration.*;
/**
 *
 * @author Sean
 */
public class fftPanel extends JPanel implements TableModelListener, ActionListener{

    //REFERENCE TO LIST
    MetaDataList myparent;  //metalist panel (to pass data to)

    //test image and test image input parameters
    public MetaPicture test_image;
    int npics;      //count number of test images created
    
    //fft swing worker
    fft2D mytask;
    int optype;

    //GUI ELEMENTS

    //scrolled table for displaying test image attributes
    JTable test_table;
    JScrollPane test_scroll;
    MetaArray test_attr;
    
    //scrolled table for test image input parameters
    JTable input_table;
    JScrollPane input_scroll;
    
    //button panel
    JPanel but_panel;       //main panel
    
    JButton test_but;       //create test image
    
    JComboBox dimension_cbx;      //dimension options
    Dimension_Type dimension_arr[] = Dimension_Type.values();
    JComboBox window_cbx;     //window options
    Window_Type window_arr[] = Window_Type.values();
    JComboBox scale_cbx;    //a scaling options
    Scale_Type scale_arr[] = Scale_Type.values();
    JComboBox filter_cbx;    //filter type options
    Filter_Type filter_arr[] = Filter_Type.values();
    JComboBox pass_cbx;    //pass type options
    Pass_Type pass_arr[] = Pass_Type.values();
    
    JTextField order_tf;    //filter order
    JTextField[] freqarr_tf;  //filter frequencies  
    
    JButton spec_but;       //create spectra
    JButton filter_but;     //create filtered image
    JButton window_but;     //get window image
    JButton kernal_but;     //get filter kernal image

    //CNSTR
    public fftPanel(MetaDataList arg){

        //metadata list
        myparent = arg;

        ///test image and test image input parameters
        test_image = new MetaPicture();

        test_image.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "test image");
        test_image.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "sine waves");
        test_image.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, "null");

        test_image.metadata.SetValueUnEditable(MetaTagType.X_NAME, "time");
        test_image.metadata.SetValueUnEditable(MetaTagType.X_UNIT, "sec");
        test_image.metadata.SetValueUnEditable(MetaTagType.X_ORIGIN, "0.0");

        test_image.metadata.SetValueUnEditable(MetaTagType.Y_NAME, "space");
        test_image.metadata.SetValueUnEditable(MetaTagType.Y_UNIT, "cm");
        test_image.metadata.SetValueUnEditable(MetaTagType.Y_ORIGIN, "0.0");

        test_image.metadata.SetValueUnEditable(MetaTagType.A_NAME, "mag");
        test_image.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "arb");
        test_image.metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, "0.0");

        npics = 0;

        //GUI ELEMENTS
        
        //scrolled list for displaying test image data
        test_attr = new MetaArray();
        test_attr.AddTag(MetaTagType.X_WIDTH, "300");
        test_attr.AddTag(MetaTagType.X_NPIXELS, "800");
        test_attr.AddTag(MetaTagType.Y_WIDTH, "5");
        test_attr.AddTag(MetaTagType.Y_NPIXELS, "250");
   
        test_table = new JTable(4, 2);
        SetTestAttributes();
        test_table.getModel().addTableModelListener(this);
        test_scroll = new JScrollPane(test_table);
        
        //scrolled table for test image input parameters
        input_table = new JTable(20, 3);
        input_table.getModel().addTableModelListener(this);
        input_scroll = new JScrollPane(input_table);
        
        //button panel
       
        test_but  = new JButton("TEST IMAGE");  //create test image
        test_but.addActionListener(this);

        dimension_cbx = new JComboBox();             //dimension options
        for(int i = 0; i < dimension_arr.length; i++) dimension_cbx.addItem(dimension_arr[i].GetDescription());
        window_cbx = new JComboBox();                //window options
        for(int i = 0; i < window_arr.length; i++) window_cbx.addItem(window_arr[i].GetDescription());
        scale_cbx = new JComboBox();                 //scale options
        for(int i = 0; i < scale_arr.length; i++) scale_cbx.addItem(scale_arr[i].GetDescription());
        filter_cbx = new JComboBox();                //filter options
        for(int i = 0; i < filter_arr.length; i++) filter_cbx.addItem(filter_arr[i].GetDescription());
        pass_cbx = new JComboBox();                  //pass options
        for(int i = 0; i < pass_arr.length; i++) pass_cbx.addItem(pass_arr[i].GetDescription());
 
        order_tf = new JTextField("8");         //filter order
        
        freqarr_tf  = new JTextField[4] ;       //frequencies
        freqarr_tf[0] = new JTextField("1");
        freqarr_tf[1] = new JTextField("");
        freqarr_tf[2] = new JTextField("1");
        freqarr_tf[3] = new JTextField("");
        JPanel xfreq_pn = new JPanel();
        xfreq_pn.setLayout(new GridLayout(1,2));
        xfreq_pn.add(freqarr_tf[0]);
        xfreq_pn.add(freqarr_tf[1]);
        JPanel yfreq_pn = new JPanel();
        yfreq_pn.setLayout(new GridLayout(1,2));
        yfreq_pn.add(freqarr_tf[2]);
        yfreq_pn.add(freqarr_tf[3]);
    
        spec_but = new JButton("SPECTRA");       //create spectra
        spec_but.addActionListener(this);
        filter_but = new JButton("FILTER");     //create filtered image
        filter_but.addActionListener(this);
        window_but = new JButton("WINDOW");     //get window image
        window_but.addActionListener(this);
        kernal_but = new JButton("FILTER KERNAL");     //get filter kernal image
        kernal_but.addActionListener(this);
        
        but_panel = new JPanel();
        but_panel.setLayout(new GridLayout(11, 2));
        //1
        but_panel.add(test_but);
        but_panel.add(new JLabel(""));
        //2
        but_panel.add(new JLabel("dimensions"));
        but_panel.add(dimension_cbx);
        //3
        but_panel.add(new JLabel("windowing"));
        but_panel.add(window_cbx);
        //4
        but_panel.add(new JLabel("scaling"));
        but_panel.add(scale_cbx);
        //5
        but_panel.add(new JLabel("filter type"));
        but_panel.add(filter_cbx);
        //6
        but_panel.add(new JLabel("filter pass"));
        but_panel.add(pass_cbx);
        //7
        but_panel.add(new JLabel("filter order"));
        but_panel.add(order_tf);
        //8
        but_panel.add(new JLabel("x freq"));
        but_panel.add(xfreq_pn);
        //9
        but_panel.add(new JLabel("y freq"));
        but_panel.add(yfreq_pn);
        //10
        but_panel.add(spec_but);
        but_panel.add(filter_but);
        //11
        but_panel.add(window_but);
        but_panel.add(kernal_but);
       
        //add gui elements to main panel
        setLayout(new GridLayout(3,1));
        add(test_scroll);
        add(input_scroll);
        add(but_panel);

    }

    //TEST IMAGE
    //set test image attributes
    void SetTestAttributes(){

        for (int j = 0; j < test_attr.Length(); j++){
            test_table.setValueAt(test_attr.GetDescription(j), j, 0);
            test_table.setValueAt(test_attr.GetValue(j), j, 1);
        }

    }

    //entry to test image tables
    public void tableChanged(TableModelEvent te){

        //entry to test image attr table
        if(te.getSource() == test_table.getModel()){

            int col = te.getColumn();
            int row = te.getFirstRow();
            //if change was to second column....
            if (col == 1){
                //update test image attributes
                String readval = (String)test_table.getModel().getValueAt(row, col);
                test_attr.SetValueUnEditable(row, readval);
                SetTestAttributes();
            }
            
        }
       
    }

    //return number of full sets of variables for test image
    int GetNSetsTestVariable(){
        
        //find number of full sets (freq, vel, amp)...
        boolean full_set = false;
        int nsets = 0;
        //...loop through input table...
        for(int i = 0; i < input_table.getRowCount(); i++){
            full_set = true;
            for(int j = 0;  j < 3; j++){
                
                //...test if value id double
                if (SPUtils.MetaUtils.StrToDbl((String)input_table.getModel().getValueAt(i, j))== -1)
                    full_set = false;
                
                //...if it is not break from all loops
                if(full_set == false) break;
            }
            if(full_set == false) break;
            //otherwise count row
            nsets ++; 
        }
        
        return nsets;
   
    }
    
    //get test image variables from table
    double[][] GetTestVariables(){
        
        int nsets = GetNSetsTestVariable();
        
        //if there is at least one full set...
        if (nsets > 0){
            
            //create return array
            //y0 = frequency, y1 = velocity, y2 = amp
            double ret[][] = new double[nsets][3];
            for(int i = 0; i < nsets; i++)
                for(int j = 0;  j < 3; j++)
                    ret[i][j] = SPUtils.MetaUtils.StrToDbl((String)input_table.getModel().getValueAt(i, j));
            
            return ret;
         
        }
    
        return null;
        
    }

    //SWING WORKER
    void WhenDone(){
        
        myparent.AddPicture(new MetaPicture(mytask.output));
        myparent.ShowLatestAdded();

        //set button
        spec_but.enable();
        spec_but.setText("SPECTRA");
        filter_but.enable();
        filter_but.setText("FILTER");
        window_but.enable();
        window_but.setText("WINDOW");
        kernal_but.enable();
        kernal_but.setText("FILTER KERNAL");
        
    }

    //set up fft2D (swing worker)
    public void SetWorker(){

        mytask = new fft2D(this, myparent.GetCurrentPicture());
        mytask.SetVariables(dimension_arr[dimension_cbx.getSelectedIndex()],
                                window_arr[window_cbx.getSelectedIndex()],
                                scale_arr[scale_cbx.getSelectedIndex()],
                                filter_arr[filter_cbx.getSelectedIndex()],
                                pass_arr[pass_cbx.getSelectedIndex()],
                                (int)MetaUtils.StrToDbl(order_tf.getText()),
                                (float)MetaUtils.StrToDbl(freqarr_tf[0].getText()),
                                (float)MetaUtils.StrToDbl(freqarr_tf[1].getText()),
                                (float)MetaUtils.StrToDbl(freqarr_tf[2].getText()),
                                (float)MetaUtils.StrToDbl(freqarr_tf[3].getText()),
                                optype);

        //set button text
        spec_but.setText("processing...");
        spec_but.disable();
        filter_but.setText("processing...");
        filter_but.disable();
        window_but.setText("processing...");
        window_but.disable();
        kernal_but.setText("processing...");
        kernal_but.disable();

    }
    
    //button listener
    public void actionPerformed(ActionEvent ae){

        //CREATE TEST IMAGE
        if(ae.getSource() == test_but){
            
            //if there are sets of variables....
            int nsets = GetNSetsTestVariable();
            if (nsets > 0){
            
                //create array representing test image
                int xn = (int)SPUtils.MetaUtils.StrToDbl(test_attr.GetValue(MetaTagType.X_NPIXELS));
                double xl = SPUtils.MetaUtils.StrToDbl(test_attr.GetValue(MetaTagType.X_WIDTH));
                double xr = xl/(double)xn;      //resolution (units/pixel)
                int yn = (int)SPUtils.MetaUtils.StrToDbl(test_attr.GetValue(MetaTagType.Y_NPIXELS));
                double yl = SPUtils.MetaUtils.StrToDbl(test_attr.GetValue(MetaTagType.Y_WIDTH));
                double yr = yl/(double)yn;      //resolution (units/pixel)
            
                float data[][] = new float[xn][yn];
                double var[][] = GetTestVariables();        //y0 = frequency, y1 = velocity, y2 = amp
                
                //calculate data ......
                double val = 0;
                double x = 0;
                double y = 0;
                //loop through array
                for (int i = 0; i < xn; i++){
                for(int j = 0; j < yn; j++){
                        
                    //loop through variable sets
                    for(int s = 0; s < nsets; s++){

                        x = (double)i * xr;
                        y = (double)j * yr;
                        val = (x * 2 * Math.PI * var[s][0]);
                        if (var[s][1] != 0) val += (y * 2 * Math.PI * var[s][0] / var[s][1]);
                        data[i][j] += (float)(var[s][2] * Math.sin(val));
                        data[i][j] += (float) var[s][2];
                        
                    }
             
                }}

                //set test image
                FloatProcessor imp = new FloatProcessor(data);
                MetaPicture ret_image = new MetaPicture(test_image);
                ret_image.SetBothProcessors(imp);
                ret_image.SetFileData("C:\\SineTestImage_" + SPUtils.MetaUtils.IntToStr(npics) + ".tiff");
                ret_image.SetPictureName();
                ret_image.metadata.SetValueUnEditable(MetaTagType.CREAT_D, SPUtils.MetaUtils.GetDateTime());
                ret_image.metadata.SetValueUnEditable(MetaTagType.UNIQ_ID, SPUtils.MetaUtils.GetRandomString());
                ret_image.metadata.SetValueUnEditable(MetaTagType.X_RES, SPUtils.MetaUtils.DblToStr(xr));
                ret_image.metadata.SetValueUnEditable(MetaTagType.Y_RES, SPUtils.MetaUtils.DblToStr(yr));
                ret_image.metadata.SetValueUnEditable(MetaTagType.A_RES, "1.0");
                for (int  s = 0 ; s < nsets; s++){
                    ret_image.metadata.AddTag(MetaTagType.SINE_FREQ, SPUtils.MetaUtils.DblToStr(var[s][0]));
                    ret_image.metadata.AddTag(MetaTagType.SINE_VELO, SPUtils.MetaUtils.DblToStr(var[s][1]));
                    ret_image.metadata.AddTag(MetaTagType.SINE_AMP, SPUtils.MetaUtils.DblToStr(var[s][2]));
                }

                myparent.AddPicture(ret_image);
                myparent.ShowLatestAdded();

                npics++;

            }//end of if nsets > 0

        }
        //GET SPECTRA
        else if(ae.getSource() == spec_but){

            optype = 0;
            SetWorker();
            mytask.execute();

        }
        //GET FILTERED IMAGE
        else if(ae.getSource() == filter_but){

            optype = 1;
            SetWorker();
            mytask.execute();

        }
        //GET WINDOWING FUNCTION
        else if(ae.getSource() == window_but){

            optype = 2;
            SetWorker();
            mytask.execute();
 
        }
        //GET FILTER KERNAL
        else if(ae.getSource() == kernal_but){

            optype = 3;
            SetWorker();
            mytask.execute();

        }
        else;

    }

    


}
