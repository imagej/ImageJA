
import ij.plugin.*;
import metapicture.*;
/**
 *
 * @author Sean
 */
public class MetaData_V1 implements PlugIn {

    public void run(String arg) {

        MetaDataDialog mydialog = new MetaDataDialog(ij.IJ.getInstance(), "MetaData", false);
        mydialog.show();

    }



}
