//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************
 Name: MetaArray.java
 Function: Collection of meta data for an item of data (image/trace/etc)
 Author: Sean Parsons
 Date: February 2010

 Description:

 A number of possible meta data types are defined by the MetTagType enumeration.
 A MetTagType is associated with a value in class MetaTag.
 MetaArray contains an array of MetaTag objects.

 ****************************************************************************/
//////////////////////////////////////////////////////////////////////////////

package metapicture;
import SPUtils.MetaUtils;
import ij.*;
import java.util.*;

//an ArrayList of MetaTag objects (see below for class MetaTag)
public class MetaArray {

    //MEMBERS
    private ArrayList<MetaTag> array;       //array of MetaTags
    String path;                            //file path
    String name;                            //file name
    String ext;                             //file extension
    
    //CNSTR
    //default
    public MetaArray(){

        SetFileData("c:\\something.xxx");
        array = new ArrayList<MetaTag>();

    }


    public MetaArray(String fname){

        SetFileData(fname);

        array = new ArrayList<MetaTag>();
        AddTag(MetaTagType.CLASS_ID, "none");
        AddUniqID();
        AddTag(MetaTagType.CREAT_P, "none");
        AddTag(MetaTagType.DATATYPE, "DEFAULT");
        AddTimeDate();
        AddTag(MetaTagType.PARENT_ID, "null");
   
    }

    //copy
    public MetaArray(MetaArray arg){

        //copy all fields
        this.array = new ArrayList<MetaTag>();
        for (int i = 0; i < arg.array.size(); i++)
            this.array.add(new MetaTag(arg.array.get(i)));

        this.path = arg.path;
        this.name = arg.name;
        this.ext = arg.ext;

        //change unique ID and creation time
        SetValueUnEditable(MetaTagType.UNIQ_ID, MetaUtils.GetRandomString());
        SetValueUnEditable(MetaTagType.CREAT_D, MetaUtils.GetDateTime());

    }
    
    //from tab/new-line delimited string
    public MetaArray(String arg, String fname){

        SetFileData(fname);

        //initiate array and counter for number of tags found from arg string
        array = new ArrayList<MetaTag>();    
        int nTags = 0;                      
        
        //find start and end of meta data
        int st = arg.indexOf("METATAGS\n") + 9;
        int end = arg.indexOf("TAGEND\n");
   
        //if start and end found.....
        if ((st >= 0) &&
            (end > st)){
       
            //initiate variables
            int tag_st = st, tag_mid = 0, tag_end = 0; //tag start, middle and end indexes
            String TagType = "", TagValue = "";         //tag type and value substrings
            MetaTagType tag_type;                       //tag type
          
            //loop though string
            while (tag_end < end){
          
                //get tag middle (\t) and tag end(\n)
                //(tag start already initiated)
                tag_mid = arg.indexOf('\t', tag_st);
                tag_end = arg.indexOf('\n', tag_st);
                
                //if tag_st < tag_mid < tag_end (and neither is -1 and spaces between are > 1)
                if ((tag_st < tag_mid - 1) && (tag_mid < tag_end - 1)){
                    
                     //get tag type (start to \t) and value (\t to end) strings  
                     TagType = arg.substring(tag_st, tag_mid);
                     TagValue = arg.substring(tag_mid + 1, tag_end);

                     //if TagType is a valid MetaTagType, add MetaTag
                     try {
                         tag_type = MetaTagType.valueOf(TagType);
                         AddTag(tag_type, TagValue);
                         nTags ++;
                     } catch (IllegalArgumentException e){}  
                        
                }
                
                //set next tag start to last tag end
                tag_st = tag_end + 1;
     
            }//end of while loop
 
        }//end of if (end and start)
        
        //if no tags found (start and end not found or no tags in between found),
        //add some default tags
        if (nTags == 0){  
            AddTag(MetaTagType.CLASS_ID, "???");
            AddUniqID();
            AddTag(MetaTagType.CREAT_P, "ca imaging");
            AddTag(MetaTagType.DATATYPE, "linescan");
            AddTimeDate();
            AddTag(MetaTagType.PARENT_ID, "???");
        }
    
    }
    
    //set file stuff
    public void SetFileData(String arg){
        path = MetaUtils.GetFilePath(arg);
        name = MetaUtils.GetFileName(arg);
        ext = MetaUtils.GetFileExtension(arg);
    }
    
    //OTHER METHODS
    
    //get tab/new-line delimited string for attaching to file
    public String GetMetaString(){
        
        String ret = "METATAGS\n";
        for(int i = 0; i < array.size(); i++){  
            ret += array.get(i).type.toString();
            ret += "\t";
            ret += array.get(i).value;
            ret += "\n"; 
        }
        ret += "TAGEND\n";
        
        return ret;
        
    }
    
    //return length
    public int Length(){return array.size();}

    public boolean isempty(){return array.isEmpty();}
    
    //find array index with MetaTagType = arg
    //returns -1 if tag not found
    public int FindIndex(MetaTagType arg){
        for(int i = 0; i < array.size(); i++){
            if (array.get(i).type == arg) return i;
        }
        return -1; 
    }
    
    //get value
    //return null if tag not found
    public String GetValue(int index){
        if ((index < array.size()) &&
            (index >= 0))
            return array.get(index).value;
            else return null;
    }
    
    public String GetValue(MetaTagType arg){
        return GetValue(FindIndex(arg)); 
    }

    public String GetDescription(int index){
        if ((index < array.size()) &&
            (index >= 0))
            return array.get(index).GetDescription();
            else return null;
    }

    public MetaTagType GetTagType(int index){
        if ((index < array.size()) &&
            (index >= 0))
            return array.get(index).type;
        else return null;
    }
    
    //set value
    //return false if tag not found
    public boolean SetValue(int index, String val){
        
        //check that index is within range and is editable
        if ((index < array.size()) &&
            (index >= 0) &&
            (array.get(index).IsEditable())
            ){
            
            //check that if it is a number, the string is parsable to one
            if ((array.get(index).IsNumber()) &&
                (MetaUtils.StrToDbl(val) == -1))
                return false;
            
            //change value
            array.get(index).value = val;
            return true;
            
        }
        
        return false;    
        
    }
    
    public boolean SetValue(MetaTagType arg, String val){
        return SetValue(FindIndex(arg), val);   
    }

    //set value, regardless of IsEditable status
    //return false if tag not found
    public boolean SetValueUnEditable(int index, String val){

        //check that index is within range and is editable
        if ((index < array.size()) &&
            (index >= 0)
            ){

            //check that if it is a number, the string is parsable to one
            if ((array.get(index).IsNumber()) &&
                (MetaUtils.StrToDbl(val) == -1))
                return false;

            //change value
            array.get(index).value = val;
            return true;

        }

        return false;

    }

    public boolean SetValueUnEditable(MetaTagType arg, String val){
        return SetValueUnEditable(FindIndex(arg), val);
    }
    
    //add/insert MetaTag object to end of array
    //return false is unsuccessful (e.g. val is not a number/etc)
    public boolean AddTag(MetaTagType arg, String val){
        
        //check that if it is a number, the string is parsable to one
        if ((arg.IsNumber()) &&
            (MetaUtils.StrToDbl(val) == -1))
            return false;
        //add MetaTag
        array.add(new MetaTag(arg, val));
        return true;
        
    }
    
    public boolean InsertTag(MetaTagType arg, String val, int index){
        
        //check that if it is a number, the string is parsable to one
        if ((arg.IsNumber()) &&
            (MetaUtils.StrToDbl(val) == -1))
            return false;
        
        //add MetaTag
        if ((index >= 0) &&
            (index < array.size() - 1))
             array.add(index, new MetaTag(arg, val));
        else array.add(new MetaTag(arg, val)); 
        return true;
        
    }
    
    //add specific tags
    public boolean AddUniqID(){
        return AddTag(MetaTagType.UNIQ_ID, MetaUtils.GetRandomString());
    }

    public boolean AddTimeDate(){
        return AddTag(MetaTagType.CREAT_D, MetaUtils.GetDateTime());
    }

    //remove MetaTag object
    public boolean RemoveTag(int index){

        if ((index < array.size()) &&
            (index >= 0)){
            array.remove(index);
            return true;
        } else return false;
        
    }
    
    public boolean RemoveTag(MetaTagType arg){
        return RemoveTag(FindIndex(arg));
    }

    public boolean RemoveAll(){
        array.clear();
        return true;
    }
}

