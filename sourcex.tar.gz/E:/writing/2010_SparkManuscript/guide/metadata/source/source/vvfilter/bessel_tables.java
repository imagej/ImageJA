/*
 An IIR filter library, translated from the c++ code of Vladimir L. Vassilevsky.
 *
 * Sean Parsons, April 2010
 *
 * BIQUAD.java
 * FILTER.java
 *
 * BIQUAD_TYPE.java
 * FILTER_FUNCTION.java
 * FILTER_TYPE.java
 *
 * bessel_tables.java
 * misutil.java
 * modphase.java (added by SP)
 *
 *
 */

package vvfilter;

public abstract class bessel_tables {

    // Precalculated Bessel filter A1 A2 data
    static double bessel1[] = { 1.0, 0.0 };

    static double bessel2[] = { 1.361654, 0.618034 };

    static double bessel3[] = { 0.999629, 0.477191,
                            0.756043, 0.0 };

    static double bessel4[] = { 0.774254, 0.388991,
                         1.339664, 0.488904 };

    static double bessel5[] = { 0.621595, 0.324533,
                         1.140177, 0.412845,
                         0.665639, 0.0 };

    static double bessel6[] = { 0.513054, 0.275641,
                         0.968607, 0.350473,
                         1.221734, 0.388718 };

    static double bessel7[] = { 0.433228, 0.238072,
                         0.830363, 0.301095,
                         1.094437, 0.339457,
                         0.593694, 0.0 };

    static double bessel8[] = { 0.372765, 0.208745,
                         0.720236, 0.262125,
                         0.975366, 0.297924,
                         1.111250, 0.316161 };


    static double bessel9[] = { 0.325742, 0.185418,
                         0.631960, 0.231049,
                         0.871017, 0.263562,
                         1.024356, 0.283414,
                         0.538619, 0.0 };

    static double bessel10[] = { 0.288318, 0.166512,
                          0.560356, 0.205909,
                          0.781532, 0.235149,
                          0.939275, 0.254934,
                          1.021499, 0.264964 };

    static double bessel11[] = { 0.257940, 0.150928,
                          0.501515, 0.185268,
                          0.705206, 0.211495,
                          0.860698, 0.230458,
                          0.958389, 0.241998,
                          0.495859, 0.0  };

    static double bessel12[] = { 0.232862, 0.137889,
                          0.452546, 0.168086,
                          0.640003, 0.191640,
                          0.789953, 0.209464,
                          0.894879, 0.221511,
                          0.948908, 0.227595  };


     static double[] bessel_table[] = { bessel1,bessel2,bessel3,bessel4,
                                 bessel5,bessel6,bessel7,bessel8,
                                 bessel9,bessel10,bessel11,bessel12 };


}
