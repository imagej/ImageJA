/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PhysiolPlot;

import java.awt.*;
import java.awt.event.*;
import ij.*;
import ij.gui.*;
import ij.process.*;
import ij.WindowManager.*;
import javax.swing.*;
import ij.plugin.frame.*;


public class Viewer2 extends JFrame{

	public Viewer2(ImagePlus arg) {

            super("imageX");
        
            JScrollPane sp = new JScrollPane();
            sp.setViewportView((Canvas)arg.getCanvas());
            sp.setPreferredSize(new Dimension(300, 250));
            sp.setViewportBorder(
                BorderFactory.createLineBorder(Color.black));

            JPanel mypan = new JPanel();
            mypan.add(sp);
            add(mypan);
            setSize(300, 300);
            setVisible(true);
    }


}



