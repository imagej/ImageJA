/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package frequency;

import metapicture.*;
import SPUtils.MetaUtils.*;

import javax.swing.*;

import ij.process.*;


import edu.emory.mathcs.jtransforms.dht.*;
import edu.emory.mathcs.jtransforms.fft.*;
import marf.math.*;

/**
 *
 * @author Sean
 */
public class ffttwo extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    fftPanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture spectra;    //output picture (frequency spectra)
    
    //options
    int wndw_op;            //0 = none, 1 = Hamming
    int meth_op;            //0 = DHT, 1 = FFT
    int dim_op;            //0 = x, 1 = y, 2 = xy
    int scale_op;       //0 = mag, 1 = mag^2, 2 = dB

    //--------------------------------------------
    //CNSTR
    public ffttwo(fftPanel arg){

        //parent panel
        parent = arg;

        //output picture (2d frequency spectra)
        spectra = new MetaPicture();
        spectra.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "frequency spectra");
        
        //options
        wndw_op = 1;            //0 = none, 1 = Hamming
        meth_op = 0;            //0 = DHT, 1 = FFT
        dim_op = 2;            //0 = x, 1 = y, 2 = xy
        scale_op = 1;       //0 = mag, 1 = mag^2, 2 = dB
   
    }

    //------------------------------------------------------------
    void SetInput(MetaPicture arg, int meth_arg, int wndw_arg, int dim_arg, int scale_arg){
        
        input = arg;
        
        wndw_op = wndw_arg;            //0 = none, 1 = Hamming
        meth_op = meth_arg;            //0 = DHT, 1 = FFT
        dim_op = dim_arg;            //0 = x, 1 = y, 2 = xy
        scale_op = scale_arg;       //0 = mag, 1 = mag^2, 2 = dB
        
    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {
        
        if(input == null) return false;
 
        //get dimensions of input image
        int xn = input.OImage.getWidth();
        int yn = input.OImage.getHeight();
        
        //resolution of input and frequency intervals of output (unit-1)
        double xres = SPUtils.MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.X_RES));
        double yres = SPUtils.MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.Y_RES));
        if (xres <= 0) xres = 1; if (yres <= 0) yres = 1;
        double xint = 1 / (xn * xres);
        double yint = 1 / (yn * yres);
        
        //put image into array
        float data[][] = new float[xn][yn];
        for(int i = 0; i < xn; i++)
           for(int j = 0; j < yn; j++)
               data[i][j] = input.OImage.getProcessor().getf(i, j);
        
        //windowing
        String win = "";
        if (wndw_op > 0){

            float xwindow[] = new float[xn];
            float ywindow[] = new float[yn];
        
            switch (wndw_op){
            
                case 1:
                win = "(Hamming)";
                Algorithms.Hamming hma = new Algorithms.Hamming();
                for(int i = 0; i < xn; i++) xwindow[i] = (float)hma.hamming(i, xn);
                for(int j = 0; j < yn; j++) ywindow[j] = (float)hma.hamming(j, yn);
                break;

                default:
                win = "(no window)";
                for(int i = 0; i < xn; i++) xwindow[i] = 1;
                for(int j = 0; j < yn; j++) ywindow[j] = 1;
            
            }

            for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++){ 
                   if((dim_op == 0) || (dim_op == 2)) data[i][j] = data[i][j] * xwindow[i];
                   if((dim_op == 1) || (dim_op == 2)) data[i][j] = data[i][j] * ywindow[j];
            }

        }//end of if wndw_op > 0

        //holding arrays (for 1d transforms)
        float xhold[] = new float[xn];
        float yhold[] = new float[yn];
   
        //--------------------------------------------------------------------------
        //do ftt
        String proc = "";
        switch (meth_op){

            //DHT
            case 0:

            proc = "DHT";
            FloatDHT_1D xdht = new FloatDHT_1D(xn);
            FloatDHT_1D ydht = new FloatDHT_1D(yn);
            int k = 0;
       
            //perform transform along x
            if((dim_op == 0) || (dim_op == 2)){
                proc += "x";
                k = 0;
                for(int j = 0; j < yn; j++){
           
                    for(int i = 0; i < xn; i++)
                        xhold[i] = data[i][j];
           
                    xdht.forward(xhold);
           
                    k = xn/2;
                    for(int i = 0; i < xn; i++){
                        if(k >= xn) k = 0;
                        data[i][j] = xhold[k];
                        k ++;
                    }
                
                }
            }

            //perform transform along y
            if((dim_op == 1) || (dim_op == 2)){
                proc += "y";
                for(int i = 0; i < xn; i++){

                    for(int j = 0; j < yn; j++)
                        yhold[j] = data[i][j];

                    ydht.forward(yhold);

                    k = yn/2;
                    for(int j = 0; j < yn; j++){
                        if(k >= yn) k = 0;
                        data[i][j] = yhold[k];
                        k ++;
                    }

                }
            }
            break;//********************************************

            //FFT
            case 1:

            proc = "FFT";
            FloatFFT_1D xfft = new FloatFFT_1D(xn);
            FloatFFT_1D yfft = new FloatFFT_1D(yn);

            int p, q;
            //perform transform along x
            if((dim_op == 0) || (dim_op == 2)){
                proc += "x";
                for(int j = 0; j < yn; j++){

                    for(int i = 0; i < xn; i++)
                        xhold[i] = data[i][j];

                    xfft.realForward(xhold);

                    for(int i = 0; i < xn; i = i + 2){
                        p = (xn/2) + (i/2);
                        q = (xn/2) - (i/2);
                        if (p < xn) data[p][j] = xhold[i];
                        if (q > -1) data[q][j] = xhold[i];
                    }

                }
            }

            //perform transform along y
            if((dim_op == 1) || (dim_op == 2)){
                proc += "y";
                for(int i = 0; i < xn; i++){

                    for(int j = 0; j < yn; j++)
                        yhold[j] = data[i][j];

                    yfft.realForward(yhold);

                    for(int j = 0; j < yn; j = j + 2){
                        p = (yn/2) + (j/2);
                        q = (yn/2) - (j/2);
                        if (p < yn) data[i][p] = yhold[j];
                        if (q > -1) data[i][q] = yhold[j];
                    }

                }
            }
            break;//***********************************************

            default:

        }

        /////////////////////////////////////////////////////////

        //convert to absolute, real units
        String punit = input.metadata.GetValue(MetaTagType.A_UNIT);
        for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++)
                    data[i][j] = Math.abs(data[i][j]);
        
        if((dim_op == 0) || (dim_op == 2)){
            punit += ("." + input.metadata.GetValue(MetaTagType.X_UNIT));
            for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++)
                    data[i][j] *= xres;
        }

        if((dim_op == 1) || (dim_op == 2)){
            punit += ("." + input.metadata.GetValue(MetaTagType.Y_UNIT));
            for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++)
                    data[i][j] *= yres;
        }

        //scale
        switch (scale_op){

            //power
            case 0:
            spectra.metadata.SetValueUnEditable(MetaTagType.A_NAME, "power");
            spectra.metadata.SetValueUnEditable(MetaTagType.A_UNIT, punit);
            break;

            //power^2
            case 1:
            spectra.metadata.SetValueUnEditable(MetaTagType.A_NAME, "power");
            spectra.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "(" + punit + ")^2");
            for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++)
                    data[i][j] = (float)Math.pow(data[i][j], 2.0);
            break;

            //dB
            case 2:
            spectra.metadata.SetValueUnEditable(MetaTagType.A_NAME, "power");
            spectra.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "dB");
            for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++)
                    if (data[i][j] > 0) data[i][j] = 10 * (float)Math.log10(data[i][j]);
            break;

            //default
            default:
            spectra.metadata.SetValueUnEditable(MetaTagType.A_NAME, "power");
            spectra.metadata.SetValueUnEditable(MetaTagType.A_UNIT, "(" + punit + ")^2");
            for(int i = 0; i < xn; i++)
                for(int j = 0; j < yn; j++)
                    data[i][j] = (float)Math.pow(data[i][j], 2.0);
   
        }
        
        //find min/max of data, excluding zero frequency
        float min = data[0][0]; float max = 0;
        for(int i = (xn/2) + 5; i < xn; i++)
           for(int j = 0; j < yn; j++){
               
               if(data[i][j] > max) max = data[i][j];
               if(data[i][j] < min) min = data[i][j];
               
           }
        float factor = (float)255.0 / (max - min);
        spectra.metadata.SetValueUnEditable(MetaTagType.A_ORIGIN, SPUtils.MetaUtils.DblToStr(min));
        spectra.metadata.SetValueUnEditable(MetaTagType.A_RES, SPUtils.MetaUtils.DblToStr(1.0/factor));

        //put data into output image
        ByteProcessor imp = new ByteProcessor(xn, yn);
        for(int i = 0; i < xn; i++)
           for(int j = 0; j < yn; j++){
               imp.set(i, j, (byte)((data[i][j] - min) * factor));
           }
       
        spectra.SetBothProcessors(imp);
        spectra.SetFileData(input.path + input.name + "_" + proc + ".tif");
        spectra.SetPictureName();
        spectra.metadata.SetValueUnEditable(MetaTagType.UNIQ_ID, SPUtils.MetaUtils.GetRandomString());
        spectra.metadata.SetValueUnEditable(MetaTagType.CREAT_P, proc + " " + win);
        spectra.metadata.SetValueUnEditable(MetaTagType.CREAT_D, SPUtils.MetaUtils.GetDateTime());
        spectra.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));

        if((dim_op == 0) || (dim_op == 2)){
            spectra.metadata.SetValue(MetaTagType.X_NAME, "frequency");
            spectra.metadata.SetValue(MetaTagType.X_UNIT, input.metadata.GetValue(MetaTagType.X_UNIT) + "^-1");
            spectra.metadata.SetValue(MetaTagType.X_ORIGIN, SPUtils.MetaUtils.DblToStr(-(xn/2) * xint));
            spectra.metadata.SetValue(MetaTagType.X_RES, SPUtils.MetaUtils.DblToStr(xint));
        } else {
            spectra.metadata.SetValue(MetaTagType.X_NAME, input.metadata.GetValue(MetaTagType.X_NAME));
            spectra.metadata.SetValue(MetaTagType.X_UNIT, input.metadata.GetValue(MetaTagType.X_UNIT));
            spectra.metadata.SetValue(MetaTagType.X_ORIGIN, input.metadata.GetValue(MetaTagType.X_ORIGIN));
            spectra.metadata.SetValue(MetaTagType.X_RES, input.metadata.GetValue(MetaTagType.X_RES));
        }

        if((dim_op == 1) || (dim_op == 2)){
            spectra.metadata.SetValue(MetaTagType.Y_NAME, "frequency");
            spectra.metadata.SetValue(MetaTagType.Y_UNIT, input.metadata.GetValue(MetaTagType.Y_UNIT) + "^-1");
            spectra.metadata.SetValue(MetaTagType.Y_ORIGIN, SPUtils.MetaUtils.DblToStr(-(yn/2) * yint));
            spectra.metadata.SetValue(MetaTagType.Y_RES, SPUtils.MetaUtils.DblToStr(yint));
        } else {
            spectra.metadata.SetValue(MetaTagType.Y_NAME, input.metadata.GetValue(MetaTagType.Y_NAME));
            spectra.metadata.SetValue(MetaTagType.Y_UNIT, input.metadata.GetValue(MetaTagType.Y_UNIT));
            spectra.metadata.SetValue(MetaTagType.Y_ORIGIN, input.metadata.GetValue(MetaTagType.Y_ORIGIN));
            spectra.metadata.SetValue(MetaTagType.Y_RES, input.metadata.GetValue(MetaTagType.Y_RES));
        }

        return true;

    }

    @Override
    public void done() {

          parent.WhenDone();

    }

}
