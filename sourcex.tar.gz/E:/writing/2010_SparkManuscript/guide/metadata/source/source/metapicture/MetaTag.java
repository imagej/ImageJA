/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package metapicture;


//a MetaTagType object (enum MetaTagType below) with its string value
public class MetaTag {

    //MEMBERS
    MetaTagType type;   //tag type (see below)
    String value;       //tag value

    //CNSTR
    MetaTag(MetaTagType type_arg, String value_arg){
        type = type_arg;
        value = value_arg;
    }

    //copy cnstr
    MetaTag(MetaTag arg){

        this.type = arg.type;
        this.value = arg.value;

    }

    //shell methods of class MetaTagType
    String GetDescription(){return type.GetDescription();}
    boolean IsNumber(){return type.IsNumber();}
    boolean IsDouble(){return type.IsDouble();}
    boolean IsEditable(){return type.IsEditable();}

}