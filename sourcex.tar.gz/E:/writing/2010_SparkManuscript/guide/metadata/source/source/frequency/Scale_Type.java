/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package frequency;

/**
 *
 * @author Sean
 */
public enum Scale_Type {

    ABS("abs(a)"),
    SQR("a^2"),
    DB("dB");

    //MEMBERS
    private String description;

    //CNSTR
    Scale_Type(String description_arg){
        description = description_arg;
    }

    //GET
    String GetDescription(){
        return description;
    }

}
