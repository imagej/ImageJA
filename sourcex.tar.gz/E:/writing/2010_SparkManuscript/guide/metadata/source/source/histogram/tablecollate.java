/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package histogram;


import metapicture.*;
import SPUtils.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import ij.*;
import ij.process.*;
import ij.plugin.filter.*;
import ij.gui.*;


/**
 *
 * @author Sean
 */
public class tablecollate extends SwingWorker<Boolean, Void>{

    //------------------------------------------
    //DATA MEMBERS
    histpanel parent;        //parent panel

    MetaObject input[];     //array of input objects
    MetaTable output;       //colated table
 
    public tablecollate(histpanel parent_arg, MetaObject arg[]){
        parent = parent_arg;
        input = arg;
        
        output = new MetaTable();
    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;


        //loop through input objects
        MetaTable curr = new MetaTable();
        int count = 0;          //number of tables collated
        for(int i = 0; i < input.length; i++){

            //get metatable 
            if(input[i].type != 2) continue;
            curr = (MetaTable)input[i];
            count++;
            
            //with first table....
            if(count == 1){
                //make copy to initiate output
                output = new MetaTable(curr);
                output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "Table Collation");
                output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, curr.metadata.GetValue(MetaTagType.UNIQ_ID));
                output.path = curr.path;
                output.name = "Collated_Table";
                output.SetFilePath();
                output.SetPictureName();
                output.metadata.SetFileData(output.fpath);

                //add string column to record file name
                output.AddColumn("File", "", 1);
                output.Set(0, output.ncols - 1, curr.name);
                continue;
            }

            //with subsequent tables...
            for(int r = 0; r < curr.nrows; r++){

                //add row and set last column to file name
                output.AddRow();
                if(r == 0) output.Set(output.nrows - 1, output.ncols - 1, curr.name);
                    else output.Set(output.nrows - 1, output.ncols - 1, "");

                //copy data
                for(int c = 0; (c < output.ncols - 1) && (c < curr.ncols); c++){
                    output.Set(output.nrows - 1, c, curr.Get(r, c));
                }

            }//end of row loop


        }//end of metatable loop


        //return
        return true;
    }


    @Override
    public void done() {

        parent.WhenCollateDone();

    }


}

