/*
 An IIR filter library, translated from the c++ code of Vladimir L. Vassilevsky.
 *
 * Sean Parsons, April 2010
 * 
 * BIQUAD.java
 * FILTER.java
 *
 * BIQUAD_TYPE.java
 * FILTER_FUNCTION.java
 * FILTER_TYPE.java
 *
 * bessel_tables.java
 * misutil.java
 * modphase.java (added by SP)
 *
 *
 */
package vvfilter;


public enum FILTER_TYPE {

    FLAT_FILTER,
    BUTTERWORTH,
    BESSEL,
    LINKWITZ_RILEY,
    EQUALIZER 

}
