/*
 * Applies Confinement Tree algorithm
 *
 * Parsons and Bolton (2004) Localised calcium release events in cells from
 the muscle of guinea-pig gastric fundus. J Physiol 554, 687.
 *
 *
 * Sean Parsons, April 2010
 *
 *
 */
package spark;

import metapicture.*;
import SPUtils.*;
import javax.swing.*;
import ij.process.*;
import ij.gui.*;
import ij.*;
import java.awt.*;
import java.util.ArrayList;

import regions.*;
import contours.*;

public class Ctree extends SwingWorker<Boolean, Void>{


    //------------------------------------------
    //DATA MEMBERS
    sparkpanel parent;        //parent panel

    MetaPicture input;      //reference to input picture
    MetaPicture output;    //output picture (ratioed image)
    MetaTable metrics;      //output data

    double alphai;      //starting level
    double beta;        //step
    double mina;        //minimum area (xunits.yunits)
    
    public Ctree(sparkpanel parent_arg, MetaPicture arg){

        parent = parent_arg;
        input = arg;

        //output picture
        output = new MetaPicture(input);
        output.SetBothProcessors(input.OImage.getProcessor().duplicate().convertToFloat());
        output.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        output.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "CTree");
        output.name = output.name + "_" + "CTree";
        output.SetFilePath();
        output.SetPictureName();
        
        //output data
        metrics = new MetaTable();
        metrics.metadata.SetValueUnEditable(MetaTagType.PARENT_ID, input.metadata.GetValue(MetaTagType.UNIQ_ID));
        metrics.metadata.SetValueUnEditable(MetaTagType.CREAT_P, "CTree");
        metrics.metadata.SetValueUnEditable(MetaTagType.DATATYPE, "metric data");
        metrics.path = output.path;
        metrics.name = output.name + "_" + "CTreeData";
        metrics.ext = "txt";
        metrics.SetFilePath();

        //variables/etc
        alphai = 1.0;
        beta = 0.1;
        mina = 10;

    }

    void SetVariables(double alphai_arg, double beta_arg, double mina_arg){
        alphai = alphai_arg;
        if (beta_arg > 0) beta = beta_arg;
        if (mina_arg > 0) mina = mina_arg;
    }

    //--------------------------------------------------------------
    //background function (activated by this.execute)
    @Override
    public Boolean doInBackground() {

        if(input == null) return false;

        //dimensions
        ImageProcessor imp = input.OImage.getProcessor();
        ImageProcessor imp_o = output.OImage.getProcessor();
        int xl = imp.getWidth();
        int yl = imp.getHeight();
        int tp = xl * yl;
        String tunit = input.metadata.GetValue(MetaTagType.X_UNIT);
        String sunit = input.metadata.GetValue(MetaTagType.Y_UNIT);
        String aunit = input.metadata.GetValue(MetaTagType.A_UNIT);
        double tres = MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.X_RES));
        double sres = MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.Y_RES));
        double ares = MetaUtils.StrToDbl(input.metadata.GetValue(MetaTagType.A_RES));

        int mina_pixels = (int)Math.floor(mina / (tres * sres));

        //processor for segmentation
        ImageProcessor seg = imp_o.duplicate();
        ImageProcessor spark = imp_o.duplicate();
        for(int i = 0; i < spark.getPixelCount(); i++) spark.setf(i, 0);
        
        //region labeling object, with initial threshold
        DepthFirstLabeling labeling = new DepthFirstLabeling();

        //array of "binary objects" describing identified sparks
        ArrayList<BinaryRegion> sparks = new ArrayList<BinaryRegion>();

        //main algorithm loop
        double alpha = alphai;      //initiate alpha
        int rcount = 1;             //region count
        int scount = 0;             //spark count

        BinaryRegion aregion = new BinaryRegion(2);       //region
        float rmax = 0;             //region maximum
        float rahm = 0;             //region half maximum amplitude
        int max_xc = 0;             //maximum x and y coordinates
        int max_yc = 0;

        while (rcount > 0){
            
            //threshold segmentation processor
            for(int i = 0; i < xl; i++)
                for(int j = 0; j < yl; j++)
                    if (seg.getf(i, j) > 0)
                        if (imp.getf(i, j) > alpha)
                            seg.setf(i, j, 1);
                        else seg.setf(i, j, 0);
            
            //region label
            labeling = new DepthFirstLabeling(seg);  //!!!!!!!!!!!!!!!
            //labeling.Labeling(seg);
            seg = labeling.makeGrayImage();

            //number of regions
            if (labeling.regions == null) rcount = 0;
                else rcount = labeling.regions.size();
            if (rcount < 1) break;

            //go through regions
            for(int r = 0; r < labeling.regions.size(); r++){

                //region and label value
                aregion = labeling.regions.get(r);
            
                //if smaller than minimum size or touches edge....
                if (aregion.numberOfPixels <= mina_pixels){
                    //zero pixels
                    for(int i = aregion.left; i <= aregion.right; i++)
                        for(int j = aregion.top; j <= aregion.bottom; j++)
                            if (seg.getf(i, j) == aregion.label) seg.setf(i, j, 0);
                    //reduce count
                    rcount--;
                    //continue to next region
                    continue;
                }

                //find half maximum value
                rmax = 0;
                max_xc = 0;
                max_yc = 0;
                for(int i = aregion.left; i <= aregion.right; i++)
                        for(int j = aregion.top; j <= aregion.bottom; j++)
                            if ((seg.getf(i, j) == aregion.label) &&
                                (imp.getf(i, j) > rmax)){
                                    rmax = imp.getf(i, j);
                                    max_xc = i;
                                    max_yc = j;
                            }
                rahm = 1f + ((rmax - 1f)/2f);

                //if ahm<alpha+beta....
                if (rahm < alpha + beta){
          
                    //if alpha<ahm<alpha+beta, and not touching edges.....
                    if ((alpha < rahm) &&
                        (aregion.left > 0) &&
                        (aregion.right < (xl - 1)) &&
                        (aregion.top > 0) &&
                        (aregion.bottom < (yl - 1))){

                        //threshold labeling.labels array at ahm
                        for(int i = aregion.left; i <= aregion.right; i++)
                            for(int j = aregion.top; j <= aregion.bottom; j++)
                                if (seg.getf(i, j) == aregion.label){
                                    if (imp.getf(i,j) < rahm) labeling.labels[j * labeling.width + i] = labeling.BACKGROUND;
                                     else labeling.labels[j * labeling.width + i] = labeling.FOREGROUND;
                                }

                        //floodfill labeling.labels with -1 from maximum coordinates
                        labeling.floodFill(max_xc, max_yc, -1);

                        //find area
                        int npix = 0;
                        for(int i = aregion.left; i <= aregion.right; i++)
                            for(int j = aregion.top; j <= aregion.bottom; j++)
                                if (labeling.labels[j * labeling.width + i] == -1) npix++;
                          
                        //if area > minarea, add stats
                        if(npix > mina_pixels){

                            scount++;
                            //find mhm, ahm, etc
                            float sum = 0;
                            for(int i = aregion.left; i <= aregion.right; i++)
                                for(int j = aregion.top; j <= aregion.bottom; j++){
                                    if (labeling.labels[j * labeling.width + i] == -1) {
                                        spark.setf(i, j, scount);
                                        sum += (imp.getf(i, j) - rahm);
                                    }
                                    labeling.labels[j * labeling.width + i] = labeling.BACKGROUND;
                                }
                            //...add region to final spark list, calculate hmax, ahm 
                            sparks.add(new BinaryRegion(aregion));
                            sparks.get(sparks.size()-1).max_x = max_xc;
                            sparks.get(sparks.size()-1).max_y = max_yc;
                            //(x1/fwhm/etc recalculated after contouring, below)
                            sparks.get(sparks.size()-1).x1 = max_xc;
                            sparks.get(sparks.size()-1).x2 = max_xc + 1;
                            sparks.get(sparks.size()-1).y1 = max_yc;
                            sparks.get(sparks.size()-1).y2 = max_yc + 1;
                            sparks.get(sparks.size()-1).fdhm = 1;
                            sparks.get(sparks.size()-1).fwhm = 1;
             
                            sparks.get(sparks.size()-1).mhm = (double)sum * tres * sres * ares;
                            sparks.get(sparks.size()-1).ahm = (double)npix * tres * sres;
                            sparks.get(sparks.size()-1).hmax = rahm;
                            sparks.get(sparks.size()-1).label = scount;
                            sparks.get(sparks.size()-1).numberOfPixels = npix;
                 
                        }//end of if npix>mina_pixels
                        
                    }//end of alpha<ahm<alpha+beta, and not touching edges
                    
                    //zero pixels
                    for(int i = aregion.left; i <= aregion.right; i++)
                        for(int j = aregion.top; j <= aregion.bottom; j++)
                            if (seg.getf(i, j) == aregion.label) seg.setf(i, j, 0);
                            
                    //reduce count
                    rcount--;
                    
                    //continue to next region
                    continue;
                }
                //...otherwise (if ahm>alpha+beta)
                else {
                    //do something???
                }

            }//end of region loop

            alpha += beta;      //increment alpha

        }
  
        if (scount <= 0) return true;

        
        //get roi contours for identified sparks and calculate fwhm, fdhm in pixels
        //output.SetBothProcessors(imp_o.convertToRGB());
        ContourTracer tracer = new ContourTracer(spark);
        ArrayList<Contour> sparkcont = (ArrayList<Contour>)tracer.getOuterContours();
        Polygon mypoly = new Polygon();
        boolean match = false;
        for(int i = 0; i < sparkcont.size(); i++){
             try {

                //get polygon
                mypoly = (Polygon)sparkcont.get(i).makePolygon();
                if(mypoly == null) continue;

                //find matching contour
                match = false;
                for(int k = 0; k < sparks.size(); k++){
                    aregion = sparks.get(k);
                    if (mypoly.contains(aregion.max_x, aregion.max_y)){
                        match = true;
                        break;
                    }
                }

                //if a match....
                if (match) {
                    //calculate metrics
                    FindContourMetrics(mypoly, aregion);
                    //add roi
                    output.AddROI(new PolygonRoi(mypoly, 6));
                    output.SetROIProperties(Color.RED, 2);
                }
                
            }catch (Throwable e){}
        }

        //get metrics....
        metrics.AddColumn("max(t)", tunit, 3);        //0
        metrics.AddColumn("max(x)", sunit, 3);        //1
        metrics.AddColumn("b(t1)", tunit, 3);        //2
        metrics.AddColumn("b(t2)", tunit, 3);        //3
        metrics.AddColumn("b(x1)", sunit, 3);        //4
        metrics.AddColumn("b(x2)", sunit, 3);        //5

        metrics.AddColumn("MA", aunit, 3);        //6
        metrics.AddColumn("MA-1", aunit, 3);        //7
        metrics.AddColumn("hMA", aunit, 3);        //8
        metrics.AddColumn("AHM", sunit + "." + tunit, 3);        //9
        metrics.AddColumn("MHM", sunit + "." + tunit + "." + aunit, 3);        //10
        metrics.AddColumn("FDHM", tunit, 3);        //11
        metrics.AddColumn("FWHM", sunit, 3);        //12

        metrics.AddColumn("log(MA)", aunit, 3);        //13
        metrics.AddColumn("log(MA-1)", aunit, 3);        //14
        metrics.AddColumn("log(hMA)", aunit, 3);        //15
        metrics.AddColumn("log(MHM/AHM)", aunit, 3);    //16
        metrics.AddColumn("log(AHM)", sunit + "." + tunit, 3);        //17
        metrics.AddColumn("log(MHM)", sunit + "." + tunit + "." + aunit, 3);        //18
        metrics.AddColumn("log(FDHM)", tunit, 3);        //19
        metrics.AddColumn("log(FWHM)", sunit, 3);        //20

        metrics.AddVariable("alpha<i> (" + aunit + ")", alphai);
        metrics.AddVariable("beta (" + aunit + ")", beta);
        metrics.AddVariable("min area (pixels)", mina_pixels);
        metrics.AddVariable("min area (" + sunit + "." + tunit + ")", mina);

        //go through spark list
        for(int i = 0; i < sparks.size(); i++){

            //get BinaryRegion object for spark
            aregion = sparks.get(i);

            //add fdhm/fwhm rois
            output.AddROI(new Line(aregion.x1, aregion.max_y, aregion.x2, aregion.max_y));
            output.SetROIProperties(Color.GREEN, 2);
            output.AddROI(new Line(aregion.max_x, aregion.y1, aregion.max_x, aregion.y2));
            output.SetROIProperties(Color.GREEN, 2);

            //add row to MetaTable
            metrics.AddRow();

            //centre, bounds
            //metrics.Set(i, 0, );
            metrics.Set(i, 0, aregion.max_x * tres);
            metrics.Set(i, 1, aregion.max_y * sres);
            metrics.Set(i, 2, aregion.x1 * tres);
            metrics.Set(i, 3, aregion.x2 * tres);
            metrics.Set(i, 4, aregion.y1 * sres);
            metrics.Set(i, 5, aregion.y2 * sres);

            //max, hmax, ahm, mhm
            metrics.Set(i, 6, ((aregion.hmax -1) * 2) + 1);
            metrics.Set(i, 7, ((aregion.hmax - 1) * 2));
            metrics.Set(i, 8, aregion.hmax);
            metrics.Set(i, 9, aregion.ahm);
            metrics.Set(i, 10, aregion.mhm);
            metrics.Set(i, 11, aregion.fdhm * tres);
            metrics.Set(i, 12, aregion.fwhm * sres);

            metrics.Set(i, 13, Math.log10(((aregion.hmax -1) * 2) + 1));
            metrics.Set(i, 14, Math.log10(((aregion.hmax - 1) * 2)));
            metrics.Set(i, 15, Math.log10(aregion.hmax));
            metrics.Set(i, 16, Math.log10(aregion.mhm/aregion.ahm));
            metrics.Set(i, 17, Math.log10(aregion.ahm));
            metrics.Set(i, 18, Math.log10(aregion.mhm));
            metrics.Set(i, 19, Math.log10(aregion.fdhm * tres));
            metrics.Set(i, 20, Math.log10(aregion.fwhm * sres));
            
        }
        
        //write out metrics metatable
        //metrics.WriteData(metrics.fpath);

        //return
        return true;

    }

    @Override
    public void done() {

          parent.WhenCtreeDone();

    }
    
    
    private void FindContourMetrics(Polygon parg, BinaryRegion barg){
        
        barg.fwhm = 0;
        barg.fdhm = 0;

        int p = 0;
        while (parg.contains(barg.max_x, barg.max_y + p)) p++;
        barg.fwhm += p;
        barg.y2 = barg.max_y + p;

        p = 1;
        while (parg.contains(barg.max_x, barg.max_y - p)) p++;
        barg.fwhm += p;
        if(p > 1) p--;
        barg.y1 = barg.max_y - p;

        p = 0;
        while (parg.contains(barg.max_x + p, barg.max_y)) p++;
        barg.fdhm += p;
        barg.x2 = barg.max_x + p;

        p = 1;
        while (parg.contains(barg.max_x - p, barg.max_y)) p++;
        barg.fdhm += p;
        if(p > 1) p--;
        barg.x1 = barg.max_x - p;

    }

}
