/**
 * This sample code is made available as part of the book "Digital Image
 * Processing - An Algorithmic Introduction using Java" by Wilhelm Burger
 * and Mark J. Burge, Copyright (C) 2005-2009 Springer-Verlag Berlin, 
 * Heidelberg, New York.
 * Note that this code comes with absolutely no warranty of any kind.
 * See http://www.imagingbook.com for details and licensing conditions.
 * 
 * Date: 2009/11/15
 */

package regions;

import java.awt.Rectangle;
import java.awt.geom.Point2D;

/*
 * This class is used to incrementally compute and maintain
 * the statistics of a binary region.
 */

public class BinaryRegion {
	public int label;
	public int numberOfPixels = 0;
	public double xc = Double.NaN;
	public double yc = Double.NaN;
	public int left = Integer.MAX_VALUE;
	public int right = -1;
	public int top = Integer.MAX_VALUE;
	public int bottom = -1;
	
	// auxiliary variables
	int x_sum  = 0;
	int y_sum  = 0;
	int x2_sum = 0;
	int y2_sum = 0;

        //added by Sean Parsons (spark metrics)
        public int max_x = 0;
        public int max_y = 0;
        public double hmax = 0;
        public double ahm = 0;
        public double mhm = 0;
        public double fwhm = 0;
        public double fdhm = 0;
        public int x1 = 0;
        public int x2 = 0;
        public int y1 = 0;
        public int y2 = 0;
	
	// ------- constructor --------------------------

	public BinaryRegion(int id){
		this.label = id;
	}

        //copy cnstr added by Sean Parsons
        public BinaryRegion(BinaryRegion arg){
            label = arg.label;
            numberOfPixels = arg.numberOfPixels;
            xc = arg.xc;
            yc = arg.yc;
            left = arg.left;
            right = arg.right;
            top = arg.top;
            bottom = arg.bottom;

            x_sum  = arg.x_sum;
            y_sum  = arg.y_sum;
            x2_sum = arg.x2_sum;
            y2_sum = arg.y2_sum;

            //added by Sean Parsons (spark metrics)
            max_x = arg.max_x;
            max_y = arg.max_y;
            hmax = arg.hmax;
            ahm = arg.ahm;
            mhm = arg.mhm;
            fwhm = arg.fwhm;
            fdhm = arg.fdhm;
            x1 = arg.x1;
            x2 = arg.x2;
            y1 = arg.y1;
            y2 = arg.y2;

	}
	
	// ------- public methods --------------------------
	
	public int getLabel() {
		return this.label;
	}
	
	public int getSize() {
		return this.numberOfPixels;
	}
	
	public Rectangle getBoundingBox() {
		if (left == Integer.MAX_VALUE) 
			return null;
		else
			return new Rectangle(left, top, right-left+1, bottom-top+1);
	}
	
	public Point2D.Double getCenter(){
		if (Double.isNaN(xc))
			return null;
		else
			return new Point2D.Double(xc, yc);
	}
	
	/* Use this method to add a single pixel to this region. Updates summation
	 * and boundary variables used to calculate various region statistics.
	 */
	public void addPixel(int x, int y){
		numberOfPixels = numberOfPixels + 1;
		x_sum = x_sum + x;
		y_sum = y_sum + y;
		x2_sum = x2_sum + x*x;
		y2_sum = y2_sum + y*y;
		if (x<left) left = x;
		if (y<top)  top = y;
		if (x>right) right = x;
		if (y>bottom) bottom = y;
	}
	
	/* Call this method to update the region's statistics. For now only the 
	 * center coordinates (xc, yc) are updated. Add additional statements as
	 * needed to update your own region statistics.
	 */
	public void update(){
		if (numberOfPixels > 0){
			xc = (double) x_sum / numberOfPixels;
			yc = (double) y_sum / numberOfPixels;
		}
	}
	
	public String toString(){
		return
			"Region: " + label +
			" / pixels: " + numberOfPixels +
			" / bbox: (" + left + "," + top + "," + right + "," + bottom + ")" +
			" / center: (" + trunc(xc,2) + "," + trunc(yc,2) + ")"
			;
	}
	
	// --------- local auxiliary methods -------------------
	
	String trunc(double d){
		long k = Math.round(d * 100);
		return String.valueOf(k/100.0);
	}
	
	String trunc(double d, int precision){
		double m =  Math.pow(10,precision);
		long k = Math.round(d * m);
		return String.valueOf(k/m);
	}

}
