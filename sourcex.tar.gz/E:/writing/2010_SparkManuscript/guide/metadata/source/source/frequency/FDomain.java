/*

class for frequency domain manipulations of 1D data (spectra, windowing, filtering)
 *
 * Uses jtransforms library for FFT, marfmath library for window functions and
   a translation (from the c++) of Vladimir Vassilevsky's filter design code
   (see package vvfilter).
 * 
 *
 Sean Parsons, Mar-May 2010
 */

////////////////////////////////////////////////////////////
/* DATA ORDERS
 
 f(i) = i/ND

 where  f = frequency,
        i = integer,
        N = number of samples,
        D = sample interval

array[indx]      f[i]               f[i]
(filter1/   (gsl, multi-radix)    (jtransforms)
 filter2/
 fft)

 * 0            real[0]             real[0]
 * 1            real[1]             imag[1]
 * 2            imag[1]             real[1]
 * 3            real[2]             imag[2]
 * 4            imag[2]             real[2]
 * 5            real[3]             imag[3]
 * .
 * .
 * (n/2)
 *
 * real,        indx = (i*2)-1      indx = i*2
 * imag,        indx = i*2          indx = (i*2)-1
 *
 * output from all "Do" operations is put into hold2[]
 */
/////////////////////////////////////////////////////////////

package frequency;

import edu.emory.mathcs.jtransforms.fft.*;
import marf.math.*;
import vvfilter.*;

public class FDomain {

    //data
    private int n;          //number of samples
    float delta;    //interval (units/sample)
    float data[];   //data (time domain)
    float hold[];   //holding array
    float hold2[];  //output data

    //fft
    private FloatFFT_1D fft;        //transform object

    //filter design
    FILTER vladfilter;

    //filtering
    Filter_Type filter_type;    //filter type
    Pass_Type pass_type;        //pass type (low/high/band/stop)
    int filter_order;           //filter order
    private float filter1[];   //arrays (1st and 2nd pass)
    private float filter2[];
    float f1;                   //frequencies (1st and 2nd pass)
    float f2;                   
    FILTER_FUNCTION ff1;        //pass types (1st and 2nd pass)
    FILTER_FUNCTION ff2;

    //windowing
    private float window[];             //window
    Window_Type window_type;    //window type

    int c;

    //CNSTR
    public FDomain(int n_arg, float delta_arg){

        n = n_arg;
        delta = delta_arg;
        data = new float[n];
        hold = new float[n];
        hold2 = new float[n];
        
        SetTransform();
        SetFilter();
        SetWindow();
        c = 0;
    }

    //PARAMETER SET UP
    
    public void SetData(int idx, float val){
        if ((idx >= 0) && (idx < n)) data[idx] = val;
    }
    
    public void SetData(float[] arg){
        for (int i = 0; (i < n) && (i < arg.length); i++)
            data[i] = arg[i]; 
    }

    public void SetTransform(){  
        fft = new FloatFFT_1D(n);
    }
    
    public void SetFilter(){
        
        filter_type = Filter_Type.BUTTERWORTH;
        pass_type = Pass_Type.LOWPASS;       
        filter_order = 8;         
        f1 = 1.0f;              //!!!!!!           
        f2 = 2.1f;
        SetFilterArray();
        
    }

    public void SetFilter(Filter_Type ftype_arg, Pass_Type ptype_arg, int order_arg, float f1_arg, float f2_arg){

        filter_type = ftype_arg;
        pass_type = ptype_arg;
        if ((order_arg <= 0) || (order_arg > 12)) filter_order = 8; else filter_order = order_arg;
        if (f1 <= 0) f1 = 1; else f1 = f1_arg;
        if (f2 <= 0) f2 = 1; else f2 = f2_arg;
        SetFilterArray();

    }

    public void SetFilterArray(){

        //initiate filter array and filter design objects
        if (filter1 == null) filter1 = new float[n];
        if (filter2 == null) filter2 = new float[n];
        if (vladfilter == null) vladfilter = new FILTER();
        
        //sampling frequency
        double rsample = 1.0/delta;
        
        //filter type
        FILTER_TYPE ft = FILTER_TYPE.BESSEL;
        switch (filter_type){
            case BESSEL: ft = FILTER_TYPE.BESSEL;
            break;
            case BUTTERWORTH: ft = FILTER_TYPE.BUTTERWORTH;
            break;
        }
        
        //filter functions for 1st and 2nd pass 
        switch (pass_type){
            
            case LOWPASS:
                ff1 = FILTER_FUNCTION.LPF;
                ff2 = null;
                break;
            
            case HIGHPASS:
                ff1 = null;
                ff2 = FILTER_FUNCTION.HPF;
                break;
                
            case BANDPASS:
                ff1 = FILTER_FUNCTION.HPF;
                ff2 = FILTER_FUNCTION.LPF;
                
            case BANDSTOP:          //(original image - bandpassed image)
                ff1 = FILTER_FUNCTION.HPF;
                ff2 = FILTER_FUNCTION.LPF;
    
        }
        
        //design filters
        modphase mp = new modphase();
        int indx = 0;
        //...1st pass
        if (ff1 != null){

            vladfilter.DesignFilter(ft, ff1, rsample, f1, filter_order);
            //real
            for (int i = 0; i < Math.floor((double)n/2.0); i++){
                indx = (i * 2);
                vladfilter.GetFrqResponse(mp,(double)i*rsample/n);
                filter1[indx] = (float)Math.pow(10.0, mp.modulus/10.0); //convert from dB to magnitude
            }
            //imaginary
            for (int i = 1; i <= Math.floor((double)(n-1)/2.0); i++){
                indx = (i * 2) - 1;
                vladfilter.GetFrqResponse(mp,(double)i*rsample/n);
                filter1[indx] = (float)mp.phase;
            }

        } else for(int i = 0; i < n; i++) filter1[i] = 1f;
        
        //...2nd pass
        if (ff2 != null){

            vladfilter.DesignFilter(ft, ff2, rsample, f2, filter_order);
            //real
            for (int i = 0; i < Math.floor((double)n/2.0); i++){
                indx = (i * 2);
                vladfilter.GetFrqResponse(mp,(double)i*rsample/n);
                filter2[indx] = (float)Math.pow(10.0, mp.modulus/10.0); //convert from dB to magnitude
            }
            //imaginary
            for (int i = 1; i <= Math.floor((double)(n-1)/2.0); i++){
                indx = (i * 2) - 1;
                vladfilter.GetFrqResponse(mp,(double)i*rsample/n);
                filter2[indx] = (float)mp.phase;
            }

        } else for(int i = 0; i < n; i++) filter2[i] = 1f;
  
    }
    
    public void SetWindow(){
        window_type = Window_Type.HAMMING;
        SetWindowArray();
    }
    
    public void SetWindow(Window_Type type_arg){
        window_type = type_arg;
        SetWindowArray();
    }

    public void SetWindowArray(){

        if (window == null) window = new float[n];
        
        switch (window_type){
            
            case HAMMING:
                Algorithms.Hamming hma = new Algorithms.Hamming();
                for(int i = 0; i < n; i++) window[i] = (float)hma.hamming(i, n);
                break;

            case NONE:
                for(int i = 0; i < n; i++) window[i] = 1.0f;
                break;

        }//end of switch

    }

    //ALGORITHMS/GET DATA
    
    //get length
    public int Length(){
        return n;
    }

    //get output data (contents of hold2)
    public float GetOutput(int idx){
        if ((idx >= 0) && (idx < n)) return hold2[idx];
        return 1;
    }

    //do nothing
    public void DoNothing(){
        for(int i = 0; i < n; i++) hold2[i] = data[i];
    }

    //frequency spectra of data
    public void DoSpectra(){

        /**
     * Computes 1D forward DFT of real data leaving the result in <code>a</code>
     * . The physical layout of the output data is as follows:<br>
     *
     * if n is even then
     *
     * <pre>
     * a[2*k] = Re[k], 0&lt;=k&lt;n/2
     * a[2*k+1] = Im[k], 0&lt;k&lt;n/2
     * a[1] = Re[n/2]
     * </pre>
     *
     * if n is odd then
     *
     * <pre>
     * a[2*k] = Re[k], 0&lt;=k&lt;(n+1)/2
     * a[2*k+1] = Im[k], 0&lt;k&lt;(n-1)/2
     * a[1] = Im[(n-1)/2]
     * </pre>
     *
     * This method computes only half of the elements of the real transform. The
     * other half satisfies the symmetry condition. If you want the full real
     * forward transform, use <code>realForwardFull</code>. To get back the
     * original data, use <code>realInverse</code> on the output of this method.
     *
     * @param a
     *            data to transform
     */

        //multiple by window
        for (int i = 0; i < n; i++)
            hold[i] = data[i] * window[i];

        //transform
        fft.realForward(hold);

        //shuffle to give real components symmetrical about f(0)
        int p, q;
        for(int i = 0; i < n; i = i + 2){

            p = (n/2) + (i/2);
            q = (n/2) - (i/2);
            if (p < n) hold2[p] = hold[i];
            if (q > -1) hold2[q] = hold[i];

        }

    }

    //window
    public void DoWindow(){
        for(int i = 0; i < n; i++) hold2[i] = window[i];
    }
    
    //filter kernal
    public void DoKernal(){
        
        //shuffle to give real components symmetrical about f(0)
        int p, q, indx;
        for (int i = 0; i < Math.floor((double)n/2.0); i++){
                indx = (i * 2);
                p = (n/2) + i;
                q = (n/2) - i;
                if (p < n) hold2[p] = filter1[indx] * filter2[indx];
                if (q > -1) hold2[q] = filter1[indx] * filter2[indx];
        }
        
        if (pass_type == Pass_Type.BANDSTOP)
            for(int i = 0; i < n; i++) hold2[i] = 1 - hold2[i];

    }

    //filter
    public void DoFilter(){

        //get data
        for (int i = 0; i < n; i++)
            hold[i] = data[i];

        //transform
        fft.realForward(hold);


        //multiply real values by filter arrays
        int indx;
        //data(r) * filter(r)
        for (int i = 0; i < Math.floor((double)n/2.0); i++){
            indx = (i * 2);
            hold[indx] = hold[indx] * filter1[indx] * filter2[indx];
        }

        //data(i) * filter(r)
        int findx  = 0;
        for (int i = 1; i <= Math.floor((double)(n-1)/2.0); i++){
            indx = (i * 2) - 1;
            findx = (i * 2);
            hold[indx] = hold[indx] * filter1[findx] * filter2[findx];
        }
        
        //reverse transform
        fft.realInverse(hold, true);
        
        //put data into hold2
        if (pass_type == Pass_Type.BANDSTOP)
           for (int i = 0; i < n; i++) hold2[i] = data[i] - hold[i];
        else
           for (int i = 0; i < n; i++) hold2[i] = hold[i]; 
        
       
    }

}
