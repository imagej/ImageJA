These imagej plugins implement the VAMP2D and VAMP3D algorithms for analysis of 

Installation Instructions:
Unzip the vamp.zip to a folder vamp in the Imagej plugins directory.


Usage Instructions:
In ImageJ open a image stack.  Run the plugin from the ImageJ Plugin menu.

Questions about usage can be addressed to dani.dumitriu@mssm.edu.