import ij.*;
import ij.plugin.*;
import ij.plugin.Duplicator;
import ij.process.*;
import ij.gui.*;
import ij.text.TextWindow;
import java.awt.*;
import java.lang.Integer;
import java.util.TreeSet;
import java.util.SortedSet;
import java.util.Iterator;
import java.util.Comparator;
import java.util.LinkedList ;
import java.lang.Math;


/* The author of this software is Seth Ian Berger.  Copyright (c) 2010.
Permission to use, copy, modify, and distribute this software for any purpose 
without fee is hereby granted, provided that this entire notice is included in 
all copies of any software which is or includes a copy or modification of this 
software and in all copies of the supporting documentation for such software.
Any for profit use of this software is expressly forbidden without first
obtaining the explicit consent of the author. 
THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED WARRANTY. 
IN PARTICULAR, THE AUTHOR DOES NOT MAKE ANY REPRESENTATION OR WARRANTY 
OF ANY KIND CONCERNING THE MERCHANTABILITY OF THIS SOFTWARE OR ITS FITNESS FOR ANY 
PARTICULAR PURPOSE. 
*/
/* This PlugIn implements VAMP2D
	Seth Ian Berger
	seth.berger@mssm.edu
*/
public class vamp2d_v2 implements PlugIn { 
                private ImageStack stack;
	    int bitDepth = 0;
                int bitMask = 0xffff;
                ImagePlus imp;

           private class pixel implements Comparable {
                    private int x;
                    private int y;
                    private int z;

                    pixel(int xt, int yt, int zt){
                           x = xt;
                           y = yt;
                           z = zt;
                   }


                   public int getIntensity(){
                        if (x >= stack.getWidth() || x < 0 || y<0 || y> stack.getHeight() || z<1 || z>stack.getSize()){
                                 return -1;
                        }
                        return stack.getProcessor(z).getPixel(x,y,null)[0]&bitMask;
                   }

                   public int getX(){
                        return (x);
                   }
                   public int getY(){
                        return (y);
                   }
                   public int getZ(){
                        return (z);
                   }

                   /* sorts pixels top to bottom,left to right, up to down */
                   public int compareTo(Object o){
                           if (o instanceof pixel){
                                pixel p2 = (pixel)o;
                                     if (z < p2.getZ()){
                                          return (1);
                                     } else if (z> p2.getZ()){
                                          return (-1);
                                     } else if (x < p2.getX()){
                                          return (1);
                                     } else if (x > p2.getX()){
                                          return (-1);
                                     } else if (y < p2.getY()){
                                          return (1);
                                     } else if (y > p2.getY()){
                                          return (-1);
                                     } else {
                                        return (0);
                                     }
                          } else {
                             return (-1);
                          }
                   }
                  public String toString(){
                          return ("("+x+","+y+","+z+","+")");
                  }

                  public int hashCode(){
                       return this.toString().hashCode();
                  }
           }


	public void run (String arg) {
		ImagePlus imp1 = IJ.getImage();
		if (imp1.getStackSize()==1)
			{IJ.error("Stack required"); return;}
                         imp= new Duplicator().run(imp1);
                         imp.setTitle( "Vamp2ed_"+ imp1.getTitle() );

            int middleSlice = -1;
            int topSlice = -1;
            int bottomSlice = -1;
            int midStack = -1;
            int threshhold = -1;;
		if (imp.getStackSize()==1){
                  IJ.error("Stack required");
                  return;
            }
		if (imp.getBitDepth()==24){
			IJ.error("RGB stacks not currently supported");
                  return;
            }

            stack = imp.getStack();
            ImageProcessor ip = stack.getProcessor(1);
	if (ip instanceof ByteProcessor){
			bitDepth = 8;
                                    bitMask = 0xff;}
		else if (ip instanceof ShortProcessor){
			bitDepth = 16;
                                    bitMask = 0xffff;}
		else if (ip instanceof FloatProcessor){
			bitDepth = 32;
                                    bitMask = 0xffffffff;}
		else
			throw new IllegalArgumentException("RGB stacks not supported");

            topSlice = 1;
            bottomSlice = stack.getSize();
            middleSlice = (topSlice + bottomSlice) / 2 ;

		GenericDialog d = new GenericDialog("tHoldCounter");
		d.addSlider("Top Slice:", topSlice, bottomSlice, topSlice);
		d.addSlider("Reference Slice:",  topSlice, bottomSlice, middleSlice);
		d.addSlider("Bottom Slice:",  topSlice, bottomSlice, bottomSlice);
		d.addSlider("Threshhold:",  0, ip.getMax() ,  ip.getAutoThreshold() );
		d.showDialog();
		if(d.wasCanceled()) return;
		topSlice =  (int)d.getNextNumber();
		middleSlice = (int)d.getNextNumber();
		bottomSlice = (int)d.getNextNumber();
                        int thresholdchoice   = (int)d.getNextNumber();
		if(d.invalidNumber())
			{IJ.error("Invalid input Number"); return;}
		if(topSlice > middleSlice || middleSlice >  bottomSlice){
			IJ.error("Reference slice must be between top and bottom slices.");
                  return;
            }


		vamp2der( topSlice, bottomSlice, middleSlice, thresholdchoice);

	}

	public void vamp2der(int top, int bottom, int middle, int thresholdchoice) {
                        TreeSet<pixel> pixelList = new TreeSet<pixel>();
		ImageProcessor ip = stack.getProcessor(middle);

		int width = stack.getWidth();
		int height = stack.getHeight();
		int dimension = width*height;
		
                        int niv = 0;
                        int maxniv =dimension*(stack.getSize()+1);
		for(int w=0; w<width; w++) {
                            for(int h=0; h<height; h++) {
                                    niv++;
			IJ.showProgress(niv, maxniv);
                                    pixel pRef = new pixel(w,h,middle);
                                    if (pRef.getIntensity() >= thresholdchoice && !pixelList.contains(pRef) ){
                                          pixelList.add(pRef);
                                          LinkedList<pixel> ip1 =new LinkedList<pixel>();
                                          ip1.add(pRef);
                                          pixel pn;
                                          while ( (pn = ip1.poll()) != null){
                                                    int x = pn.getX();
                                                    int y = pn.getY();
                                                    int z = pn.getZ();
                                                    vampAddPixel(ip1, pixelList, x+1, y, z, thresholdchoice) ;
                                                    vampAddPixel(ip1, pixelList, x-1, y, z, thresholdchoice) ;
                                                    vampAddPixel(ip1, pixelList, x, y+1, z, thresholdchoice) ;
                                                    vampAddPixel(ip1, pixelList, x, y-1, z, thresholdchoice) ; 
                                                    if (z >= middle && z< bottom){
                                                            vampAddPixel(ip1, pixelList, x, y, z+1, thresholdchoice);
                                                    }
                                                    if (z <= middle && z > top){
                                                            vampAddPixel(ip1, pixelList, x, y, z-1, thresholdchoice);
                                                    }
                                          }
                                    }                              
		   }	
		}

                       for(int s = 1; s<=stack.getSize(); s++){
                       	for(int w=0; w<width; w++) {
                            for(int h=0; h<height; h++) {
                                    niv++; 
			IJ.showProgress(niv, maxniv);
                                    pixel p = new pixel(w, h, s);
                                    if ( !pixelList.contains(p) ){
                                        stack.getProcessor(s).putPixel(w,h,0);
                                    }
		   }	
		}
                      } 
                      IJ.showProgress(100,100);
                       imp.updateAndDraw() ;
                       imp.show();   

	}

         
            public void vampAddPixel(LinkedList<pixel> ip1, TreeSet<pixel> pixelList, int x, int y, int z, int thresholdchoice) {
                 if (x < stack.getWidth() && x >= 0 && y>=0 && y <= stack.getHeight() && z>=1 && z<=stack.getSize()){
                      pixel vp = new pixel(x,y,z);
                      if ( !pixelList.contains(vp) && vp.getIntensity() >= thresholdchoice){
                              ip1.add(vp);
                              pixelList.add(vp);
                      }
                 }
            }

}
