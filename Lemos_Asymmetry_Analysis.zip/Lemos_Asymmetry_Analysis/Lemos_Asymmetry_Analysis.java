/**
 * Lemos Asymmetry Analysis v1.0.
 * 
 * Description: this software package is intended to automate and facilitate the measurements of mandibular asymmetry. 
 * Nine anatomic points were demarcated in sequence directly on the digital images using the tools offered by the software program, 
 * from which angular and linear measurements were obtained and. 
 * 
 * @author Eduardo Santiago Moura
 * @author Arnaldo Sena
 * @author Herman Martins Gomes
 */
import ij.IJ;
import ij.ImagePlus;
import ij.gui.GenericDialog;
import ij.gui.ImageCanvas;
import ij.gui.ImageWindow;
import ij.gui.Line;
import ij.gui.PointRoi;
import ij.gui.Roi;
import ij.gui.StackWindow;
import ij.measure.Calibration;
import ij.measure.ResultsTable;
import ij.plugin.PlugIn;
import ij.plugin.filter.Analyzer;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.ImageIO;

/**
 * Lemos Asymmetry Analysis plugin class.
 * @author Eduardo Santiago Moura
 * @author Arnaldo Sena
 * @author Herman Martins Gomes
 */
public class Lemos_Asymmetry_Analysis implements PlugIn {

	/* Global Variables - Start */
	public final int YES = 1;
	public final int NO = 2;
	int mode = NO;
	int currentTooth = -1;
	boolean fileLoaded = false;
	double pixelDepth = 1.0;
	String unit = "pixel";
	CustomCanvas cc;
	/* Global Variables - End */

	/**
	 * Lemos Asymmetry Analysis - Default main method.
	 * 
	 * @author Eduardo Santiago Moura
	 * @author Arnaldo Sena
	 * @author Herman Martins Gomes 
	 */
	public void run(String arg) {

		/* List of marked points */
		List<Point> points = new LinkedList<Point>();
		
		/* Marked points text file */
		String filename = IJ.getImage().getOriginalFileInfo().directory + IJ.getImage().getShortTitle() + ".txt";
		
		/* Verifies the existence of a previous marked points */
		if (existFile(filename)){
			fileLoaded = IJ.showMessageWithCancel(filename, "Load marked points?");
			if(fileLoaded){
				points = loadMarkedPoints(filename);
			}
		} 

		/* Retrieve the input image */
		ImagePlus imp = IJ.getImage();
		
		/* Verifies the presence of the image */
		if (imp == null) {
			IJ.noImage();
			return;
		}
		
		/* Sets current foreground color */
		imp.setColor(Color.RED);

		/* Calibration objects contain an image's spatial and density calibration data:
		 * Local calibration or the system-wide calibration */
		Calibration calibration;
		
		if (fileLoaded){
			calibration = new Calibration(imp);
		    calibration.pixelDepth = pixelDepth;
		   	calibration.pixelWidth = pixelDepth;
		   	calibration.pixelHeight = pixelDepth;
		   	calibration.setUnit(unit);
		   	imp.setGlobalCalibration(calibration);
		} else {
			calibration = imp.getGlobalCalibration();
		}

		/* Verifies calibration consistency */
		if (calibration == null || !calibration.scaled()) {
			IJ.showMessage("Lemos Asymmetry Analysis", "A prior GLOBAL Scale Calibration is needed!");
			return;
		}

		generateModeDialog();

		this.cc = new CustomCanvas(imp);

		if (imp.getStackSize()>1) {
			new StackWindow(imp, cc).addMouseListener(cc);
			new StackWindow(imp, cc).addKeyListener(cc);
		}
		else {
			new ImageWindow(imp, cc).addMouseListener(cc);
			new ImageWindow(imp, cc).addKeyListener(cc);
		}

		/* Verifies the existence of a previous marked points, if TRUE, load marked points */
		if(fileLoaded){
			cc.drawPoints(points);
		}

		/* Retrieves image's region of interest (ROI) */
		Roi roi = imp.getRoi();
		if (roi != null)
			roi.setImage(imp);

		/* Verifies the existence of a previous marked points, if FALSE, reset roi */
		if ( ! fileLoaded) {
			imp.killRoi();
		}

	}
	
	/**
	 * Method that loads a previously marked points file.
	 * 
	 * @author Eduardo Santiago Moura
	 * @author Arnaldo Sena
	 * @author Herman Martins Gomes 
	 */
	private List<Point> loadMarkedPoints(String filename) {
		List<Point> points = new LinkedList<Point>();
		try {
	        BufferedReader in = new BufferedReader(new FileReader(filename));
	        int x;
	        int y;
	        Point p;
			int nPoint = 1;
	        while (nPoint <= 9){
	        	x = Integer.parseInt(in.readLine());
	        	y = Integer.parseInt(in.readLine());
	        	p = new Point(x,y);
	        	points.add(p);
	        	nPoint++;
	        }
	        pixelDepth = Double.parseDouble(in.readLine());
	        unit = in.readLine();
	        in.close();
	        return points;
		} catch (IOException e){
			IJ.showMessage(filename + "not opened");
		}
		return null;
	}
	
	/**
	 * Method that generates the mode dialog.
	 * 
	 * @author Eduardo Santiago Moura
	 * @author Arnaldo Sena
	 * @author Herman Martins Gomes 
	 */
	private void generateModeDialog()
	{
		GenericDialog localGenericDialog = new GenericDialog("Processing Mode - Lemos Asymmetry Analysis");
		localGenericDialog.addChoice("Process with distortion factor?", new String[] { "Yes", "No" }, "Yes");
		localGenericDialog.showDialog();

		if (localGenericDialog.wasCanceled())
			return;
	}

	/**
	 * Method that verifies the existence of a previously marked points file.
	 * 
	 * @author Eduardo Santiago Moura
	 * @author Arnaldo Sena
	 * @author Herman Martins Gomes 
	 */
	private boolean existFile(String fullName){
		
		File archive = new File(fullName);
		return (archive.exists())?true:false;
	}

	/**
	 * Innerclass CustomCanvas.
	 * 
	 * @author Eduardo Santiago Moura
	 * @author Arnaldo Sena
	 * @author Herman Martins Gomes
	 */
	class CustomCanvas extends ImageCanvas implements MouseListener, KeyListener {

		/* Generated serial ID */
		private static final long serialVersionUID = 232104303313449272L;

		/* Global variables - Start */
		List<Point> points;
		List<Double> metrics;
		List<String> labels;
		final int width;
		final int height;
		final int numberPoints;
		double M;
		double C;
		double d26Actual = -1;
		double d26Model = -1;
		double d36Actual = -1;
		double d36Model = -1;
		double d16Actual = -1;
		double d16Model = -1;
		double d46Actual = -1;
		double d46Model = -1;
		/* Global variables - End */

		/**
		 * CustomCanvas constructor.
		 * 
		 * @author Arnaldo Sena
		 * @author Eduardo Santiago Moura
		 * @author Herman Martins Gomes 
		 */
		CustomCanvas(ImagePlus imp) {
			super(imp);
			width = imp.getWidth();
			height = imp.getHeight();
			pixelDepth = imp.getBitDepth();
			points = new LinkedList<Point>();
			metrics = new LinkedList<Double>();
			labels = new LinkedList<String>();
			numberPoints = 9;
			M = 0;
			C = 0;

			/* Add key listener functionality */
			this.addKeyListener(this);
		}

		/**
		 * Overrides mouseReleased functionality.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public void mouseReleased(MouseEvent e) {

			/* Calls super functionality */
			super.mouseReleased(e);

			/* Retrieves region of interest (ROI) */
			Roi roi = imp.getRoi();

			/* Verifies the presence of the ROI */
			if (roi == null || !(roi instanceof PointRoi)) {
				return;
			}

			PointRoi r = (PointRoi)roi;

			/* Verify is new point was added */
			if (r.getNCoordinates() != points.size()) {

				/* Verifies number of points limit */
				if (r.getNCoordinates() > numberPoints) {

					clearResults();

					IJ.showMessage("Lemos Asymmetry Analysis", "Limit of " + numberPoints + " points reached!");

					removeLastPoint();

				} else {

					/* Removed Point */
					if (r.getNCoordinates() < points.size()) {

						updatePoints();

						/* Added Point */
					} else {

						int x = imp.getWindow().getCanvas().offScreenX(e.getX());
						int y = imp.getWindow().getCanvas().offScreenY(e.getY());

						/* Add new point */
						addPoint(x, y);

					}
				}

			/* Moved point or other click */
			} else {

				updatePoints();

			}

			paint(super.getGraphics());

		}

		/**
		 * Method that calculates the metrics and results.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void processPoints() throws IOException {

			/* Calculates metrics */
			computeMetrics();

			/* Calculates results */
			showResults();

		}

		/**
		 * Method that draws the points in the image.
		 * @param npoints
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void drawPoints(List<Point> npoints) {
			this.points = npoints;
			paint(super.getGraphics());
			Point p = new Point();
			int []ox = new int[points.size()];
			int []oy = new int[points.size()];
			for (int i = 0; i < points.size(); i++) {
				p = points.get(i);
				ox[i] = p.x;
				oy[i] = p.y;
			}
			PointRoi point = new PointRoi(ox, oy, points.size());
			point.setImage(imp);
			imp.setRoi(point);
		}

		/**
		 * Method that saves marked points in the text file.
		 * @param npoints
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void savePoints() throws IOException{
			IJ.getImage().copyScale(imp);
			String dir = imp.getOriginalFileInfo().directory;
			String filename = imp.getShortTitle() + ".txt";
			File outputFile = new File(dir + filename);
			Calibration c = imp.getCalibration();
			try{
				Writer writer = new BufferedWriter(new FileWriter(outputFile));  
				try {  
					for (int i = 0; i <= (numberPoints - 1); i++){
						writer.write(points.get(i).x + "\r\n");
						writer.write(points.get(i).y + "\r\n");
					}
					writer.write(c.pixelDepth + "\r\n");
					writer.write(c.getUnits() + "\r\n");
				} finally {  
					writer.close();  
				}  				

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		/**
		 * Method that draws all the measurements in the image.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void drawImage() {

			Graphics g = super.getGraphics();

			/* Line 1 <-> 2 */
			drawLineBetweenPoints(g, points.get(0), points.get(1), true);

			/* Line 2 <-> 3 */
			drawLineBetweenPoints(g, points.get(1), points.get(2), true);

			/* Top point bisectorLine */
			Point top = getBisector(points.get(0), points.get(1), points.get(2), 10);

			/* Bottom point bisectorLine */
			Point bottom = getBisector(points.get(0), points.get(1), points.get(2), height - 10);

			/* Bisector */
			drawLineBetweenPoints(g, top, bottom, true);

			/* Line 4 <-> 5 */
			drawLineBetweenPoints(g, points.get(3), points.get(4), true);

			/* Line 6 <-> 7 */
			drawLineBetweenPoints(g, points.get(5), points.get(6), true);

			/* Line 5 <-> 8 */
			drawLineBetweenPoints(g, points.get(4), points.get(7), true);

			/* Line 7 <-> 8 */
			drawLineBetweenPoints(g, points.get(6), points.get(7), true);

			/* Line 2 <-> 8 */
			int x8 = calculateX(points.get(7).y);
			Point tmp8 = new Point(x8, points.get(7).y);
			drawLineBetweenPoints(g, tmp8, points.get(7), true);

			/* Line 2 <-> 9 */
			int x9 = calculateX(points.get(8).y);
			Point tmp9 = new Point(x9, points.get(8).y);
			drawLineBetweenPoints(g, tmp9, points.get(8), true);

			/* Line 4 <-> 6 */
			Point left = new Point(0, Math.min(points.get(3).y, points.get(5).y));
			Point right = new Point(width, Math.min(points.get(3).y, points.get(5).y));
			drawLineBetweenPoints(g, left, right, true);

			/* Draw labels and measurements */ 
			setInformations(g, true);

		}

		/**
		 * Method that calculates the metrics.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void computeMetrics() {

			metrics.clear();
			labels.clear();

			/* Top point bisectorLine */
			Point top = getBisector(points.get(0), points.get(1), points.get(2), 10D);

			/* Bottom point bisectorLine */
			Point bottom = getBisector(points.get(0), points.get(1), points.get(2), width - 10);

			double adjustRight = round((((round(d16Model,2) / round(d16Actual,2)) + (round(d46Model,2) / round(d46Actual,2)))) / 2, 2);

			double adjustLeft = round((((round(d26Model,2) / round(d26Actual,2)) + (round(d36Model,2) / round(d36Actual,2)))) / 2, 2);

			if (d16Model == -1 || d46Model == -1) {
				/* Model values not informed yet */
				adjustRight = 1;
			}

			if (d26Model == -1 || d36Model == -1) {
				/* Model values not informed yet */
				adjustLeft = 1;
			}

			/* Distance 1 <-> 2 */
			metrics.add(calibratedDistance(points.get(0), points.get(1)) * adjustRight);
			labels.add("RPF-ANS");

			/* Distance 2 <-> 3 */
			metrics.add(calibratedDistance(points.get(1), points.get(2)) * adjustLeft);
			labels.add("ANS-LPF");

			/* Distance 4 <-> 5 */
			metrics.add(calibratedDistance(points.get(3), points.get(4)));
			labels.add("LRH");

			/* Distance 6 <-> 7 */
			metrics.add(calibratedDistance(points.get(5), points.get(6)));
			labels.add("RRH");

			/* Distance 5 <-> 8 */
			metrics.add(calibratedDistance(points.get(4), points.get(7)) * adjustLeft);
			labels.add("LCL");

			/* Distance 7 <-> 8 */
			metrics.add(calibratedDistance(points.get(6), points.get(7)) * adjustRight);
			labels.add("RCL");

			/* Distance 2 <-> 8 */
			double dist28 = ptBisectorDist(top.x, top.y, bottom.x, bottom.y, points.get(7).x, points.get(7).y);
			metrics.add(calibratedValue(dist28));
			labels.add("Pog-MSP");

			/* Distance 2 <-> 9 */
			double dist29 = ptBisectorDist(top.x, top.y, bottom.x, bottom.y, points.get(8).x, points.get(8).y);
			metrics.add(calibratedValue(dist29));
			labels.add("IP-MSP");

			/* Difference 6 <-> 4 */
			metrics.add(calibratedDifference(points.get(5), points.get(3)));
			labels.add("CHD");

			/* Angle 1 <-> 2 <-> 3 */
			metrics.add((double)angleBetweenLines(points.get(0), points.get(1), points.get(2)));
			labels.add("AIM");

			/* Angle 4 <-> 5 <-> 8 */
			metrics.add((double)angleBetweenLines(points.get(3), points.get(4), points.get(7)));
			labels.add("LGA");

			/* Angle 6 <-> 7 <-> 8 */
			metrics.add((double)angleBetweenLines(points.get(5), points.get(6), points.get(7)));
			labels.add("RGA");

			if (d16Model != -1 && d46Model != -1 ) {
				metrics.add(adjustLeft);
				labels.add("LDF");
			}

			if (d26Model != -1 && d36Model != -1) {
				metrics.add(adjustRight);
				labels.add("RDF");
			}

		}

		/**
		 * Method that calculates the distance between a point and the axis of the bisector.
		 * @param x Point 1
		 * @param y Point 1
		 * @param x2 Point 2
		 * @param y2 Point 2
		 * @param x3 Point 3
		 * @param y3 Point 3
		 * @return The distance between a point and the axis of the bisector
		 * 
		 * @author Eduardo Santiago Moura
		 * @author Arnaldo Sena
		 * @author Herman Martins Gomes 
		 */
		private double ptBisectorDist(double x, double y, double x2, double y2, double x3, double y3) {
			Calibration calibration = imp.getGlobalCalibration();
			x = calibration.getX(x);
			y = calibration.getY(y);
			x2 = calibration.getX(x2);
			y2 = calibration.getY(y2);
			x3 = calibration.getX(x3);
			y3 = calibration.getY(y3);
			return Line2D.ptLineDist(x,y,x2,y2,x3,y3);
		}

		/**
		 * Method that calculates the calibrated difference between two points.
		 * @param p1 Point 1
		 * @param p2 Point 2
		 * @return The calibrated difference between two points
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private double calibratedDifference(Point p1, Point p2) {
			Calibration calibration = imp.getGlobalCalibration();
			double distanceUnit = Math.abs(calibration.getY(points.get(5).y) - calibration.getY(points.get(3).y));
			return distanceUnit;
		}

		/**
		 * Method that calculates the calibrated value of a point.
		 * @param value Point value
		 * @return The calibrated value of a point
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private double calibratedValue(double value) {
			Calibration calibration = imp.getGlobalCalibration();
			return calibration.getCValue(value);
		}
		
		/**
		 * Method that calculates the calibrated distance between two points.
		 * @param p1 Point 1
		 * @param p2 Point 2
		 * @return The calibrated distance between two points
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private double calibratedDistance(Point p1, Point p2) {
			Calibration calibration = imp.getGlobalCalibration();

			double distancePixel = 0;
			distancePixel += Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2);
			distancePixel = Math.sqrt(distancePixel);

			double distanceUnit = 0;
			distanceUnit += Math.pow((calibration.getX(p1.x) - calibration.getX(p2.x)), 2) + Math.pow((calibration.getY(p1.y) - calibration.getY(p2.y)), 2);
			distanceUnit = Math.sqrt(distanceUnit); 

			return distanceUnit;

		}

		/**
		 * Method that calculates the angle between two lines.
		 * @param p1 Point 1
		 * @param p2 Point 2
		 * @param p3 Point 3
		 * @return The angle between two lines
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private int angleBetweenLines(Point p1, Point p2, Point p3) {

			/* Slope (m) of lines r e s */
			double mr = slope(p1.x, p1.y, p2.x, p2.y);
			double ms = slope(p2.x, p2.y, p3.x, p3.y);

			/* Perpendicular lines mr*ms = -1 or if there is a line perpendicular (m >= 50000.0) */
			if(((mr*ms) <= -1.0009) && ((mr*ms) >= -0.9991)){return 90;}
			if(mr >= 50000.0){ return (int) (180.0 - Math.toDegrees(Math.atan(Math.abs(1/ms))));} 
			if(ms >= 50000.0){ return (int) (180.0 - Math.toDegrees(Math.atan(Math.abs(1/mr))));}

			/* tg a = |mr-ms / 1 + mr*ms| => a = arctg(|mr-ms / 1 + mr*ms|) */
			double tga = Math.abs((mr-ms)/(1+mr*ms));
			double anguloRadiano = Math.atan(tga);
			return (int) (180.0 - Math.toDegrees(anguloRadiano));
		}

		/**
		 * Method that calculates the slope between two lines.
		 * @param x0 Point 1
		 * @param y0 Point 1
		 * @param x1 Point 2
		 * @param y1 Point 2
		 * @return The slope between two lines
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private double slope(int x0, int y0, int x1, int y1 ){
			double m = 0.0;
			y0 = y0 * (-1);
			y1 = y1 * (-1);

			if ((x1-x0) == 0){ return 50000.0;}
			m = ((double)(y1-y0)/(x1-x0));
			m = m * -1;
			return m;
		}

		/**
		 * Method that draws lines in the image.
		 * @param g Graphics
		 * @param withScale
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void drawLines(Graphics g, boolean withScale) {

			/* Line 1 <-> 2 */
			drawLineBetweenPoints(g, points.get(0), points.get(1), withScale);

			/* Line 2 <-> 3 */
			drawLineBetweenPoints(g, points.get(1), points.get(2), withScale);

			/* Top point bisectorLine */
			Point top = getBisector(points.get(0), points.get(1), points.get(2), 10D);

			/* Bottom point bisectorLine */
			Point bottom = getBisector(points.get(0), points.get(1), points.get(2), width - 10);

			/* Bisector */
			drawLineBetweenPoints(g, top, bottom, withScale);

			/* Line 4 <-> 5 */
			drawLineBetweenPoints(g, points.get(3), points.get(4), withScale);

			/* Line 6 <-> 7 */
			drawLineBetweenPoints(g, points.get(5), points.get(6), withScale);

			/* Line 5 <-> 8 */
			drawLineBetweenPoints(g, points.get(4), points.get(7), withScale);

			/* Line 7 <-> 8 */
			drawLineBetweenPoints(g, points.get(6), points.get(7), withScale);

			/* Line 2 <-> 8 */
			int x8 = calculateX(points.get(7).y);
			Point tmp8 = new Point(x8, points.get(7).y);
			drawLineBetweenPoints(g, tmp8, points.get(7), withScale);

			/* Line 2 <-> 9 */
			int x9 = calculateX(points.get(8).y);
			Point tmp9 = new Point(x9, points.get(8).y);
			drawLineBetweenPoints(g, tmp9, points.get(8), withScale);

			/* Line 4 <-> 6 */
			Point left = new Point(0, Math.min(points.get(3).y, points.get(5).y));
			Point right = new Point(width, Math.min(points.get(3).y, points.get(5).y));
			drawLineBetweenPoints(g, left, right, withScale);

			/* Draw labels and measurements */ 
			setInformations(g, withScale);
		}

		/**
		 * Method that draws labels and angles in the image.
		 * @param g Graphics
		 * @param withScale
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void setInformations(Graphics g, boolean withScale){

			if(points.size() == numberPoints){
				ImageCanvas ic = imp.getCanvas();
				double mag = ic.getMagnification();
				DecimalFormat df = new DecimalFormat("##,###0.0");
				computeMetrics();
				Calibration c = imp.getCalibration();
				String u = c.getUnit();
				Rectangle rect = ic.getSrcRect();
				Point p = new Point();
				p = rect.getLocation();

				if (!withScale) {
					mag = 1;
				}

				int fontSize = (int) (30 * mag);
				if (fontSize > 22) fontSize = 22;
				if (fontSize < 10) fontSize = 10;

				Graphics2D g2d = (Graphics2D) g.create();  
				g2d.setFont(new Font("TimesRoman", Font.PLAIN, fontSize));
				g2d.setColor(Color.YELLOW);
				g2d.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING, java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

				int a = (int)(10.0 * mag); 
				int b = (int)(40.0 * mag);

				g2d.drawString(df.format(metrics.get(0))+u, (int)(((points.get(0).x - p.x + points.get(1).x - p.x)*mag)/2), (int)(((points.get(0).y - p.y + points.get(1).y- p.y)*mag)/2));
				g2d.drawString(df.format(metrics.get(1))+u, (int)(((points.get(1).x - p.x + points.get(2).x - p.x)*mag)/2) - a, (int)(((points.get(1).y - p.y + points.get(2).y- p.y)*mag)/2)-a);
				g2d.drawString(df.format(metrics.get(2))+u, (int)(((points.get(3).x - p.x + points.get(4).x - p.x)*mag)/2), (int)(((points.get(3).y - p.y + points.get(4).y- p.y)*mag)/2));
				g2d.drawString(df.format(metrics.get(3))+u, (int)(((points.get(5).x - p.x + points.get(6).x - p.x)*mag)/2), (int)(((points.get(5).y - p.y + points.get(6).y- p.y)*mag)/2));
				g2d.drawString(df.format(metrics.get(4))+u, (int)(((points.get(4).x - p.x + points.get(7).x - p.x)*mag)/2) + b, (int)(((points.get(4).y - p.y + points.get(7).y- p.y)*mag)/2) + a);
				g2d.drawString(df.format(metrics.get(5))+u, (int)(((points.get(6).x - p.x + points.get(7).x - p.x)*mag)/2), (int)(((points.get(6).y - p.y + points.get(7).y- p.y)*mag)/2));
				g2d.drawString(df.format(metrics.get(6))+u, (int)((points.get(7).x - p.x)*mag) + a, (int)((points.get(7).y - p.y)*mag) + a);
				g2d.drawString(df.format(metrics.get(7))+u, (int)((points.get(8).x - p.x)*mag) + a, (int)((points.get(8).y - p.y)* mag) + a);
				g2d.drawString(df.format(metrics.get(8))+u, (int)((points.get(5).x - p.x)*mag) + a, (int)((points.get(5).y - p.y)*mag) - a);
				g2d.drawString(df.format(metrics.get(10))+"�", (int)((points.get(4).x - p.x)*mag) - b,(int)((points.get(4).y - p.y)* mag) - a);
				g2d.drawString(df.format(metrics.get(11))+"�", (int)((points.get(6).x- p.x)*mag) + a,(int)((points.get(6).y - p.y)* mag)- a);

				g2d.dispose();
			}
		}

		private int calculateX(int y) {
			return (int) ((y - C)/M); 
		}

		/**
		 * Method that draws lines between points in the image.
		 * @param g Graphics
		 * @param p1 Point 1
		 * @param p2 Point 2
		 * @param withScale
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void drawLineBetweenPoints(Graphics g, Point p1, Point p2, boolean withScale) {

			ImageCanvas ic = imp.getCanvas();
			double mag = ic.getMagnification();

			Rectangle rect = ic.getSrcRect();
			Point p = new Point();
			p = rect.getLocation();

			Graphics2D g2d = (Graphics2D) g.create();  
			g2d.setStroke(new BasicStroke((float) (2.5 * mag)));
			g2d.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,
					java.awt.RenderingHints.VALUE_ANTIALIAS_ON);


			if (!withScale) {
				g2d.setColor(Color.YELLOW);
				g2d.drawLine((int)( (p1.x - p.x)), (int)( (p1.y -p.y)), (int)( (p2.x - p.x)), (int)( (p2.y - p.y)));

			} else {
				g2d.setColor(Color.YELLOW);
				g2d.drawLine((int)( (p1.x - p.x) * mag), (int)( (p1.y -p.y) * mag), (int)( (p2.x - p.x) * mag), (int)( (p2.y - p.y) * mag));
			}

			g2d.dispose();

		}

		/**
		 * Method that saves the image in png format.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes  
		 */
		public void saveImagePNG() {
			RenderedImage image = myCreateImage();
			String filename = IJ.getImage().getOriginalFileInfo().directory + IJ.getImage().getShortTitle() + "_lemos.png";
			File file = new File(filename);
			try {
				ImageIO.write(image, "PNG", file);  // ignore returned boolean
			} catch(IOException e) {
				System.out.println("Write error for " + file.getPath() +
						": " + e.getMessage());
			}
		}

		/**
		 * Method that saves the image in jpg format.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public void saveImageJPEG() {
			RenderedImage image = myCreateImage();
			String filename = IJ.getImage().getOriginalFileInfo().directory + IJ.getImage().getShortTitle() + "_lemos.jpeg";
			File file = new File(filename);
			try {
				ImageIO.write(image, "JPEG", file);  // ignore returned boolean
			} catch(IOException e) {
				System.out.println("Write error for " + file.getPath() +
						": " + e.getMessage());
			}
		}

		/**
		 * Method that saves the image in gif format.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public void saveImageGIF() {
			RenderedImage image = myCreateImage();
			String filename = IJ.getImage().getOriginalFileInfo().directory + IJ.getImage().getShortTitle() + "_lemos.gif";
			File file = new File(filename);
			try {
				ImageIO.write(image, "gif", file);  // ignore returned boolean
			} catch(IOException e) {
				System.out.println("Write error for " + file.getPath() +
						": " + e.getMessage());
			}

		}

		/**
		 * Method that creates a representation of the image.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public RenderedImage myCreateImage() {
			Image image = imp.getImage();
			//take the graphics width and height
			int width = image.getWidth(null);
			int height = image.getHeight(null);

			BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d = bufferedImage.createGraphics();

			g2d.drawImage(image, 0, 0, null);

			drawLines(g2d, false);

			g2d.dispose();

			return bufferedImage;
		}

		/**
		 * Method that creates xls output file.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void showResults() {
			ResultsTable rt = Analyzer.getResultsTable();
			rt = new ResultsTable();
			rt.reset();
			Analyzer.setResultsTable(rt);
			
			/* Set table PRECISION */
			rt.setPrecision(1);

			for (int i = 0; i < metrics.size(); i++) {

				rt.incrementCounter();

				if (i > 11) {
					rt.setPrecision(2);
					rt.addValue("Labels", metrics.get(i));
				}
				else {
					rt.setPrecision(1);
					rt.addValue("Labels", format(metrics.get(i)));
				}

				rt.setLabel(labels.get(i), (i));
			}
			rt.show("Results");
		}

		/**
		 * Rounds double value.
		 * @param d
		 * @param decimalPlace
		 * @return Rounded value
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public double round(double d, int decimalPlace) {
			BigDecimal bd = new BigDecimal(Double.toString(d));
			bd = bd.setScale(decimalPlace,BigDecimal.ROUND_HALF_UP);
			return bd.doubleValue();
		}

		/**
		 * Formats double value
		 * @param d
		 * @return
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public double format(double d) {  
			DecimalFormat fmt = new DecimalFormat("0.0");        
			String string = fmt.format(d);  
			String[] part = string.split("[,]");  
			String string2 = part[0]+"."+part[1];
			double valorFin = Double.parseDouble(string2);  
			return valorFin;  
		}  		

		/**
		 * Generates the start processing dialog.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void generateDialog() {
			GenericDialog gd = new GenericDialog("Start Processing - Lemos Asymmetry Analysis");
			gd.addChoice("Start Processing?", new String[] { "Yes", "No"}, "Yes");
			gd.showDialog();
			if (gd.wasCanceled())
				return;

			mode = gd.getNextChoiceIndex() + 1;
		}

		/**
		 * Generates the save points dialog.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void generateSaveDialog() {
			GenericDialog gd = new GenericDialog("Save Points - Lemos Asymmetry Analysis");
			gd.addChoice("Confirm save lines and points?", new String[] { "Yes", "No"}, "Yes");
			gd.showDialog();
			if (gd.wasCanceled())
				return;

			mode = gd.getNextChoiceIndex() + 1;
		}

		/**
		 * Generates the adjustmente dialog.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private GenericDialog generateAdjustmentDialog() {
			GenericDialog gd = new GenericDialog("Adjustment - Lemos Asymmetry Analysis");
			gd.addStringField("Tooth 16 (Model Cast):", "");
			gd.addStringField("Tooth 26 (Model Cast):", "");
			gd.addStringField("Tooth 36 (Model Cast):", "");
			gd.addStringField("Tooth 46 (Model Cast):", "");
			gd.addChoice("Confirm processing with adjustment?", new String[] { "Yes", "No"}, "Yes");
			gd.showDialog();
			if (gd.wasCanceled())
				return gd;

			mode = gd.getNextChoiceIndex() + 1;

			return gd;
		}

		/**
		 * Generates the tooth dialog.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void generateToothDialog() {
			GenericDialog gd = new GenericDialog("Tooth Measure - Lemos Asymmetry Analysis");
			gd.addChoice("Measuring of tooth:", new String[] { "Tooth 16", "Tooth 26", "Tooth 36", "Tooth 46" }, "Tooth 16");
			gd.addChoice("Confirm measure?", new String[] { "Yes", "No"}, "Yes");
			gd.showDialog();
			if (gd.wasCanceled())
				return;

			currentTooth = gd.getNextChoiceIndex() + 1;

			mode = gd.getNextChoiceIndex() + 1;
		}
		
		/**
		 * Generates the file extension dialog.
		 * 
		 * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
	    private void generateImageFile() {
	        GenericDialog gd = new GenericDialog("Save Image As - Lemos Asymmetry Analysis");
	        gd.addChoice("Chosse extense file:", new String[] { "PNG", "GIF", "JPEG" }, "PNG");
	        gd.addChoice("Confirm choice?", new String[] { "Yes", "No" }, "Yes");
	        gd.showDialog();
	        if (gd.wasCanceled()) {
	          return;
	        }
	        
	        currentTooth = gd.getNextChoiceIndex() + 1;

	        mode = gd.getNextChoiceIndex() + 1;
	      }

	    /**
	     * Method that updates the points.
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
	     */
		private void updatePoints() {

			Roi roi = imp.getRoi();
			if (roi == null || !(roi instanceof PointRoi))
				return;

			PointRoi r = (PointRoi)roi;
			Rectangle rect = r.getBounds();
			int n = r.getNCoordinates();
			int[] x = r.getXCoordinates();
			int[] y = r.getYCoordinates();
			int[] novoX = new int[n];
			int[] novoY = new int[n];

			points.clear();

			for (int i = 0; i < n; i++) {
				Point p = new Point(x[i] + rect.x, y[i] + rect.y);
				novoX[i] = p.x;
				novoY[i] = p.y;
				points.add(p);
			}

			clearResults();

		}

		/**
		 * Method that clears the points.
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void clearResults() {
			metrics.clear();
			labels.clear();

			ResultsTable rt = Analyzer.getResultsTable();
			rt.reset();
		}

		/**
		 * Method that removes the last point.
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void removeLastPoint() {

			Roi roi = imp.getRoi();
			if (roi == null || !(roi instanceof PointRoi))
				return;

			int n = points.size();
			int[] novoX = new int[n];
			int[] novoY = new int[n];

			for (int i = 0; i < n; i++) {
				Point p = points.get(i);
				novoX[i] = p.x;
				novoY[i] = p.y;
			}

			PointRoi novoRoi = new PointRoi(novoX, novoY, n);

			imp.setRoi(novoRoi);
		}

		/**
		 * Method that adds a point.
		 * @param x
		 * @param y
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		private void addPoint(int x, int y) {

			Roi roi = imp.getRoi();
			if (roi == null || !(roi instanceof PointRoi))
				return;

			points.add(new Point(x, y));

			IJ.showStatus(" --> Point #" + points.size() + ": (" + x + "," + y + ") added.");

		}

		/**
		 * Method that paints the window component.
		 * @param g Graphics
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public void paint(Graphics g) {
			super.paint(g);
			draw(g);
		}

		/**
		 * Method that draws the window component.
		 * @param g Graphics
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public void draw(Graphics g) {
			drawLines(g, true);
		}

		/**
		 * Method that computes the bisector between two lines.
		 * @param p1
		 * @param p2
		 * @param p3
		 * @param desired_y
		 * @return
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public Point getBisector(Point p1, Point p2, Point p3, double desired_y){
			double a, b, ang, M=0, C=0;
			boolean IsVertical;
			Point p4 = new Point(0,0);

			a = angleLines(p1.x,p1.y, p2.x,p2.y);
			b = angleLines(p3.x,p3.y, p2.x,p2.y);
			ang = (a + b) / 2.0;

			if( (ang>89.999) && (ang <90.001))
				IsVertical=true;
			else{
				M = -Math.tan(Math.toRadians(ang));
				IsVertical=false;
			}

			if(IsVertical){
				p4.x = p2.x;
				p4.y = p2.y + 10;
			}
			else{
				C = p2.y - M * p2.x;
				p4.x= (int) ((desired_y-C)/M);
				p4.y= (int) desired_y;
			}

			this.M = M;
			this.C = C;

			return p4;
		}

		/**
		 * Method that computes the angle between two lines.
		 * @param x1
		 * @param y1
		 * @param x
		 * @param y
		 * @return The angle between two lines
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		public double angleLines(double x1, double y1, double x, double y){

			double temp=0, DY, dx;

			dx = x1 - x;
			DY = y - y1;

			if( (dx > 0) && (DY == 0))
				temp = 0;
			else if ((dx > 0) && (DY > 0))
				temp = Math.atan(Math.abs(DY / dx));
			else if ((dx == 0) && (DY > 0))
				temp = Math.PI / 2;
			else if ((dx < 0) && (DY > 0)) 
				temp = Math.PI - Math.atan(Math.abs(DY / dx));
			else if ((dx < 0) && (DY == 0))
				temp = Math.PI;
			else if ((dx < 0) && (DY < 0))
				temp = Math.PI + Math.atan(Math.abs(DY / dx));
			else if ((dx == 0) && (DY < 0))
				temp = (3.0 / 2) * Math.PI;
			else if ((dx > 0) && (DY < 0))
				temp = 2.0 * Math.PI - Math.atan(Math.abs(DY / dx));

			return Math.toDegrees(temp);
		}

		/**
	     * Key released funcionality.
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		@Override
		public void keyReleased(KeyEvent paramKeyEvent)
	    {
	      int i = 119;
	      int j = 120;
	      int k = 121;
	      int m = 122;
	      int n = 123;

	      if (paramKeyEvent.getKeyCode() == k)
	      {
	        if (this.points.size() == this.numberPoints)
	        {
	          generateDialog();

	          if (1 == Lemos_Asymmetry_Analysis.this.mode)
	          {
	            this.d26Model = -1.0D;
	            this.d36Model = -1.0D;
	            this.d16Model = -1.0D;
	            this.d46Model = -1.0D;

	            Lemos_Asymmetry_Analysis.this.mode = 2;
	            try
	            {
	              clearResults();
	            	
	              processPoints();

	              repaint();

	              drawImage();
	            }
	            catch (IOException localIOException1) {
	              localIOException1.printStackTrace();
	            }
	          }
	        }
	        else {
	          IJ.showMessage("Lemos Asymmetry Analysis", "Insufficient number of points to process!");
	        }

	      }

	      if (paramKeyEvent.getKeyCode() == n)
	      {
	        if (this.points.size() == this.numberPoints) {
	          generateSaveDialog();

	          if (1 == Lemos_Asymmetry_Analysis.this.mode) {
	            Lemos_Asymmetry_Analysis.this.mode = 2;
	            try {
	              savePoints();
	            } catch (IOException localIOException2) {
	              localIOException2.printStackTrace();
	            }
	          }
	        }
	        else {
	          IJ.showMessage("Lemos Asymmetry Analysis", "Insufficient number of points to process!");
	        }

	      }

	      if (paramKeyEvent.getKeyCode() == m)
	      {
	        generateImageFile();

	        if (1 == Lemos_Asymmetry_Analysis.this.mode)
	          switch (Lemos_Asymmetry_Analysis.this.currentTooth) {
	          case 3:
	        	  saveImageJPEG();
	        	  break;
	          case 2:
	        	  saveImageGIF();
	        	  break;
	          default:
	        	  saveImagePNG();
	        	  break;
	          }
	      }
	      Object localObject;
	      if (paramKeyEvent.getKeyCode() == j)
	      {
	        localObject = generateAdjustmentDialog();

	        if (1 == Lemos_Asymmetry_Analysis.this.mode)
	        {
	          this.d26Model = Double.parseDouble(((GenericDialog)localObject).getNextString());
	          this.d36Model = Double.parseDouble(((GenericDialog)localObject).getNextString());
	          this.d16Model = Double.parseDouble(((GenericDialog)localObject).getNextString());
	          this.d46Model = Double.parseDouble(((GenericDialog)localObject).getNextString());

	          if (this.points.size() == this.numberPoints) {
	            try
	            {
	              processPoints();

	              repaint();

	              drawImage();
	            }
	            catch (IOException localIOException3) {
	              localIOException3.printStackTrace();
	            }
	          }
	          else {
	            IJ.showMessage("Lemos Asymmetry Analysis", "Insufficient number of points to process!");
	          }
	        }
	      }

	      if (paramKeyEvent.getKeyCode() == i)
	      {
	        generateToothDialog();

	        if (1 == Lemos_Asymmetry_Analysis.this.mode)
	        {
	          localObject = this.imp.getRoi();

	          if ((localObject == null) || (!(localObject instanceof Line))) {
	            return;
	          }
	          Line localLine = (Line)localObject;

	          switch (Lemos_Asymmetry_Analysis.this.currentTooth) {
	          case 1:
	            this.d26Actual = localLine.getLength();

	            break;
	          case 2:
	            this.d36Actual = localLine.getLength();

	            break;
	          case 3:
	            this.d16Actual = localLine.getLength();

	            break;
	          case 4:
	            this.d46Actual = localLine.getLength();
	          }
	        }
	      }
	    }

		/**
	     * Key pressed funcionality.
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		@Override
		public void keyPressed(KeyEvent e) {
			/* Not used */
		}

		/**
	     * Key typed funcionality.
	     * 
	     * @author Eduardo Santiago Moura
	 	 * @author Arnaldo Sena
	 	 * @author Herman Martins Gomes 
		 */
		@Override
		public void keyTyped(KeyEvent e) {
			/* Not used */
		}
	}
}
