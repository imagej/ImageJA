#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <jni.h>		// Java native interface

#include "SensiCam_8bit.h"	

#define NOERR  0
#define VALCHANGE 103

// GlobalVariables

unsigned char *pic8=NULL;

int err;

static int width,height;
static int ccdwidth,ccdheight;

static int roixmin,roixmax,roiymin,roiymax;
static int hbin,vbin;
static int delay=0;
static int exposure=100;

static int lutmin=0;
static int lutmax=4095;
static int lutlin=0;

static int val1,val2,val3;

char TIMETABLE[4096];
byte LUTTABLE[4096];

int cameratyp;
int trig;

int time1,time2;
int picstat;

//for dynamic linking of DLL
HINSTANCE SensiLib=NULL;
FARPROC setinit;
FARPROC runcoc;
FARPROC stopcoc;
FARPROC setcoc;
FARPROC getstatus;
FARPROC getimagestatus;
FARPROC getimagesize;
FARPROC readimage8;
FARPROC testcoc;

FARPROC loadlut;
FARPROC convert12to8;

int InitSensiMinimal(void);
int GetCCDSize(void);
int SetCaptureCondition(int gain, int submode);
int CaptureFrame(int mode);
void convert_set(byte *MLUT,int vala,int valb,int valc);
int runCOC0(void);

JNIEXPORT jint JNICALL Java_SensiCam_18bit_SetUpCamera (

      JNIEnv *env,			// Java environment
      jobject obj,			// reserved
      jintArray jiaParams)

{
// Init Camera
    
    jint errnum=0;
    int subM=1;

    jsize lenPar = (*env)->GetArrayLength(env, jiaParams);
    jint *aiPar = (*env)->GetIntArrayElements(env, jiaParams, 0);

    if((errnum=InitSensiMinimal())!=0) {
       // failed to initialize camera
      return(errnum);
     }

    if((errnum=GetCCDSize())!=0) {
      // failed to get CCD size
      return(errnum);
    }
    
    int xmin=(int)aiPar[0];
    int ymin=(int)aiPar[1];
    width=(int)aiPar[2];
    height=(int)aiPar[3];

    int xmax=xmin+width;
 
    int ymax=ymin+height;

    roixmin=xmin/32+1;
    roixmax=xmax/32;    
    if (xmax>=ccdwidth) {
	roixmax=ccdwidth/32;
    }

    roiymin=ymin/32+1;
    roiymax=ymax/32;
    if (ymax>=ccdheight) {
	roiymax=ccdheight/32;
    }

    hbin=aiPar[4];
    vbin=aiPar[5];
    delay=aiPar[6];
    exposure=aiPar[7];
    trig=0;

    lutmin=aiPar[8];
    lutmax=aiPar[9];
    lutlin=aiPar[10];

    // Setting parameters
    if((errnum=SetCaptureCondition(0, subM))!=0) {
      return(errnum);
    }

    (*env)->ReleaseIntArrayElements(env, jiaParams, aiPar, 0);
    return(0);
}

JNIEXPORT jint JNICALL Java_SensiCam_18bit_RunCOCAsVIDEO (
      JNIEnv *env,			// Java environment
      jobject obj)			// reserved
{
    if((err=runcoc(0))!=NOERR) {
      // failed in capturing an image
      return(err);
    }
    return(0);
}

JNIEXPORT jint JNICALL Java_SensiCam_18bit_Acquire (

      JNIEnv *env,			// Java environment
      jobject obj,			// reserved
      jbyteArray jsaPixels)	// Array of 16bit pixels to fill

{
  int errnum=0;
  int contag=4;

    jsize lenPix = (*env)->GetArrayLength(env, jsaPixels);
    jbyte *asPix = (*env)->GetByteArrayElements(env, jsaPixels, 0);

    pic8=asPix;

    if((errnum=CaptureFrame(contag))!=0) {
      // failed in capturing an image
      return(errnum);
    }
   (*env)->ReleaseByteArrayElements(env, jsaPixels, asPix, 0);
    return(0);
}

JNIEXPORT jint JNICALL Java_SensiCam_18bit_StopCOC
  (JNIEnv *env, jobject obj)
{
  if((err=stopcoc(0))!=NOERR) {
    // Error in STOP_COC()
    return(err);
  } 
  return(0);
}

int InitSensiMinimal(void)
{
  int x,y;

  OSVERSIONINFO vers;

  // Get actual Operating System
  vers.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&vers);
  if(vers.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS)
  {
    // Load Library SEN95CAM
   if((SensiLib=LoadLibrary("SEN95CAM"))==NULL)
   {
     // Cannot load Library SEN95CAM.DLL
    return(201);
   }
  }
  else if(vers.dwPlatformId==VER_PLATFORM_WIN32_NT)
  {
   if(vers.dwMajorVersion<4)
   {
     // NT Version must be greater 4.00
    return(202);
   }
   // Load Library SENNTCAM
   if((SensiLib= LoadLibrary("SENNTCAM"))==NULL)
   {
     // Cannot load Library SENNTCAM.DLL
    return(203);
   }
  }
  else
  {
    // No Driver for this OS
    return(204);
  }

  // Get Function SETINIT from DLL
  setinit=(FARPROC)GetProcAddress(SensiLib,"SET_INIT");
  if(setinit==NULL)
   {
     // Cannot get function SET_INIT
    return(205);
   }

  // Get all other needed Functions from DLL
  runcoc=(FARPROC)GetProcAddress(SensiLib,"RUN_COC");
  if(runcoc==NULL)
   {
     // Cannot get function RUN_COC
    return(206);
   }

  stopcoc=(FARPROC)GetProcAddress(SensiLib,"STOP_COC");
  if(stopcoc==NULL)
   {
     // Cannot get function STOP_COC
    return(207);
   }

  setcoc=(FARPROC)GetProcAddress(SensiLib,"SET_COC");
  if(setcoc==NULL)
   {
     // Cannot get function SET_COC
    return(208);
   }

  getstatus=(FARPROC)GetProcAddress(SensiLib,"GET_STATUS");
  if(getstatus==NULL)
   {
     // Cannot get function GET_STATUS
    return(210);
   }

  getimagestatus=(FARPROC)GetProcAddress(SensiLib,"GET_IMAGE_STATUS");
  if(getimagestatus==NULL)
   {
     // Cannot get function GET_IMAGE_STATUS
    return(211);
   }

  getimagesize=(FARPROC)GetProcAddress(SensiLib,"GET_IMAGE_SIZE");
  if(getimagesize==NULL)
   {
     // Cannot get function GET_IMAGE_SIZE
    return(212);
   }

  testcoc=(FARPROC)GetProcAddress(SensiLib,"TESTCOC");
  if(testcoc==NULL)
   {
     // Cannot get function TESTCOC
    return(213);
   }

  loadlut=(FARPROC)GetProcAddress(SensiLib,"LOAD_OUTPUT_LUT");
  if(loadlut==NULL)
   {
     // Cannot get function LOAD_OUTPUT_LUT
    return(214);
   }

  readimage8=(FARPROC)GetProcAddress(SensiLib,"READ_IMAGE_8BIT");
  if(readimage8==NULL)
   {
       // Cannot get function READ_IMAGE_8BIT
    return(215);
   }


  // Call Function SETINIT(1)

  if((err=setinit(1))!=NOERR)
   {
    // Error in SETINIT(1)
    return(216);
   }
  return(0);
}

int GetCCDSize(void) {

  // Call Function GET_IMAGE_SIZE(&width,&height)
  // to get size of the CCD
  if((err=getimagesize(&ccdwidth,&ccdheight))!=NOERROR)
   {
     // Error in GET_IMAGE_SIZE()
    return(217);
   }
  return (0);
}

int SetCaptureCondition(int gain, int submode) {
  int x;
  // Call Function GET_STATUS(&val1,&val2,&val3)
  // to get the cameratyp connected
  if((err=getstatus(&val1,&val2,&val3))!=NOERR)
   {
     // Error in GET_IMAGE_STATUS
    return(218);
   }
  // Values returned:
  //    Val1: cam_type = %04x,val1
  //    Val2: temp_electronic = %3d,val2
  //    Val3: temp_ccd  = %3d,val3

  // Get cameratyp LONG or Fast or DICAM from val1
  cameratyp=((val1&0x03000)>>12);

  if(cameratyp==0) {
    // Cameratyp is LONG
    // Set Timevalues in Table:
    sprintf(TIMETABLE, "%d,%d,-1,-1", delay, exposure);
    //    sprintf(TIMETABLE,"0,33,-1,-1");

    x=sizeof(TIMETABLE);
    int mode=cameratyp+(gain*256)+(submode*65536);

    // Call SET_COC(...) to set Camera Parameters
    if((err=setcoc(mode,trig,
                    roixmin,roixmax,
                    roiymin,roiymax,
                    hbin,vbin,
                    TIMETABLE))!=NOERR)
     {
       // Error in SET_COC()
       return(219);
     }

    // Set values for lookuptable 12Bit to 8Bit

    convert_set(LUTTABLE,lutmin,lutmax,lutlin);

    // Load LUT to 'camera' with LOAD_OUTPUT_LUT()
    if((err=loadlut(LUTTABLE))!=NOERR)
      {
	// Error %d in LOAD_OUTPUT_LUT()
	return(220);
      }
    return(0);
  }
  else {
    // Cameratyp other than LONG is not supported in this plugin
    return(221);
  }
}

int runCOC0(void)
{
  // Start grabing pictures
  if((err=runcoc(0))!=NOERR) {
    return(222);
  }
  return(0);
}


int CaptureFrame(int mode) {
  
  if(err==NOERR) {
    time1=GetTickCount();
    do {
      err=getimagestatus(&picstat);
      time2=GetTickCount();
      // timeout in 5 seconds
      if(time2>time1+5010)
	return(223);
    } while(((picstat&0x02)!=0)&&(err==NOERR));
    if(time2>time1+5000) {
      // TIMEOUT in GET_IMAGE_STATUS
      return(224);
    }
  }
  
  if((err=readimage8(0,width,height,pic8))!=NOERR) {
    // Error, reading picture 8bit
    return(225);
  }
  return(0);
}




void convert_set(byte *MLUT,int vala,int valb,int valc)
{
  float step;
  float wert;
  int a,v;
  byte logtab[256];
  
  if(valc==0) {
    if(vala<0)
      vala=0;
    if(vala>4094)
      vala=4094;
    if(valb>4095)
      valb=4095;
    if(valb<1)
      valb=1;
    
    if((vala>valb))
      valb=vala+1;
    
    step=((float)(valb-vala))/256;
    v=0;
    
    for(a=0;a<vala;a++)
      MLUT[a]=(byte)v;
    
    wert=(float)a;
    
    for(;a<valb;a++) {
      if(a>=(int)wert) {
	for(;wert<a;wert+=step)
	  v++;
      }
      if(v>255)
	v=255;
      MLUT[a]=(byte)v;
    }
    
    for(;a<4096;a++)
      MLUT[a]=255;
  }
  
  if(valc==1) {
    if(vala<0)
		vala=0;
    if(vala>4094)
      vala=4094;
    if(valb>4095)
      valb=4095;
    if(valb<1)
      valb=1;
    
    if((vala>valb))
      valb=vala+1;
    
    for(v=0;v<256;v++)
      logtab[v]= (byte)(powl((long double)255,(long double)0.55)*
			powl((long double)v,(long double)0.45));
    
    step=(((float)(valb-vala))/256);
    v=0;
    
    for(a=0;a<vala;a++)
      MLUT[a]=(byte)v;
     
    wert=(float)a;
    
    for(;a<valb;a++) {
      if(a>=(int)wert) {
	for(;wert<a;wert+=step)
	  v++;
      }
      if(v>255)
	v=255;
      MLUT[a]=(byte)logtab[v];
		}
    
    for(;a<4096;a++)
      MLUT[a]=255;
  }
}
