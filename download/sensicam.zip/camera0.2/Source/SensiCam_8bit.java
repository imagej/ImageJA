import ij.plugin.*;
import java.lang.String;
import java.awt.*;
import ij.*;
import ij.gui.*;
import ij.process.*;
import java.awt.event.*;
import java.util.*;
import ij.io.*;
import java.text.*;


/* written by Kunito Yoshida (k.yoshida@imperial.ac.uk) */
/* based on Jeffrey Kuhn's "AcquireIMAQ" plugin and pco SDK sample programme */
/* compatible only with 'Long-Exposure' type camera */

public class SensiCam_8bit implements PlugIn {

    public class capturePanel {
	public Rectangle rect = new Rectangle(0, 0, 1280, 1024);
	public ImageProcessor ip = new ByteProcessor(this.rect.width, this.rect.height);
	public String title = "Camera";
	public ImagePlus imp = new ImagePlus(title, ip);
	public CustomCanvas cc = new CustomCanvas(imp);
	public boolean live = true;
	public COC coc = new COC();

	void setUpPanel (Rectangle Rect, String Title) {
	    this.rect=Rect;
	    this.title=Title;
	    this.ip = this.ip.resize(this.rect.width, this.rect.height);
	    this.imp = new ImagePlus(this.title, this.ip);
	    this.cc = new CustomCanvas(this.imp);
	    cc.coc=this.coc;
	}
    }

    private class COC {
	public boolean bin=false;
	public int delay=0;
	public int exposure=850;
	public int lutmin=0;
	public int lutmax=4095;
	public int lutlin=0;
	public boolean log=false;
    }

    private class sequentialCapture {
	public int number=10;
	public int interval=1000;
    }

    private class fileName {
	public String folder="Default";
	public String prefix="ACQ";
	public int imageNumber=0;
	public String pathName=setPathName(this.folder, this.prefix);
	public boolean autoSave=true;

	public String setPathName(String Folder, String Prefix) {
	    DecimalFormat serialNum=new DecimalFormat("00000");
	    String fn="Acquired\\"+Folder+"\\"+Prefix+serialNum.format(this.imageNumber++)+".TIF";
	    return(fn);
	}
    }

    private class stopWatch {
    	public boolean timeStamp = false;
	public long startTime = System.currentTimeMillis();
	public long elapsedTime;

	public void resetStopWatch() {
	    this.startTime = System.currentTimeMillis();
	}

	public void stampTime(ImageProcessor ip) {
	    DecimalFormat timeDisp=new DecimalFormat("00");
	    this.elapsedTime = System.currentTimeMillis()-this.startTime;
	    Font font = new Font("SansSerif", Font.PLAIN, 14);
	    ip.setFont(font);
	    ip.setColor(255);

	    // convert time to hour:min:sec:msec format
	    int sec=(int)(elapsedTime/1000);
	    int msec=(int)(elapsedTime/10)-100*sec;
	    int min=(int)(sec/60);
	    sec=sec-min*60;
	    int hour=(int)(min/60);
	    min=min-hour*60;
	    String s = (timeDisp.format(hour)+":"+timeDisp.format(min)+":"+timeDisp.format(sec)+"."+timeDisp.format(msec));
	    ip.moveTo(10,17);
	    ip.drawString(s);
	}
    }


    // initialize parameters

    private char switchChar=0;
    private int flags;
    String whichcoc=null;
    boolean windowFlag=true;

    int roix=320;
    int roiy=256; 
    int roiwidth=640; 
    int roiheight=512;

    capturePanel lp=new capturePanel();
    COC ccoc = new COC();
    COC fcoc = new COC();
    fileName fn = new fileName();
    sequentialCapture sq = new sequentialCapture();
    stopWatch sw = new stopWatch();

    static {
        System.loadLibrary("SensiCam_8bitNative");
    }
    
native int SetUpCamera(int[] iParams);
native int RunCOCAsVIDEO();
native int Acquire(byte[] sPixels);
native int StopCOC();

public void run(String arg) {

    IJ.register(SensiCam_8bit.class);

    lp.imp.show();

    new CustomWindow();

    // fit LUT to the current video input
    fcoc.exposure=133;
    autoSetLUT(fcoc);
    autoSetLUT(ccoc);
    lp.coc=ccoc; //The expression "lp.coc" now represents ccoc.
    //    COC current_coc=ccoc; NOW TESTING!!!

    switchChar='g';

    while (switchChar!='Q') {

	if (switchChar=='c') {
	    switchChar=' ';
	    takeAPicture();
	}
	else if (switchChar=='l') {
	    switchChar=' ';
	    autoSetLUT(lp.coc);
	}
	else if (switchChar=='b') {
	    switchChar=' ';
	    inputCOC(lp.coc);
	}
	else if (switchChar=='j') {
	    switchChar=' ';
	    GenericDialog jgd = new GenericDialog("Sequential Capture Condition", IJ.getInstance());
	    jgd.addNumericField("Number of Frames:", sq.number, 0);
	    jgd.addNumericField("Interval(>Exposure+150 for full area):", sq.interval, 0);
	    jgd.addNumericField("Exposure:", ccoc.exposure, 0);
	    jgd.addStringField("Folder path: ImageJ\\Acquired\\", fn.folder);
	    jgd.addStringField("File Prefix:", fn.prefix);
	    jgd.addNumericField("Serial #:", fn.imageNumber, 0);
	    jgd.addCheckbox("Time Stamp:", sw.timeStamp);

	    jgd.showDialog();

	    if (!jgd.wasCanceled()) {
		sq.number=(int)jgd.getNextNumber();
		sq.interval=(int)jgd.getNextNumber();	    
		ccoc.exposure=(int)jgd.getNextNumber();
		fn.folder=jgd.getNextString();
		fn.prefix=jgd.getNextString();
		fn.imageNumber=(int)jgd.getNextNumber();
		sw.timeStamp=jgd.getNextBoolean();
	    }
	}
	else if (switchChar=='t') {
	    switchChar=' ';
	    lp.live=true;
	    timeLapse();
	}
	else if (switchChar=='g') {
	    switchChar=' ';

	    GenericDialog tgd = new GenericDialog("Save Files As", IJ.getInstance());
	    tgd.addStringField("Folder path: ImageJ\\Acquired\\", fn.folder);
	    tgd.addStringField("File Prefix:", fn.prefix);
	    tgd.addNumericField("Serial #:", fn.imageNumber, 0);
	    tgd.addCheckbox("Auto Save (for Single Capture):", fn.autoSave);
	    tgd.addCheckbox("Time Stamp:", sw.timeStamp);
	    tgd.showDialog();

	    if (!tgd.wasCanceled()) {

		fn.folder=tgd.getNextString();
		fn.prefix=tgd.getNextString();
		fn.imageNumber=(int)tgd.getNextNumber();
		fn.autoSave=tgd.getNextBoolean();
		sw.timeStamp=tgd.getNextBoolean();
	    }
	}
	else if (switchChar=='u') {
	    switchChar=' ';
	    if (lp.coc==ccoc) {
		lp.coc=fcoc;
		lp.cc.coc=fcoc;
		whichcoc="Focus Mode";
	    } else if (lp.coc==fcoc) {
		lp.coc=ccoc;
		lp.cc.coc=ccoc;
		whichcoc="Capture Mode";
	    }
	    IJ.showStatus(whichcoc);
	}
	else if (switchChar=='y') {
	    switchChar=' ';
	    placeAROI();
	}
	else if (switchChar=='s') {
	    switchChar=' ';
	    sw.resetStopWatch();
	}
	else if (switchChar=='q') {
	    switchChar=' ';
	    lp.live=true;
	    idling();
	}
	else if (switchChar==' ') {
	    switchChar=0;
	    lp.live=true;
	    ShowCamera(lp.coc);
	}
    }
    if (StopCOC()!=0) {
	IJ.error("Cannot StopCOC.");
	return;
    }
    IJ.showMessage("- Plugin Ended -");
}

    public void idling() {
	while (lp.live==true) {
	    IJ.wait(250); 
	}
    }

    public void placeAROI() {

	GenericDialog gd = new GenericDialog("Create a ROI", IJ.getInstance());
	gd.addNumericField("width: ", roiwidth, 0);
	gd.addNumericField("height: ", roiheight, 0);
	gd.addNumericField("x: ", roix, 0);
	gd.addNumericField("y: ", roiy, 0);

	gd.showDialog();
	
	if (!gd.wasCanceled()) {
	    roiwidth=(int)gd.getNextNumber();
	    roiheight=(int)gd.getNextNumber();
	    roix=(int)gd.getNextNumber();
	    roiy=(int)gd.getNextNumber();
	    lp.imp.setRoi(roix, roiy, roiwidth, roiheight);
	}
    }

    public void inputCOC(COC coc) {
	if (coc==ccoc) {
	    whichcoc="Capture Mode";
	} else if (coc==fcoc){
	    whichcoc="Focus Mode";
	}
	GenericDialog bgd = new GenericDialog("Capture Condition", IJ.getInstance());
	bgd.addMessage("Now you are setting-up: "+whichcoc);
	bgd.addNumericField("Exposure:", coc.exposure, 0);
	bgd.addNumericField("LUT MIN:", coc.lutmin, 0);	    
	bgd.addNumericField("LUT MAX:", coc.lutmax, 0);	    
	bgd.addCheckbox("LUT Log:", coc.log);
	bgd.showDialog();
	
	if (!bgd.wasCanceled()) {
	    coc.exposure=(int)bgd.getNextNumber();
	    coc.lutmin=(int)bgd.getNextNumber();
	    coc.lutmax=(int)bgd.getNextNumber();
	    coc.log=bgd.getNextBoolean();
	}
    }
    
    public void timeLapse() {

	    Roi roi=lp.imp.getRoi();
	    capturePanel tp = new capturePanel();
	    tp.rect=roiInterpret(roi);
	    tp.setUpPanel (tp.rect, "Time-Lapse: "+fn.prefix);
	    tp.imp.show();
	    new TimeLapseWindow(tp);
	    windowFlag=true;

	    if (SetCaptureCondition(tp, ccoc)==false) {
		IJ.error("Setup error TL Window");
		return;
	    }

	    try {
		if (RunCOCAsVIDEO()!=0) {
		    IJ.error("Cannot RunCOCAsVIDEO.");
		    return;
		}
		
		tp.live=true;
		boolean err=true;

		while ((tp.live==true)&&(err==true)) {
		    err=CaptureFrame(tp, sw.timeStamp);
		}
		if (windowFlag==true){
		    tp.live=true;		
		    
		    long time = System.currentTimeMillis();
		    long nextTime = time + (long) sq.interval;
		    
		    for (int j=1; j<=sq.number; j++){
		    
			if (CaptureFrame(tp, sw.timeStamp)==false) {
			    return;
			}
			
			try {
			    autoSaveImage(tp.imp, fn);
			} catch (Exception e) {
			    switchChar='g';
			    IJ.showMessage("Cannot Save the Image on Disk");
			}
			
			IJ.showStatus(j+"/"+sq.number+" Captured");
			
			time = System.currentTimeMillis();
			if (tp.live==false) {
			    IJ.showMessage("Time-lapse function terminated by user.");
			    break;
			}
			else if (time<nextTime) {
			    IJ.wait(( int )(nextTime-time)); 
			}
			else {
			    IJ.error("Interval is too short to follow!"+(time-nextTime));
			    break;
			}
			
			nextTime += (long) sq.interval;
		    }
		    IJ.showMessage("TimeLapse Complete");
		}
	    } catch (Exception e) {
		IJ.showMessage("Unknown Error! ??");
	    } finally { 
		tp.imp.hide();
		if (StopCOC()!=0) {
		    IJ.error("Cannot StopCOC.");
		    return;
		}
	    }
    }

    public void takeAPicture() {
	    capturePanel ap = new capturePanel();
	    try {
		Roi roi=lp.imp.getRoi();
		ap.rect=roiInterpret(roi);
		ap.setUpPanel (ap.rect, "Acquired");
		SetCaptureCondition(ap, ccoc);
		if (RunCOCAsVIDEO()!=0) {
		    IJ.error("Cannot RunCOCAsVIDEO.");
		    return;
		}
		if (CaptureFrame(ap, sw.timeStamp)==false) {
		    IJ.error("Cannot Capture Frame.");
		    return;
		}
		ap.imp.show();
		
		if (fn.autoSave==true) {
		    if (autoSaveImage(ap.imp, fn)==false) {
			switchChar='g';
		    }
		    else {
			ap.imp.setTitle(fn.pathName);
		    }
		}
	    } catch (Exception e) {
		IJ.showMessage("Unexpected Error! ??");
	    } finally {
 		if (StopCOC()!=0) {
		    IJ.error("Cannot StopCOC.");
		    return;
		}
	    }
    }

    public boolean autoSetLUT(COC coc) {
	coc.lutmin=0;
	coc.lutmax=4095;
	capturePanel samp = new capturePanel();
	try {
	    Roi roi=lp.imp.getRoi();
	    samp.rect=roiInterpret(roi);
	    samp.setUpPanel(samp.rect, "autoLUT");
	    if (SetCaptureCondition(samp, coc)==false) {
		IJ.error("Setup error autoSetLUT1");
		return(false);
	    }
	    if (RunCOCAsVIDEO()!=0) {
		IJ.error("Cannot RunCOCAsVIDEO.");
		return(false);
	    }
	    if (CaptureFrame(samp, false)==false) {
		IJ.error("Cannot Capture Frame.");
		return(false);
	    }
	} catch (Exception e) {
	    IJ.showMessage("Unexpected Error! ??");
	} finally {
	    if (StopCOC()!=0) {
		IJ.error("Cannot StopCOC.");
		return(true);
	    }
	}
	ByteStatistics iSta=new ByteStatistics(samp.ip);
	coc.lutmin=(int)iSta.min*16;
	coc.lutmax=((int)iSta.max-1)*16;
	if (SetCaptureCondition(lp, coc)==false) {
	    IJ.error("Setup error autoSetLUT2");
	    return(false);
	}
	return(true);
    }

    public Rectangle roiInterpret(Roi roi) {
	Rectangle rect;
	Rectangle newRect=new Rectangle();
	try {
	    rect=roi.getBoundingRect();
	    if ((rect.width<=0)||(rect.height<=0)) {
		rect=lp.rect;
	    }
	} catch (Exception e) {
	    rect=lp.rect;
	}
	newRect.x=((int)(rect.x/32))*32;
	newRect.y=((int)(rect.y/32))*32;
	newRect.width=((int)(rect.width/32))*32;
	newRect.height=((int)(rect.height/32))*32;
	lp.imp.setRoi(newRect);
	return(newRect);
    }
    
    public boolean ShowCamera(COC coc) {
	boolean err=true;
	if (SetCaptureCondition(lp, coc)==false) {
	    IJ.error("Setup error showCamera");
	    return(false);
	}
	int errnum=0;
	if ((errnum=RunCOCAsVIDEO())!=0) {
	    IJ.error("Cannot RunCOCAsVIDEO-A. "+errnum);
	    return(false);
	}
	while ((lp.live==true)&&(err==true)) {
	    err=CaptureFrame(lp, sw.timeStamp);
	}
	if (StopCOC()!=0) {
	    IJ.error("Cannot StopCOC.");
	    return(false);
	}
	return(true);
    }
    
    public boolean SetCaptureCondition(capturePanel cp, COC coc) {

	int errnum=0;
	int[] aiParams = new int[16];
	
	int binw;
	if (coc.bin) {binw=2;}
	else {binw=1;}
	
	aiParams[0] = cp.rect.x;
	aiParams[1] = cp.rect.y;
	aiParams[2] = cp.rect.width;
	aiParams[3] = cp.rect.height;
	aiParams[4] = binw;
	aiParams[5] = binw;
	aiParams[6] = coc.delay;
	aiParams[7] = coc.exposure;
	aiParams[8] = coc.lutmin;
	aiParams[9] = coc.lutmax;

	if (coc.log==true) {
	    aiParams[10] = 1;
	} 
	else {
	    aiParams[10] = 0;
	}

	if ((errnum=SetUpCamera(aiParams))!=0) {
	    IJ.error("Cannot Set up Camera. err="+errnum);
	    return(false);
	}
	return(true);
    }


    public boolean CaptureFrame(capturePanel cp, boolean timeStamp) {

	byte[] asPixels = (byte[]) cp.ip.getPixels();
	int errnum;
	if ((errnum=Acquire(asPixels))!=0) {
	    IJ.error("Cannot Capture frame. err="+errnum);
	    return(false);
	}
	
	try {
	    double min = cp.ip.getMin();
	    double max = cp.ip.getMax();
	    cp.ip.setMinAndMax(min, max);
	    if (timeStamp==true) {
		sw.stampTime(cp.ip);
	    }
	    cp.imp.updateAndDraw();
	    return(true);
	} catch (Exception e){
	    lp.live=false;
	    switchChar='q';
	    return(false);
	}
    }
  
    private boolean autoSaveImage(ImagePlus imp, fileName fn) {
	try {
	    fn.pathName=fn.setPathName(fn.folder, fn.prefix);
	    FileSaver fs=new FileSaver(imp);
	    fs.saveAsTiff(fn.pathName);
	    IJ.showStatus("Saved as "+fn.pathName);
	    return(true);
	} catch (Exception e) {
	    IJ.showMessage("Cannot save files");
	    return(false);
	} 
    }

    class CustomCanvas extends ImageCanvas {
	
	COC coc=new COC();
    
        CustomCanvas(ImagePlus imp) {
            super(imp);
        }

        public void paint(Graphics g) {
            super.paint(g);
            int size = 40;
            int screenSize = (int)(size*getMagnification());
            int x = screenX(imageWidth/2 - size/2);
            int y = screenY(imageHeight/2 - size/2);
            g.setColor(Color.red);
	    if (this.coc==fcoc) {
		g.drawOval(x, y, screenSize, screenSize);
	    }
        }

        public void mousePressed(MouseEvent e) {
            super.mousePressed(e);
        }

    } // CustomCanvas inner class
    
    class CustomWindow extends ImageWindow implements ActionListener, WindowListener {
    
        private Button buttonY, buttonU, buttonC, buttonL, buttonB, buttonG, buttonJ, buttonS, buttonT, buttonQ;
        CustomWindow() {
            super(lp.imp, lp.cc);
            setLayout(new FlowLayout());
            addPanel();
        }
    
        void addPanel() {
            Panel panel = new Panel();
            panel.setLayout(new GridLayout(9, 1, 0, 30));

            buttonQ = new Button(" Pause Plugin ");
            buttonQ.addActionListener(this);
            panel.add(buttonQ);
            buttonU = new Button(" Focus<=>Capture ");
            buttonU.addActionListener(this);
            panel.add(buttonU);
            buttonB = new Button(" Gain Control ");
            buttonB.addActionListener(this);
            panel.add(buttonB);
            buttonL = new Button(" Auto Gain ");
            buttonL.addActionListener(this);
            panel.add(buttonL);
            buttonG = new Button(" Save Option ");
            buttonG.addActionListener(this);
            panel.add(buttonG);
            buttonS = new Button(" Restart Stop Watch ");
            buttonS.addActionListener(this);
            panel.add(buttonS);
            buttonJ = new Button(" Time-Lapse Condition ");
            buttonJ.addActionListener(this);
            panel.add(buttonJ);
            buttonT = new Button(" Time-Lapse Mode ");
            buttonT.addActionListener(this);
            panel.add(buttonT);
            buttonY = new Button(" Place A ROI ");
            buttonY.addActionListener(this);
            panel.add(buttonY);
            buttonC = new Button(" Take A Picture ");
            buttonC.addActionListener(this);
            panel.add(buttonC);
            add(panel);
            pack();
        }

	public void windowClosed(WindowEvent e) {
	    lp.live=false;
	    switchChar='Q';
	}
      
        public void actionPerformed(ActionEvent e) {
	    lp.live=false;
            Object b = e.getSource();
            if (b==buttonU) {
		switchChar='u';
            } else if (b==buttonY) {
		switchChar='y';
            } else if (b==buttonC) {
		switchChar='c';
            } else if (b==buttonB) {
		switchChar='b';
            } else if (b==buttonT) {
		switchChar='t';
            } else if (b==buttonJ) {
		switchChar='j';
            } else if (b==buttonG) {
		switchChar='g';
            } else if (b==buttonL) {
		switchChar='l';
            } else if (b==buttonS) {
		switchChar='s';
            } else if (b==buttonQ) {
		switchChar='q';
	    }
        }
        
    } // CustomWindow inner class


    class TimeLapseWindow extends ImageWindow implements ActionListener, WindowListener {
    
        private Button buttonU;
	capturePanel cp;
	
        TimeLapseWindow(capturePanel cp) {
            super(cp.imp, cp.cc);
	    this.cp=cp;
            setLayout(new FlowLayout());
            addPanel();
        }
    
        void addPanel() {
            Panel panel = new Panel();
            panel.setLayout(new GridLayout(1, 1, 0, 30));
            buttonU = new Button(" Start/Break ");
            buttonU.addActionListener(this);
            panel.add(buttonU);
            add(panel);
            pack();
        }

	public void windowClosing(WindowEvent e) {
	    	    cp.live=false;
		    windowFlag=false;
	}
      
        public void actionPerformed(ActionEvent e) {

            Object b = e.getSource();
            if (b==buttonU) {
		cp.live=false;
            } 
        }
        
    } // TimeLapseWindow inner class


} //SensiCam_8bit.java


