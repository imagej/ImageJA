To install:

1) You need to install pco SDK (http://www.pco.de) on your computer.

2) Add all the files in the "Classes" folder into "plugins" folder of ImageJ.

3) Put "SensiCam_8bitNative.dll" into "ImageJ\jre\bin".

4) Make a folder named as "Acquired" in "ImageJ" folder.

5) Make a folder named as "Default" in the "Acquired" folder that you
made in 4).


 - This plugin is only compatible with SensiCam Long Exposure camera,
but you could adapt it to cameras of other types in relatively simple
manner.

I compiled the plugin using gcc in cygwin environment
(http://www.cygwin.com, needs 'developper' package) by running the
following bash commands. "ImageJ" folder was placed within the root
directory of cygwin in this example. You may also need to install Java
Software Development Kits from Sun
(http://java.sun.com/j2se/1.4/download.html) to obtain javah.exe.

jdk=/cygdrive/c/j2sdk1.4.1_04
$jdk/bin/javac -classpath /cygwin/ImageJ/ij.jar SensiCam_8bit.java
$jdk/bin/javah -verbose -classpath ./ -jni -o SensiCam_8bit.h SensiCam_8bit
gcc -g -mno-cygwin -I. -I$jdk/include -I$jdk/include/win32 -Wl,--add-stdcall-alias -shared -o SensiCam_8bitNative.dll SensiCam_8bitNative.c
cp SensiCam_8bitNative.dll /ImageJ/jre/bin/


_________________________________________________

How to use:

*Data concept - SensiCam is 12-bit camera but this plugin convert the
12-bit data into 8bit data. To do this, plugin should map the 12-bit
scale to 8-bit scale. If you press 'Auto Gain' button on the main
panel, the plugin first aquire an image according to the exposure time
(in milliseconds) that you set in the 'Gain Control' or 'Time-Lapse
Condition' panel, then analyse the pixel value, and try to set the
minimal pixel value in 12-bit scale to 0 in 8-bit scale (LUT MIN) and
the maximal pixel value in 12-bit scale to 255 in 8-bit scale (LUT
MAX), respectively. You can set these LUT MIN and MAX values manually
in the 'Gain Control' or 'Time-Lapse Condition' panel.

*Aquire an image - You specify the ROI (or if not the whole area will
be selected) and press 'Take A Picture' button in the main panel. If
you checked 'Auto Save' checkbox in the 'Save Option' panel, the
captured the image will be automatically saved in the folder (a
subfolder of 'ImageJ\Acquired', 'Default' as default) which you
specified in the 'Save Option' panel.

*Time-lapse mode - If you press the 'Time-Lapse Mode' button, another
 panel will be activated according to the ROI that you
 specified. Press 'Start/Break' button to start recording. Capturing
 interval should be specified in the 'Time-Lapse Condition' panel, and
 should not exceed the time required to capture an image which is
 determined by the sum of the 'Exposure' time you specified and the
 intrinsic time for the hardware (~150 msec but may depend on your
 machine). Captured images will be sequentially numbered and stored in
 the specified folder as separate image files. If you want to stop
 capturing during the course, press the 'Start/Break' button again or
 simply close the 'Time-Lapse' window panel.

*Focus mode - If you are working with long exposure time, you will
 often experience that it is hard to focus your specimen. The 'Focus
 Mode' is a facility to achieve this more easily. By pressing the
 'Focus<=>Capture' button, you can switch between 'Focus Mode' and
 'Capture Mode'. In 'Focus Mode', a red circle will appear in the main
 monitor so that you will know that you are in 'Focus Mode'. You can
 set the capturing condition for each mode in the 'Gain Control' panel
 or by pressing 'Auto Gain' button while you are in the corresponding
 mode. 'Focus Mode' is just to monitor the camera, and you will always
 capture images according to the condition set for 'Capture Mode' even
 when you are in 'Focus Mode'.

*Pause - By pressing 'Pause Plugin' button, your machine will be freed
 from constinuous image aquisition cycle, so that you could work more
 comfortably in other jobs. To reactivate the acquisition cycle, you
 may need to press any of other buttons.

*Place A ROI - It is nothing but a facility to set a ROI reproducibly.


_____________________________________________________

If you have further questions, please write to
k.yoshida@imperial.ac.uk.

And please feel free to update the plugin.

13/Aug/2003
Kunito
