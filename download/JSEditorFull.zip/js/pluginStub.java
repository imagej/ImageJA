import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import java.io.*;
import ij.plugin.filter.*;
import org.mozilla.javascript.*;

public class XpluginNameX implements PlugInFilter {
	ImagePlus imp;
                  ImageProcessor  ip;

	public int setup(String arg, ImagePlus imp) {
		this.imp = imp;
		return DOES_ALL;
	}

	public void run(ImageProcessor ip) {
                            this.ip = ip;
	         evaluate(readAll(Menus.getPlugInsPath(), "XscriptfileX" ));
	}

	// evaluate (run) a script:
    	public void evaluate(String str)   {
	    try  {

		Context cx = Context.enter();
          		Scriptable scope = cx.initStandardObjects(null);
		performReflections(scope); 
       		 try {
         			Object result = cx.evaluateString(scope, str, "<cmd>", 1, null);
			IJ.write(cx.toString(result) );
 	
  		      }  catch( JavaScriptException jse) {IJ.write("JavaScript exception: " + jse.getMessage()) ; } 
		Context.exit();

	          } catch(Exception e) {IJ.write(e.getMessage()) ; } 
      	}

   String readAll(String dir, String fname ) {
         File  file = new File(dir, fname);
         String bigString = new String();
         try {
            StringBuffer sb = new StringBuffer(5000);
            BufferedReader r = new BufferedReader(new FileReader(file));
            
            while (true)
            {
                String s=r.readLine();
                if (s==null)
                    break;
                else bigString+=s + "\n";
            }
            r.close();
      
     }catch
            (IOException e) { IJ.showMessage("Could not read file. " + e.getMessage());return ""; }
     return bigString;
}

  void performReflections(Scriptable scope) {
	ImagePlus imp = WindowManager.getCurrentImage();
                   ImageProcessor ip = imp.getProcessor();

	Scriptable jsArgs = Context.toObject(ip, scope);
                   scope.put("ImageProcessor", scope, jsArgs);

                    jsArgs = Context.toObject(imp, scope);
                   scope.put("ImagePlus",scope,jsArgs);

	jsArgs = Context.toObject(new IJ(), scope);
                   scope.put("IJ", scope, jsArgs);
  }
} // end class
