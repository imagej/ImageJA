// Demo of how to invert an image with JavaScript, and how
// to do a bit of profiling, too...

function invertThisImage() {	
	for (p = ImageProcessor.getPixels(),
             i = p.length-1;i;i-- )	
	          p[i] = ~p[i];  // use complement operator  	     
}



// Try it and profile it:

start = new Date *1; // start timing 
invertThisImage();  // INVERT
end = new Date *1;  // end timing 
seconds = (end - start)/1000;
pixels = ImageProcessor.getPixels().length;

// write the result to the Results window:
IJ.write( String(pixels/seconds).split('.')[0]+" pixels/sec");

ImagePlus.updateAndDraw(); // refresh screen



