// A demonstration of how to rotate an image 180 degrees
// using JavaScript.

// OPEN AN RGB IMAGE BEFORE EXECUTING THIS SCRIPT

if (typeof ImageProcessor=='undefined')
   IJ.showMessage("Please open an RGB first!");

else {
    // Use the JavaScript Array method reverse()
    // to reverse the raster order of the pixels array:
    ImageProcessor.getPixels().reverse();
    ImagePlus.updateAndDraw();
}

