// This 3-liner shows how to use ImageJ's native
// copyBits() and invert() methods to achieve an
// "embossing" effect (equivalent to a Sobel convolution)

ImageProcessor.copyBits(ImageProcessor,-2,-2,4); // DIFFERENCE
ImageProcessor.invert();
ImagePlus.updateAndDraw();
