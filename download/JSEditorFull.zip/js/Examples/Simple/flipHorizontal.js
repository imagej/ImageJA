// Demonstration of using JavaScript to flip an image horizontally.
// Open an image first, before clicking Evaluate.

function flipHorizontal( imp, ip ) 
{
	var h = ip.getHeight();
	var w = ip.getWidth();

	// We need a Java int[] array:
	var row = new java.lang.reflect.Array.newInstance(
 			java.lang.Integer.TYPE, w);

	for (var i = 0; i < h; i++)
	{
		ip.getRow(0,i,row,w);
		row = row.reverse();
		ip.putRow(0,i,row,w);
		imp.updateAndDraw();
	}
}

// Exercise the routine:
flipHorizontal(ImagePlus,ImageProcessor);

