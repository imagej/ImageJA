// A demonstration of how to quantize a greyscale
// image to 8 levels of grey. Open an 8-bit greyscale
// image before executing this code.

pixels = ImageProcessor.getPixels(); // grab pixel array
for (var i = 0; i < pixels.length; i++)
{
   p = pixels[i];
   p &= 0xe0;
   pixels[i] = (new java.lang.Integer(p)).byteValue();
}
ImagePlus.updateAndDraw();