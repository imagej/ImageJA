// This snippet shows how to use ImageJ's native duplicate(),
// copyBits(), and smooth() methods to achieve a mild 
// "sharpen" effect

dup =ImageProcessor.duplicate();
dup.smooth();dup.smooth();dup.smooth();
dup.copyBits(ImageProcessor,-1,-1,8); // DIFFERENCE
ImageProcessor.copyBits(dup,0,0,10); // OR

ImagePlus.updateAndDraw();
