// Draws concentric rings running out from
// the center of the image window.

function waves( p ) {
   
   x = p.x - p.w/2; 
   y = p.y - p.h/2;
   d = Math.sqrt(x*x + y*y)/6;

   d = (1.+Math.sin(d))* 128;

   return (d<<16) + (d<<8) + d;
}

img = new RGBImage(250,250); // see "includes.js"
img.pixelIterate(waves);
