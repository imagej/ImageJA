img = new RGBImage(256,256);
k = 0;

img.pixelIterate( function(p) {
  k = p.y;
  k = (k << 16) + (k << 8) + k;

  return (p.x < img.width/2) ? 
       k & 0xe0e0e0 : k;
 }
);
