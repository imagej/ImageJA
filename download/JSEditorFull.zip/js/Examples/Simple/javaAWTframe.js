// This demo shows how to construct a java.awt.Frame from
// JavaScript. 

Frame = java.awt.Frame;
Button = java.awt.Button;
Label = java.awt.Label;
Dimension = java.awt.Dimension;
Panel = java.awt.Panel;

frame = new Frame("My New Frame");
frame.setSize(new Dimension(240,100));
label = new Label("This is a message.",1);
button = new Button("OK");
panel = new Panel();

frame.add(label);
frame.add(button,java.awt.BorderLayout.SOUTH);

ok = function dismiss(e){ e.getSource().getParent().dispose(); }
act = { actionPerformed: ok }
listener = new java.awt.event.ActionListener( act );
button.addActionListener(listener);
frame.show();