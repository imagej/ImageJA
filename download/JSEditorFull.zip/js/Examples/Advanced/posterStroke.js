// Demo of an interesting special effect.
// Open an RGB image before hitting Evaluate.

// =============== posterStroke() =====================
function posterStroke(ip,imp,mask){

ip.snapshot();             // we want to restore the original later
img = new RGBImage(ip);    // make a copy in a new window

pixels = ip.getPixels();   // grab pixel array
length = pixels.length;    // cache this for loop speed
ip.smooth();
ip.smooth();


for (var i = 0; i < length; i++)
{
    pixels[i] &= mask; // quantize 
    if (i%6000==0)         // show a progress bar
	IJ.showProgress(i/length);
}

ip.findEdges();            // get contours
ip.smooth();               // smooth them a bit
ip.smooth();               // smooth them a bit

img.imageProcessor.copyBits(ip,0,0,11); // 11 == XOR mode
ip.reset();  // restore original img.imageProcessor.copyBits(ip,0,0,7); // 11 == XOR mode
img.imagePlus.updateAndDraw();

ip.reset();  // restore original 
}

// ====================================================
// Exercise it
posterStroke(ImageProcessor,ImagePlus,0xf0f0ff);

