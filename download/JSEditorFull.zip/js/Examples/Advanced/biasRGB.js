// A demonstration of applying bias values to
// individual channels of an RGB image.
// Open an RGB image, then click Evaluate.


// ============== bias() ===============
// This is the Musgrave bias function.
// (See "Texturing and Modeling", by 
// Ebert, Musgrave, et al., Academic
// Press; an essential reference.)
// It works like gamma, except the total range
// goes from 0..1, where a bias of
// 0.5 is no change, >0.5 is more gamma,
// <0.5 is less gamma. 
//
// 'a' is input value (0..1), 'b' is the
// bias amt (0..1); the return value (0..1)
// is the input remapped to the new bias curve

function bias( a,  b)
{
   return Math.pow(a, Math.log(b) / Math.log(0.5));
}

// =========== biasPixel ============
// Scale a pixel value to 0..1, apply bias,
// then rescale the pixel back to 0..255
function biasPixel(pixel, biasAmt)
{ 
   return 255*bias(pixel/255,biasAmt);
}

// ============= biasRGBImageChannels ============
function biasRGBImageChannels(img,b1,b2,b3){
// Apply bias to the image's color channels:
img.pixelIterate( 
   function(p) { /* anonymous callback */
      return (biasPixel(p.red,b1)<<16) + (biasPixel(p.green,b2)<<8)
         + biasPixel(p.blue,b3);
   }
);
}


// EXERCISE THE FUNCTIONS
if (typeof ImageProcessor=='undefined')
   IJ.showMessage("Please open an RGB first!");

else {
   biasRGBImageChannels(new RGBImage( ImageProcessor ),.6,.4,.4);
}

