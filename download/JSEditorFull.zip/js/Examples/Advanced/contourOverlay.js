ip = ImageProcessor;
imp = ImagePlus;
ip.snapshot();

img = new RGBImage(ip);

ip.smooth(); // SMOOTH
ip.smooth(); // SMOOTH
ip.smooth(); // SMOOTH

pixels = ip.getPixels();
length = pixels.length;

for (var i = 0; i < length; i++)
{
    pixels[i] &= 0xf0f0f0; // quantize to 16 colors
}



ip.findEdges();
ip.invert();
imp.updateAndDraw();

img.imageProcessor.copyBits(ip,0,0,7);
img.imagePlus.updateAndDraw();

ip.reset();
imp.updateAndDraw();
