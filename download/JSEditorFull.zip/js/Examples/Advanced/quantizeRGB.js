// Demo of quantizing the colors in an image.
// Note: Open an RGB image before hitting Evaluate!

// This code shows how to create a custom object
// in JavaScript:

function Quantizer()  // CONSTRUCTOR
{
    this.table = new Array();
    this.levels = 8; // default is 8 levels

    this.setLevels = function( levels ) {
        levels = 256/levels;
	this.levels = levels; // store new value
    	for (var i = 0; i < 256; i++) 
	    this.table.push(levels * Math.floor(i/levels) );
        }

    // initialize table
    if (arguments.length > 0) 
        this.setLevels(Number(arguments[0]));
    else
        this.setLevels(this.levels);

    this.quantize = function(p) { return this.table[255&p] }
}


// USAGE:
q = new Quantizer(14); // quantize to 4 colors

img = new RGBImage(ImageProcessor); // copy the current image

function quantizeImage(pix)
  {
    p = q.quantize( pix.red ) << 16;
    p |= q.quantize( pix.green ) << 8;
    p |= q.quantize( pix.blue );
    return p;
  }  
  // iterate on callback that uses 'q'
img.pixelIterate( quantizeImage );

// Note: RGBImage is defined in includes.js


