// Demo of selectively inverting RGB channels.
// This demo illustrates, among other things,
// how to create a custom JavaScript method
// that implements a Java interface 
// (in this case, the Enumeration interface).

// A method for inverting any or all channels of an RGB image:
function invertRGBChannel( r,g,b,ip,imp ) // r,g, and b are booleans
{
        // implement Java Enumeration for the source pixel array:
	pixelEnum = new java.util.Enumeration() {
           index: 0, elements: ImageProcessor.getPixels(),
           hasMoreElements: function() {
                 return (this.index < this.elements.length);
               },
           nextElement: function() {
                 return this.elements[this.index++];
               }
        }

	allPixels = ip.getPixels();  // destination
	i = 0; // counter

	while (pixelEnum.hasMoreElements())  {  // enumerate pixels
	     pixel = pixelEnum.nextElement();

	     red = (pixel >> 16) & 255;
	     green = (pixel >> 8) & 255;
	     blue = pixel & 255;

	     red = r ? 255-red : red;
             green = g ? 255-green : green;
             blue = b ? 255-blue : blue;

	     allPixels[i++] = (red << 16) | (green << 8) | blue;
		
	     if (i % 5000 == 0) 
		imp.updateAndDraw();   // incremental redraw                
	}
        imp.updateAndDraw(); // draw whatever remains
}

// ====================== USAGE EXAMPLE =========================
// Exercise it:
// e.g., invert red and blue channels...
invertRGBChannel( true, false, true, ImageProcessor, ImagePlus);


