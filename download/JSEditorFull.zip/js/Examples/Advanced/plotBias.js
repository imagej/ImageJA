// A demonstration of the Musgrave bias function.
// We define two functions, bias() and plotBias().
// plotBias() simply draws a graph showing the
// mapping of 0..1 to a new set of values
// representing the output of the bias() function.
// bias() remaps the unit interval to itself,
// nonlinearly. See Ebert, Musgrave, et al. in 
// "Texturing and Modeling", Academic Press.
// bias() is a useful alternative to gamma, since
// the bias domain is the unit interval, whereas
// gamma values go from 0..infinity
 
function bias( a,  b) // 'b' is the bias amt, 0..1
{
 	return Math.pow(a, Math.log(b) / Math.log(0.5));
}

function plotBias( biasAmt ) // draw a graph of bias
{
	img = new RGBImage(200,200);
	ip=img.imageProcessor;
	ip.setColor( new java.awt.Color(0.8,0.2,0) );
	ip.setLineWidth(1);
	ip.moveTo(0,200);
	x =[], y = [];

	for (var i = 0,pts = 100; i < pts; i++)
	{
	     x[i] = i/99;  
	     y[i] = bias( biasAmt ,x[i] );  
	     y[i] = 200 - y[i] * 200;
	}
 
	for (var i = 0; i < pts; i++)
	     ip.lineTo((2* i) & 255,  y[i] & 255 );

	ip.moveTo(20,20);
	ip.drawString("bias = " + biasAmt.toString());
 
	img.imagePlus.updateAndDraw();
	return img.imagePlus.getWindow();
}  // end function



// EXERCISE THE FUNCTIONS:

plotBias(0.2).setLocation(0,0);
plotBias(0.4).setLocation(220,0);
plotBias(0.6).setLocation(440,0);
plotBias(0.7).setLocation(660,0);

