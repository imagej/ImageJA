// ===================== PLUGIN CONVERSION =========================
// This function carries out the Convert to Plugin command. It opens
// the pluginStub.java file, customizes it to the user's script name,
// and saves it in the plugins folder. To do this it relies on methods
// in the Editor object, which is simply the reflection of our editor
// class (JavaScript_Editor).

function scriptToPlugin() 
{
if (Editor.nameOfCurrentFile =="")
   {
	IJ.showMessage("Script must be saved first.");
	return;
   }
   try {
	jscode= Editor.ta.getText();

	stub = String(Editor.readAll(Editor.pluginPath + "js/", "pluginStub.java"));

	pluginName = Editor.nameOfCurrentFile.split(".")[0] + "_";
	pluginFileName = pluginName + ".java";
        
	// modify the stub and write to plugins folder:
	stub = stub.replace("XpluginNameX",pluginName);
	stub = stub.replace("XscriptfileX",Editor.nameOfCurrentFile);
 	Editor.saveStringToFile(stub,Editor.pluginPath + pluginFileName); 
        
   	// also write the script file to the same folder:
        Editor.saveStringToFile(jscode,Editor.pluginPath + 
			Editor.nameOfCurrentFile);
   }
   catch(e) { IJ.showMessage("Error creating plugin: " + e); return; }

   IJ.showMessage("New plugin \"" + pluginFileName + "\" was successfully created.");   
} // function end


// ======================= CONSTRUCTOR =======================
// A wrapper object for an RGB image. Creates a new image
// in a new window.
//
//  Some usages:
//  img = new RGBImage( ImageProcessor ); // copy of existing image
//  img = new RGBImage();   // blank rgb image, 320x240
//  img = new RGBImage(640,480);
//  img = new RGBImage(800,600,"MyImage");
// 

function RGBImage()
{
   if (arguments.length > 0 && 
	arguments[0] instanceof Packages.ij.process.ImageProcessor)
   {
       	this.imagePlus = new Packages.ij.ImagePlus(
                  "Untitled",arguments[0].crop());
        
	this.width = arguments[0].getWidth();
	this.height = arguments[0].getHeight();
	this.title = "Untitled";
        this.imagePlus.show();
   }

   else 
   {
   	this.width = arguments.length > 0 ? arguments[0] : 320;
   	this.height= arguments.length > 1 ? arguments[1] : 240;
   	this.title = arguments.length > 2 ? arguments[2] : "Untitled (RGB)";
   
   	this.imagePlus = 
   		Packages.ij.gui.NewImage.createRGBImage(
			this.title,
			this.width,
			this.height,
			0,
			0
   		);
       this.imagePlus.show();
   }
   
   this.imageProcessor = this.imagePlus.getProcessor();
   this.pixels = this.imageProcessor.getPixels();

   this.reset = function()
   { 
	this.imageProcessor.reset();
	this.imagePlus.updateAndDraw();
   }

   this.refreshRate = 2500;

   this.pixelIterate = function( userfunc ) 
   {
	IJ.showStatus("Hit Alt key to cancel.");
        this.imageProcessor.snapshot();
	  var i = this.pixels.length;
        while (i--)
        {
                 var x = i%this.width;
                 var y = i/this.width;
                 var thePixel = this.pixels[i];
                 var red = (thePixel >> 16) & 255;
                 var green = (thePixel >> 8) & 255;
                 var blue = thePixel & 255;
                 theContext = { x:x,y:y,red:red,green:green,blue:blue,
                                w:this.width,h:this.height };
                 this.pixels[i] = userfunc(theContext);


		 // update screen every so often
		 if (i % this.refreshRate==0) 
		 {
			this.imagePlus.updateAndDraw();
			java.lang.Thread.sleep(5);

			// allow user to break with Alt key:
			if (IJ.altKeyDown()) 
			{
				this.reset();  
				IJ.showStatus("Operation canceled.");
				break;			
                 	}  // if 
		 
             }  // if 


        } // while
    }  // pixelIterate()





}

// ============== bias() ===============
function bias( a,  b)
{
	return Math.pow(a, Math.log(b) / Math.log(0.5));
}
       	

