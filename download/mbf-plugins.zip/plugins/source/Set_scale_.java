import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;

public class Set_scale_ implements PlugIn {

	public void run(String arg) {
		IJ.run("Set Scale...");
	}

}
