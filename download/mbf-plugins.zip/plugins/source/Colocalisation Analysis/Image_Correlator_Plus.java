import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;

public class Image_Correlator_Plus implements PlugIn {

	public void run(String arg) {
		IJ.showMessage("Image Correlator Plus","This plugin has been superceded by \n the plugin 'Manders Coefficients'");
	}

}
