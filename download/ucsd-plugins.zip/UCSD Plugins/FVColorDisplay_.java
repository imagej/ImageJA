import ij.*; 
import ij.plugin.*; 



/** This plugin toggles the color display mode of a displayed
FluoviewTiff_ image object.

@author Patrick Kelly <phkelly@ucsd.edu>
@see plugins.FluoviewTiff_

 */

public class FVColorDisplay_ implements PlugIn {
    
    public void run(String arg) {
	ImagePlus imp = WindowManager.getCurrentImage(); 

	if(imp==null) {
	    IJ.noImage(); 
	    return; 
	}

	// Make sure this is a FluoviewTiff_ image.
	if(FluoviewTiff_.isFluoviewImage(imp)==false) {
	    IJ.error("Must invoke this plugin on a FluoviewTiff_ image."); 
	    return; 
	}

	if(!imp.lock()) return;   // exit if in use
	FluoviewTiff_ fvimp = (FluoviewTiff_)imp; 
	fvimp.setComposite(!fvimp.isComposite(),true); 
	imp.unlock(); 
    }

}  // FVColorDisplay_
