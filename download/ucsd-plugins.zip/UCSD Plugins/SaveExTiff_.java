import ij.*;
import ij.io.*; 
import ij.plugin.*; 

import java.awt.*; 
import java.io.*; 

/** This plug-in defines a means to save ExtendedTiff images. It is
    similar to the ij.io.FileSaver object. However, it deals only with
    Tiff files and calls the plugins.ExtendedTiffEncoder rather than
    the standard ij.io.TiffEncoder.

@see ij.io.TiffEncoder
@see plugins.ExtendedTiff_
@see plugins.ExtendedTiffEncoder

@author Patrick Kelly <phkelly@ucsd.edu> */


public class SaveExTiff_ implements PlugIn {
    private static final String EXTENSION = ".tif";
    private static String defaultDirectory = null; 
    private ImagePlus imp; 

    // --------------------------------------------------
    public void run(String args) {
	// Get current image.
	ImagePlus imp = WindowManager.getCurrentImage(); 
	if(imp==null) {
	    IJ.noImage(); 
	    return; 
	}

	this.imp = imp; 

	saveit(); 
    }

    // --------------------------------------------------
    public void saveImage(ImagePlus imp) {
	if(imp==null) {
	    IJ.error("Input image is null."); 
	    return; 
	}

	this.imp = imp; 
	saveit(); 
    }

    // --------------------------------------------------
    protected void saveit() {
	String fileName = getPath("TIFF",".tif"); 
	if(fileName==null)
	    return; 

	boolean rtn = save(fileName); 
	if(rtn==false)
	    IJ.error("Error saving file: "+fileName); 
    }

    // --------------------------------------------------
    protected boolean save(String path) {
	// Make calling protocol similar to that of FileSaver.
	if(imp.getStackSize()==1)
	    return saveAsTiff(path); 
	else
	    return saveAsTiffStack(path); 
    }

    // --------------------------------------------------
    // From ij.io.FileSaver
    protected String getPath(String type, String extension) {
	FileDialog fd = new FileDialog(IJ.getInstance(), 
				       "Save as "+type+"...", FileDialog.SAVE);
	String name = imp.getTitle();
	int dotIndex = name.lastIndexOf(".");
	if (dotIndex>=0)
	    name = name.substring(0, dotIndex)+extension;
	fd.setFile(name);

	if (defaultDirectory!=null)
	    fd.setDirectory(defaultDirectory);
	fd.show();
	name = fd.getFile();
	String directory = fd.getDirectory();
	defaultDirectory = directory;
	fd.dispose();
	if (name == null)
	    return null;
	IJ.showStatus("Saving as "+ type + ": " + directory + name);
	return directory+name;
    }


    // --------------------------------------------------
    /** Save the image in TIFF format using the specified path. */
    public boolean saveAsTiff(String path) {
	FileInfo fi = imp.getFileInfo();
	fi.nImages = 1;
	try {
	    /// phkelly - begin: using ExtendedTiffEncoder
	    ExtendedTiffEncoder file = new ExtendedTiffEncoder(fi);
	    /// phkelly - end.
	    DataOutputStream out = 
		new DataOutputStream(new BufferedOutputStream
				     (new FileOutputStream(path)));
	    file.write(out);
	    out.close();
	}
	catch (IOException e) {
	    IJ.log("Filesaver: " + e.getMessage());
	    return false;
	}
	return true;
    }

    // --------------------------------------------------
    /** Save the stack as a multi-image TIFF using the specified path. */
    public boolean saveAsTiffStack(String path) {
	FileInfo fi = imp.getFileInfo();
	if (fi.nImages==1)
	    {IJ.log("This is not a stack"); return false;}
	fi.pixels = imp.getStack().getImageArray();
	try {
	    /// phkelly - begin: using ExtendedTiffEncoder
	    ExtendedTiffEncoder file = new ExtendedTiffEncoder(fi);
	    /// phkelly - end.
	    DataOutputStream out = 
		new DataOutputStream(new BufferedOutputStream
				     (new FileOutputStream(path)));
	    file.write(out);
	    out.close();
	}
	catch (IOException e) {
	    IJ.log("Filesaver: " + e.getMessage());
	    return false;
	}
	return true;
    }

} // SaveExTiff_
