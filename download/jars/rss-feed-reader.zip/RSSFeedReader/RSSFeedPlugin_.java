import java.net.*;
import java.util.*;

import com.sun.syndication.feed.synd.SyndContent;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;

import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;
import ij.plugin.PlugIn;


public class RSSFeedPlugin_ implements PlugIn {
	public String urlStr="http://antwrp.gsfc.nasa.gov/apod.rss";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
    		System.setProperty("plugins.dir", args[0]);
    		new ImageJ();
    	}
    	catch (Exception ex) {
    		Log("plugins.dir misspecified");
    	}

	}
    /* general support for debug variables 
     */
     private static boolean debug=true;
     public static void Log(String astr) {
     	if (debug) IJ.log(astr);
     }
     
     public String[] parse (String astr) {
    	// ArrayList ret=new ArrayList(); 
    	 StringTokenizer st=new StringTokenizer(astr);
    	 int counter=0;
    	 String[] ret=new String[2];
    	  while (st.hasMoreTokens()) {
    		  String as=st.nextToken("><");
    	  int i0=as.indexOf("src=");
    	  if (i0>0) {
    		  as=as.substring(i0+5);
    		  i0=as.indexOf('"');
    		  as=as.substring(0,i0);
    		  counter++;
    		  //Log("index "+as);
    		  ret[0]=as;
    		  //ret.add(as);
    	  }
    	   i0=as.indexOf("href=");
    	  if (i0>0) {
    		  as=as.substring(i0+6);
    		  i0=as.indexOf('"');
    		  as=as.substring(0,i0);
    		  counter++;
    		  //Log("index "+as);
    		  ret[1]=as;
    		  //ret.add(as);
    	  }
    	  }
    	 return ret;
     }
     
      
	public void run(String arg) {
		boolean ok = false;
		//IJ.log("SocketServer: waiting on port "+ImageJ.getPort());
            try {
                URL feedUrl = new URL(urlStr);
                SyndFeedInput input = new SyndFeedInput();
                
                SyndFeed feed = input.build(new XmlReader(feedUrl));
                StringBuffer sb=new StringBuffer("");
                //Log(feed.toString());
                List entries=feed.getEntries();
               if (!entries.isEmpty()) {
            	   Iterator it=entries.iterator();
            	   while (it.hasNext()){
            		   
            		   	SyndEntry se= (SyndEntry) it.next();
            		   	SyndContent sc=se.getDescription();
            		   	String desc=sc.getValue();
            		   	//sb.append(desc);
            		   String[] imgstr=	parse(desc);
            		   sb.append(imgstr[1]);
            		   //Log("url "+imgstr[0]);
            		    
            		   ImagePlus imp=new ImagePlus(imgstr[0]);
            		   imp.show();
            		   	sb.append("\r\n");
            		   	
            	   }
               }
                ok = true;
                IJ.write(sb.toString());
            }
            catch (Exception ex) {
                ex.printStackTrace();
              
                Log("ERROR: "+ex.getMessage());
            }
         

        if (!ok) {
             
            Log("FeedReader reads and prints any RSS/Atom feed type. \r\n" +
             "The first parameter must be the URL of the feed to read.");
             
        }
		
	}

}
