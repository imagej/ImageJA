Walter O'Dell PhD,  wodell@rochester.edu,   11/6/02
    Overview of GenericDialogPlus and GenericRecallableDialog classes:
           these classes enable the specification of scrollbars, buttons, and
           the objects available in the GenericDialog class that remain active 
           until the dialog window is actively closed.
   
    Attributes:
           Scrollbars: enables scrollbars for integer, float and/or double values.
                   float/double values are facilitated by maintaining a scaling factor 
                   for each scrollbar, and an Ndigits parameter.
                   Keyboard arrow keys adjust values of most recently mouse-activated scrollbar.
           Buttons: enables buttons that perform actions (besides 'exit')
   
           rowOfItems(): enables placement of multiple objects in a row, 
                   e.g. the scrollbar title, current value and the scrollbar itsself.
           addButtons(): enables easy specification of multiple buttons across a row
           getBooleanValue(int index_to_list); getNumericValue(); getButtonValue(); getScrollbarValue()
                   enables access to the value of any individual object without having to go 
                   through the entire list of like-objects with getNext...() functions.
   
    minor changes to the parent GenericDialog were needed, as described in the header 
       for the temporary GenericDialog2 class, namely:
        1. Changed 'private' attribute to 'protected' for several variables in parent 
                  class to facilitate use of these variables by GenericDialogPlus class
         2. Added variables (int) x; // GridBagConstraints height variable
                                         and  (Container) activePanel; // facilitates row of items option
                     and code altered to initialize and update these new variables.
      It is hoped that these modifications will be made to the parent GenericDialog class
      in future versions of ImageJ, negating the need for the GenericDialog2 class.

Compiling notes:
the GenericDialog2.java file must be compiled succesfully prior to compiling this one,
and any programs that will use the GenericRecallableDialog class will need to
compile the GenericRecallableDialog.java file first. Two class files are generated from
this file: the GenericDialogPlus.class and the GenericRecallableDialog.class.
All can be put into the plugins folder and compiled from within the ImageJ program.


