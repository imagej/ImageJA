Walter O'Dell PhD,  wodell@rochester.edu,   11/6/02
   Adjusts window and level of the active image in the manner similar
   to that implemented on medical image terminals -- replacement for 
   brightness/contrast adjustment.
  
   Works on Stacks color images also.
   Because it uses the GenericRecallableDialog class, keyboard arrow 
   keys act on the most-recently mouse-touched scrollbar.

Compiling notes:
the GenericDialog2.java, and GenericRecallableDialog.java files must be 
compiled succesfully prior to compiling this one.  All can be put into the
plugins folder and compiled from within the ImageJ program.
